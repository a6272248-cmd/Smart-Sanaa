package com.smartsanaa.manager

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.io.File
import java.util.UUID
import kotlin.math.ceil
import kotlin.math.roundToInt

/** A4 print settings aligned with the original Smart Manager card editor. */
data class PrintTemplate(
    val columns: Int = 4,
    val rows: Int = 20,
    val cardWidthMm: Float = 52.2f,
    val cardHeightMm: Float = 14.47f,
    val marginMm: Float = 0f,
    val gapMm: Float = 0.4f,
    val showSerial: Boolean = false,
    val serialStart: Int = 1,
    val showPrice: Boolean = true,
    val usernameX: Float = 50f,
    val usernameY: Float = 58f,
    val usernameWidth: Float = 90f,
    val usernameSize: Float = 9f,
    val backgroundPath: String? = null
)

@Composable
fun VoucherCreator(
    repo: RouterRepository?,
    connected: Boolean,
    initialService: String,
    onCreated: (String, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val templatePrefs = remember(context) { context.getSharedPreferences("voucher_print", Context.MODE_PRIVATE) }
    var service by remember { mutableStateOf(if (initialService == "User Manager" && repo?.um?.path != null) "User Manager" else "Hotspot") }
    var profiles by remember { mutableStateOf<List<String>>(emptyList()) }
    var servers by remember { mutableStateOf<List<String>>(emptyList()) }
    var profile by remember { mutableStateOf("") }
    var server by remember { mutableStateOf("all") }
    var quantity by remember { mutableStateOf("10") }
    var usernameLength by remember { mutableStateOf("8") }
    var prefix by remember { mutableStateOf("") }
    var usernameType by remember { mutableStateOf("numbers") }
    var duration by remember { mutableStateOf("1d") }
    var customer by remember { mutableStateOf("admin") }
    var group by remember { mutableStateOf("default") }
    var sharedUsers by remember { mutableStateOf("1") }
    var price by remember { mutableStateOf("0") }
    var notes by remember { mutableStateOf("") }
    var loadingProfiles by remember { mutableStateOf(false) }
    var loadingServers by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("") }
    var planned by remember { mutableStateOf<List<String>>(emptyList()) }
    var created by remember { mutableStateOf<List<String>>(emptyList()) }
    var profileMenu by remember { mutableStateOf(false) }
    var serverMenu by remember { mutableStateOf(false) }

    var templatePath by remember { mutableStateOf(templatePrefs.getString("background", "").orEmpty()) }
    var templateBitmap by remember(templatePath) { mutableStateOf(templatePath.takeIf { it.isNotBlank() }?.let(::decodeVoucherTemplate)) }
    var columns by remember { mutableStateOf("4") }
    var rowsPerPage by remember { mutableStateOf("20") }
    var cardWidth by remember { mutableStateOf("52.2") }
    var cardHeight by remember { mutableStateOf("14.47") }
    var margin by remember { mutableStateOf("0") }
    var gap by remember { mutableStateOf("0.4") }
    var showSerial by remember { mutableStateOf(false) }
    var serialStart by remember { mutableStateOf("1") }
    var showPrice by remember { mutableStateOf(true) }
    var usernameX by remember { mutableFloatStateOf(50f) }
    var usernameY by remember { mutableFloatStateOf(58f) }
    var usernameWidth by remember { mutableFloatStateOf(90f) }
    var usernameSize by remember { mutableFloatStateOf(9f) }
    var pageFrom by remember { mutableStateOf("1") }
    var pageTo by remember { mutableStateOf("1") }

    val templatePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val target = File(context.filesDir, "voucher-template-${System.currentTimeMillis()}.img")
                context.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
                    ?: error("تعذر قراءة صورة القالب")
                templatePath = target.absolutePath
                templatePrefs.edit().putString("background", target.absolutePath).apply()
                templateBitmap = decodeVoucherTemplate(target.absolutePath)
                status = "تم حفظ قالب الطباعة على الهاتف"
            }.onFailure { status = "تعذر تحميل القالب: ${it.message}" }
        }
    }

    LaunchedEffect(repo, connected, service, customer) {
        delay(350)
        profiles = emptyList()
        servers = emptyList()
        profile = ""
        val r = repo ?: return@LaunchedEffect
        if (!connected) return@LaunchedEffect
        val root = r.profileRoot(service) ?: return@LaunchedEffect
        loadingProfiles = true
        runCatching {
            val path = "$root/print"
            val params = if (service == "User Manager" && root.startsWith("/tool/")) {
                mapOf(".proplist" to "name", "customer" to customer.ifBlank { "admin" })
            } else mapOf(".proplist" to "name")
            r.api.execute(path, r.requestParams(path, params)).data.mapNotNull { it["name"] }.distinct().sorted()
        }.onSuccess { list -> profiles = list; if (profile !in list) profile = list.firstOrNull().orEmpty() }
            .onFailure { status = "تعذر تحميل الباقات: ${it.message}" }
        loadingProfiles = false
        if (service == "Hotspot") {
            loadingServers = true
            runCatching { r.api.execute("/ip/hotspot/print", mapOf(".proplist" to "name")).data.mapNotNull { it["name"] }.distinct().sorted() }
                .onSuccess { servers = listOf("all") + it; if (server !in servers) server = "all" }
                .onFailure { status = "تعذر تحميل خوادم Hotspot: ${it.message}" }
            loadingServers = false
        }
    }

    val totalPages = if (created.isEmpty()) 0 else {
        val perPage = (columns.toIntOrNull() ?: 4).coerceAtLeast(1) * (rowsPerPage.toIntOrNull() ?: 20).coerceAtLeast(1)
        ceil(created.size.toDouble() / perPage).toInt()
    }
    LaunchedEffect(totalPages) { if (totalPages > 0) pageTo = totalPages.toString() }

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { PageHeading("إنشاء الكروت", "إعداد الكروت ومعاينتها ثم إضافتها إلى MikroTik") }

        if (planned.isEmpty()) {
            item {
                PanelCard {
                    Text("نوع الكروت", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Hotspot", "User Manager").forEach { item ->
                            FilterChip(
                                selected = service == item,
                                onClick = { service = item; status = ""; created = emptyList() },
                                enabled = item != "User Manager" || repo?.um?.path != null,
                                label = { Text(item) }
                            )
                        }
                    }
                    Text("الباقة", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    Box {
                        OutlinedButton(onClick = { profileMenu = true }, modifier = Modifier.fillMaxWidth(), enabled = profiles.isNotEmpty()) {
                            Text(profile.ifBlank { if (loadingProfiles) "جار تحميل الباقات…" else "اختر الباقة" }, modifier = Modifier.weight(1f), textAlign = TextAlign.Start)
                        }
                        DropdownMenu(expanded = profileMenu, onDismissRequest = { profileMenu = false }) {
                            profiles.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { profile = item; profileMenu = false }) }
                        }
                    }
                    if (loadingProfiles) LinearProgressIndicator(Modifier.fillMaxWidth())
                    if (service == "Hotspot") {
                        Text("خادم Hotspot", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        Box {
                            OutlinedButton(onClick = { serverMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (server == "all") "كل الخوادم" else server, modifier = Modifier.weight(1f), textAlign = TextAlign.Start)
                            }
                            DropdownMenu(expanded = serverMenu, onDismissRequest = { serverMenu = false }) {
                                (listOf("all") + servers.filter { it != "all" }).distinct().forEach { item ->
                                    DropdownMenuItem(text = { Text(if (item == "all") "كل الخوادم" else item) }, onClick = { server = item; serverMenu = false })
                                }
                            }
                        }
                        if (loadingServers) LinearProgressIndicator(Modifier.fillMaxWidth())
                        VoucherField("حد الاستخدام مثال 1d أو 2h30m", duration) { duration = it }
                    }
                    if (service == "User Manager" && repo?.um?.path?.startsWith("/tool/") == true) {
                        VoucherField("Customer / المالك", customer) { customer = it }
                        VoucherField("عدد المستخدمين المتزامنين", sharedUsers) { sharedUsers = it }
                    } else if (service == "User Manager") {
                        VoucherField("Group", group) { group = it }
                        VoucherField("عدد المستخدمين المتزامنين", sharedUsers) { sharedUsers = it }
                    }
                }
            }
            item {
                PanelCard {
                    Text("إعداد الكروت", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VoucherField("الكمية (1–100)", quantity, Modifier.weight(1f)) { quantity = it.filter(Char::isDigit).take(3) }
                        VoucherField("طول الكود", usernameLength, Modifier.weight(1f)) { usernameLength = it.filter(Char::isDigit).take(2) }
                    }
                    VoucherField("بادئة اسم المستخدم (اختياري)", prefix) { prefix = it.trim().take(12) }
                    Text("نوع الكود", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("numbers" to "أرقام", "lowercase" to "أحرف صغيرة").forEach { (value, label) ->
                            FilterChip(selected = usernameType == value, onClick = { usernameType = value }, label = { Text(label, fontSize = 11.sp) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("uppercase" to "أحرف كبيرة", "mixed" to "مختلط").forEach { (value, label) ->
                            FilterChip(selected = usernameType == value, onClick = { usernameType = value }, label = { Text(label, fontSize = 11.sp) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VoucherField("السعر", price, Modifier.weight(1f)) { price = it.take(12) }
                        VoucherField("ملاحظات", notes, Modifier.weight(1f)) { notes = it.take(60) }
                    }
                    Text("تُنشأ الكروت باسم مستخدم فقط مثل لوحة Smart Manager؛ كلمة المرور فارغة. تأكد أن إعداد المصادقة على الراوتر يسمح بذلك.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    Button(
                        onClick = {
                            val r = repo
                            val count = quantity.toIntOrNull()
                            val length = usernameLength.toIntOrNull()
                            if (r == null || !connected) { status = "اتصل بالراوتر أولًا"; return@Button }
                            if (count == null || count !in 1..100) { status = "الكمية يجب أن تكون من 1 إلى 100"; return@Button }
                            if (length == null || length !in 3..18) { status = "طول الكود يجب أن يكون من 3 إلى 18"; return@Button }
                            if (profile.isBlank() || profile !in profiles) { status = "اختر باقة موجودة على الراوتر"; return@Button }
                            if (service == "Hotspot" && duration.isNotBlank() && ExpiryPolicy.durationSeconds(duration)?.let { it > 0L } != true) { status = "اكتب حد استخدام صحيحًا مثل 1d أو 2h30m"; return@Button }
                            if (service == "User Manager" && sharedUsers.toIntOrNull()?.let { it > 0 } != true) { status = "عدد المستخدمين المتزامنين يجب أن يكون رقمًا موجبًا"; return@Button }
                            if (service == "User Manager" && r.um.path == null) { status = r.um.status; return@Button }
                            busy = true
                            created = emptyList()
                            status = "جار فحص الأسماء وتكوين المعاينة…"
                            scope.launch {
                                runCatching {
                                    val existing = r.existingUsernames(service, customer.ifBlank { "admin" })
                                    VoucherCodePolicy.generate(count, length, prefix.trim(), usernameType, existing)
                                }.onSuccess {
                                    planned = it
                                    status = "المعاينة جاهزة: ${it.size} كرت. لم يتم إرسال أي أمر إنشاء إلى الراوتر بعد."
                                }.onFailure { status = "تعذر تجهيز المعاينة: ${it.message}" }
                                busy = false
                            }
                        },
                        enabled = connected && !busy && !loadingProfiles && profiles.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AddCard, null); Spacer(Modifier.width(8.dp)); Text(if (busy) "جار التجهيز…" else "معاينة قبل الإضافة")
                    }
                }
            }
        } else {
            item {
                PanelCard {
                    Text("معاينة الدفعة", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("${planned.size} كرت · $service · الباقة $profile", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("هذه أسماء مقترحة محليًا. لن تُحفظ على الراوتر حتى تضغط تأكيد الإضافة.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    planned.take(12).forEachIndexed { index, code -> InfoLine("${index + 1}", code) }
                    if (planned.size > 12) Text("و ${planned.size - 12} كرتًا آخر…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { planned = emptyList(); status = "يمكنك تعديل الإعدادات ثم إعادة المعاينة." }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("تعديل الإعدادات") }
                        Button(onClick = {
                            val r = repo ?: return@Button
                            val batch = planned.toList()
                            val selectedService = service
                            val selectedProfile = profile
                            val selectedCustomer = customer.ifBlank { "admin" }
                            val selectedGroup = group.ifBlank { "default" }
                            val selectedShared = sharedUsers.ifBlank { "1" }
                            val selectedServer = server
                            val selectedDuration = duration
                            val batchId = UUID.randomUUID().toString().take(10)
                            busy = true
                            progress = 0
                            status = "جار إنشاء الكروت على الراوتر…"
                            scope.launch {
                                val confirmed = mutableListOf<String>()
                                var stopMessage = ""
                                for (code in batch) {
                                    val values = buildMap {
                                        put("username", code)
                                        put("password", "")
                                        put("profile", selectedProfile)
                                        put("comment", "Smart-Sanaa batch $batchId")
                                        if (selectedService == "Hotspot") {
                                            if (selectedDuration.isNotBlank()) put("limit-uptime", selectedDuration)
                                            if (selectedServer.isNotBlank() && selectedServer != "all") put("server", selectedServer)
                                        } else {
                                            put("customer", selectedCustomer)
                                            put("group", selectedGroup)
                                            put("shared-users", selectedShared)
                                        }
                                    }
                                    try {
                                        r.createUser(selectedService, values, allowEmptyPassword = true)
                                        confirmed += code
                                        progress = confirmed.size
                                    } catch (e: PartialUserCreationException) {
                                        stopMessage = "تم إنشاء $code لكن لم يكتمل ربط الباقة؛ لم يُدرج في ملف الطباعة. ${e.message}"
                                        break
                                    } catch (e: Exception) {
                                        stopMessage = "توقفت الدفعة عند $code: ${e.message}. لا تعِد الإرسال قبل تحديث قائمة الكروت؛ قد يكون الراوتر نفذ الطلب الأخير."
                                        break
                                    }
                                }
                                created = confirmed
                                planned = emptyList()
                                val finalMessage = when {
                                    stopMessage.isNotBlank() -> "تم تأكيد ${confirmed.size} من ${batch.size}. $stopMessage"
                                    confirmed.size == batch.size -> "تم إنشاء ${confirmed.size} كرتًا بنجاح على $selectedService."
                                    else -> "تم تأكيد ${confirmed.size} من ${batch.size} كرتًا."
                                }
                                status = finalMessage
                                onCreated(selectedService, finalMessage)
                                busy = false
                            }
                        }, enabled = connected && !busy, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Save, null); Spacer(Modifier.width(6.dp)); Text(if (busy) "جار الإضافة $progress/${planned.size}" else "تأكيد وإضافة للراوتر")
                        }
                    }
                }
            }
        }

        if (created.isNotEmpty()) {
            item {
                PanelCard {
                    Text("الكروت المؤكدة على الراوتر", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("${created.size} كرت · ملف PDF سيحتوي على الكروت التي تأكد إنشاؤها فقط.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    created.take(8).forEachIndexed { index, code -> InfoLine("${index + 1}", code) }
                    if (created.size > 8) Text("و ${created.size - 8} كرتًا آخر…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                PanelCard {
                    Text("قالب الطباعة A4", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    if (templateBitmap != null) {
                        Image(
                            bitmap = templateBitmap!!.asImageBitmap(), contentDescription = "قالب الكرت",
                            modifier = Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop
                        )
                    } else {
                        Surface(color = Color(0xFFEAF3FA), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().height(90.dp)) {
                            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text("SMART SANAA", color = Color(0xFF17466B), fontWeight = FontWeight.Black, fontSize = 17.sp)
                                Text("معاينة تصميم الكرت", color = Color(0xFF42647F), fontSize = 12.sp)
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { templatePicker.launch(arrayOf("image/jpeg", "image/png", "image/webp")) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.AttachFile, null); Spacer(Modifier.width(5.dp)); Text("اختيار صورة القالب")
                        }
                        if (templatePath.isNotBlank()) OutlinedButton(onClick = {
                            runCatching { File(templatePath).delete() }
                            templatePath = ""; templateBitmap = null
                            templatePrefs.edit().remove("background").apply()
                        }) { Text("إزالة") }
                    }
                    Text("إعداد الورقة", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VoucherField("الأعمدة", columns, Modifier.weight(1f)) { columns = it.filter(Char::isDigit).take(1) }
                        VoucherField("الصفوف", rowsPerPage, Modifier.weight(1f)) { rowsPerPage = it.filter(Char::isDigit).take(2) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VoucherField("عرض الكرت mm", cardWidth, Modifier.weight(1f)) { cardWidth = it.filter { ch -> ch.isDigit() || ch == '.' }.take(6) }
                        VoucherField("ارتفاع الكرت mm", cardHeight, Modifier.weight(1f)) { cardHeight = it.filter { ch -> ch.isDigit() || ch == '.' }.take(6) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VoucherField("الهامش mm", margin, Modifier.weight(1f)) { margin = it.filter { ch -> ch.isDigit() || ch == '.' }.take(6) }
                        VoucherField("الفاصل mm", gap, Modifier.weight(1f)) { gap = it.filter { ch -> ch.isDigit() || ch == '.' }.take(6) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("إظهار الرقم التسلسلي", Modifier.weight(1f))
                        Switch(checked = showSerial, onCheckedChange = { showSerial = it })
                    }
                    if (showSerial) VoucherField("بداية الرقم التسلسلي", serialStart, Modifier.fillMaxWidth()) { serialStart = it.filter(Char::isDigit).take(8) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("إظهار السعر على الكرت", Modifier.weight(1f))
                        Switch(checked = showPrice, onCheckedChange = { showPrice = it })
                    }
                    Text("موضع اسم المستخدم أفقيًا: ${usernameX.roundToInt()}%", style = MaterialTheme.typography.bodySmall)
                    Slider(value = usernameX, onValueChange = { usernameX = it }, valueRange = 10f..90f)
                    Text("موضع اسم المستخدم رأسيًا: ${usernameY.roundToInt()}%", style = MaterialTheme.typography.bodySmall)
                    Slider(value = usernameY, onValueChange = { usernameY = it }, valueRange = 15f..90f)
                    Text("عرض النص: ${usernameWidth.roundToInt()}%", style = MaterialTheme.typography.bodySmall)
                    Slider(value = usernameWidth, onValueChange = { usernameWidth = it }, valueRange = 40f..100f)
                    Text("حجم الخط: ${usernameSize.roundToInt()}", style = MaterialTheme.typography.bodySmall)
                    Slider(value = usernameSize, onValueChange = { usernameSize = it }, valueRange = 6f..18f)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VoucherField("من صفحة", pageFrom, Modifier.weight(1f)) { pageFrom = it.filter(Char::isDigit).take(4) }
                        VoucherField("إلى صفحة", pageTo, Modifier.weight(1f)) { pageTo = it.filter(Char::isDigit).take(4) }
                    }
                    Text("عدد صفحات الدفعة: $totalPages · الافتراضي 80 كرتًا في كل ورقة A4.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    Button(
                        onClick = {
                            runCatching {
                                val layout = PrintTemplate(
                                    columns = columns.toInt(), rows = rowsPerPage.toInt(),
                                    cardWidthMm = cardWidth.toFloat(), cardHeightMm = cardHeight.toFloat(),
                                    marginMm = margin.toFloat(), gapMm = gap.toFloat(),
                                    showSerial = showSerial, serialStart = serialStart.toIntOrNull() ?: 1,
                                    showPrice = showPrice, usernameX = usernameX, usernameY = usernameY,
                                    usernameWidth = usernameWidth, usernameSize = usernameSize,
                                    backgroundPath = templatePath.takeIf { it.isNotBlank() }
                                )
                                PrintLayout.page(layout.columns, layout.rows, layout.cardWidthMm, layout.cardHeightMm, layout.marginMm, layout.gapMm)
                                val from = pageFrom.toIntOrNull() ?: 1
                                val to = pageTo.toIntOrNull() ?: totalPages
                                require(from in 1..totalPages && to in from..totalPages) { "نطاق الصفحات يجب أن يكون بين 1 و$totalPages" }
                                layout to (from..to)
                            }.onSuccess { (layout, range) ->
                                runCatching {
                                    val file = exportVoucherPdf(context.cacheDir, created, price, notes, layout, range.first, range.last)
                                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/pdf"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(intent, "تصدير كروت Smart Sanaa PDF"))
                                }.onFailure { status = "تعذر إنشاء ملف PDF: ${it.message}" }
                            }.onFailure { status = "إعدادات الطباعة غير صحيحة: ${it.message}" }
                        },
                        enabled = created.isNotEmpty() && !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text("تصدير PDF ومشاركته للطباعة")
                    }
                }
            }
        }
        if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (status.isNotBlank()) item { Text(status, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun VoucherField(label: String, value: String, modifier: Modifier = Modifier.fillMaxWidth(), update: (String) -> Unit) {
    OutlinedTextField(value, update, label = { Text(label) }, modifier = modifier, singleLine = true)
}

private fun decodeVoucherTemplate(path: String): Bitmap? {
    val file = File(path)
    if (!file.isFile) return null
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    val maxSide = maxOf(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
    val sample = maxOf(1, maxSide / 1800)
    return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
}

private fun exportVoucherPdf(
    cacheDir: File,
    cards: List<String>,
    price: String,
    notes: String,
    template: PrintTemplate,
    fromPage: Int,
    toPage: Int
): File {
    require(cards.isNotEmpty()) { "لا توجد كروت مؤكدة للطباعة" }
    val rects = PrintLayout.page(template.columns, template.rows, template.cardWidthMm, template.cardHeightMm, template.marginMm, template.gapMm)
    val perPage = rects.size
    val totalPages = ceil(cards.size.toDouble() / perPage).toInt()
    require(fromPage in 1..totalPages && toPage in fromPage..totalPages)

    val document = PdfDocument()
    val image = template.backgroundPath?.let(::decodeVoucherTemplate)
    val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    val shapePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(243, 248, 252); style = Paint.Style.FILL }
    val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(187, 207, 224); style = Paint.Style.STROKE; strokeWidth = 0.65f }
    val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(19, 65, 100); style = Paint.Style.FILL }
    val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; textSize = 5.4f; typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    val codePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(15, 43, 68); textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(75, 98, 118); textSize = 4.4f; typeface = Typeface.create("sans-serif", Typeface.NORMAL) }
    val serialPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(32, 113, 151); textSize = 4.4f; textAlign = Paint.Align.RIGHT; typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    val pageWidth = (PrintLayout.A4_WIDTH_MM * PrintLayout.POINTS_PER_MM).roundToInt()
    val pageHeight = (PrintLayout.A4_HEIGHT_MM * PrintLayout.POINTS_PER_MM).roundToInt()

    for (pageNumber in fromPage..toPage) {
        val page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        val canvas = page.canvas
        val pageCards = cards.drop((pageNumber - 1) * perPage).take(perPage)
        pageCards.forEachIndexed { localIndex, username ->
            val rect = rects[localIndex]
            val left = rect.xMm * PrintLayout.POINTS_PER_MM
            val top = rect.yMm * PrintLayout.POINTS_PER_MM
            val width = rect.widthMm * PrintLayout.POINTS_PER_MM
            val height = rect.heightMm * PrintLayout.POINTS_PER_MM
            val card = RectF(left, top, left + width, top + height)

            if (image != null) {
                canvas.drawBitmap(image, null, card, bitmapPaint)
            } else {
                canvas.drawRoundRect(card, 3f, 3f, shapePaint)
                canvas.drawRoundRect(card, 3f, 3f, borderPaint)
                val band = RectF(left, top, left + width, top + minOf(7f, height * .28f))
                canvas.drawRoundRect(band, 3f, 3f, bandPaint)
                canvas.drawText("SMART SANAA", left + 5f, top + minOf(5.3f, height * .23f), titlePaint)
            }

            val absoluteIndex = (pageNumber - 1) * perPage + localIndex
            val centerX = left + width * (template.usernameX.coerceIn(0f, 100f) / 100f)
            val textY = top + height * (template.usernameY.coerceIn(15f, 95f) / 100f)
            val allowedWidth = width * (template.usernameWidth.coerceIn(30f, 100f) / 100f)
            canvas.save()
            canvas.clipRect(centerX - allowedWidth / 2f, top, centerX + allowedWidth / 2f, top + height)
            codePaint.textSize = template.usernameSize.coerceIn(6f, 18f)
            val fittedSize = minOf(codePaint.textSize, codePaint.textSize * (allowedWidth / codePaint.measureText(username).coerceAtLeast(1f)).coerceAtMost(1f))
            codePaint.textSize = fittedSize
            canvas.drawText(username, centerX, textY, codePaint)
            canvas.restore()

            if (template.showPrice && price.isNotBlank() && price != "0") {
                canvas.drawText("السعر: $price", left + 4f, top + height - 3f, smallPaint)
            }
            if (template.showSerial) {
                canvas.drawText("${template.serialStart + absoluteIndex}", left + width - 4f, top + height - 3f, serialPaint)
            }
            if (notes.isNotBlank() && template.cardHeightMm >= 20f) {
                smallPaint.textSize = 4f
                canvas.drawText(notes.take(32), left + width / 2f, top + height - 3f, smallPaint)
            }
        }
        document.finishPage(page)
    }

    val directory = File(cacheDir, "exports").apply { mkdirs() }
    val output = File(directory, "smart-sanaa-vouchers-${System.currentTimeMillis()}.pdf")
    output.outputStream().use { document.writeTo(it) }
    document.close()
    image?.recycle()
    return output
}
