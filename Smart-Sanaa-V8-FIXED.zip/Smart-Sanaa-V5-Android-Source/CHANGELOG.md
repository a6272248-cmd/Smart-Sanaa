# Changelog

## V8 — 2026-11-07

- Matched the original Smart Manager navigation labels and home shortcuts; changed the customer page label to العملاء and removed duplicate/non-functional drawer entries.
- Added actual Hotspot account total beside active sessions and active User Manager session count in reports; system log messages are now shown with credential-like values redacted.
- Added a direct reports shortcut to Hotspot active clients and aligned the reports page with the original operational summary.
- Applied the RouterOS v6 User Manager customer context consistently to discovery, list, profile, session, account and expiry operations.
- Added bounded expired-card selection and actions: disable/delete selected Hotspot cards; remove only selected UM7 profile links; keep UM6 expiry as review-only.
- Improved User Manager maintenance: database-size fallback, free-space check, verified backup-only action, confirmed exact-file backup deletion, backup-before-maintenance, UM6 rebuild plus rebuild-log, 180-second command timeout and a clean direct button to expired cards.
- Rebuilt voucher creation around local preview-before-write, existing-name checks, prefix/length/character-set options, Hotspot server selection, UM6 customer / UM7 group, and confirmed-only output.
- Matched the original A4 template defaults (4×20, 52.2×14.47 mm, 0.4 mm gap, zero margin); added background-image selection, text-position controls, serial numbering and page-range export.
- Kept the package name, app identity, native RouterOS API, RTL layout and secure credential storage unchanged.

## V7 — 2026-11-07

- Added client-side paging and bounded selection/bulk enable, disable and delete for user/card lists.
- Added exact-ID User Manager v7 deletion that removes only the selected users' profile links before deleting those users.
- Added Hotspot expiry detection and UM6 review candidates while retaining conservative UM7 end-time checks against the router clock.
- Added active/ended filters for User Manager sessions and prevented deletion of active UM session records from the session-history screen.

## V6 baseline

- Added native account creation for Hotspot, PPPoE and User Manager, package/profile creation, User Manager sessions, A4 voucher PDF, router information, reports, expiry review and guarded User Manager maintenance.

### V8 build repair (2026-11-07)
- Removed duplicate RouterOS byte parser conflicting with RouterStorage.kt.
- Corrected typed profile creation maps in Repository.kt.
- Preserved V8 user-facing behavior and Android app ID.
- Verified core Kotlin compilation; full Android APK build pending GitHub Actions.
