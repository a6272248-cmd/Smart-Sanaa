# Smart Sanaa Native Android V9 (source)

Latest V9 source and verification boundaries are documented in `docs/V9-RELEASE-STATUS.md`. GitHub CI requires the archive compatibility filename `Smart-Sanaa-V8-FIXED.zip` for the existing branch workflow. The internal application version is 0.9.0.

---

# Smart Sanaa — Native Android V8 source

Smart Sanaa V8 is a native Kotlin + Jetpack Compose Android client for MikroTik RouterOS v6 and v7. It connects directly through the native RouterOS API; it is not a WebView and it does not modify the PHP Smart Manager panel or router configuration during installation.

- Android application ID: `com.smartsanaa.manager` (unchanged)
- App label: `سمارت صنعاء` (unchanged)
- Version: `0.8.0` / versionCode `8`
- minSdk 26 · targetSdk 35 · compileSdk 36 · JDK 17 · Gradle 8.13

## Navigation and dashboard parity

- Bottom navigation follows the original order in RTL: الرئيسية، الكروت، العملاء، التقارير، الإعدادات.
- Side drawer: Hotspot, PPPoE, العملاء, معلومات الراوتر, التقارير, الكروت المنتهية, صيانة User Manager, الإعدادات, logout.
- The non-functional Smart AI Center and duplicate Cards/Packages/Sessions drawer entries are excluded. These tools remain reachable from the original bottom navigation and dashboard/report shortcuts.
- Home preserves the RouterOS/CPU/uptime row, original banner, three primary shortcuts (الرئيسية، إضافة كروت، العملاء), active Hotspot/PPPoE counts, total Hotspot accounts, User Manager total and router-information card at the bottom.
- Four quick actions remain: الباقات، الجلسات، الكروت المنتهية، مراجعة وتنظيف.
- Light/dark theme preference persists. Arabic RTL layout, supplied logo and banner are retained.

## Functional areas

- **Connection:** Native RouterOS API, v6 legacy challenge login, v7 login, independent TLS toggle, certificate/hostname validation, bounded framing and explicit connection errors.
- **Hotspot:** users, active clients, profiles, details, search, refresh, create, enable/disable, disconnect and bounded bulk operations.
- **PPPoE:** secrets, active sessions, profiles, details, search, refresh, create, enable/disable, disconnect and bounded bulk operations.
- **Customers:** opens User Manager by default and allows Hotspot/PPPoE/User Manager source selection.
- **User Manager:** automatic v6/v7 path/capability discovery, user/profile/session lists, user creation, voucher creation, v6 customer scoping and version-specific maintenance.
- **Cards:** Hotspot and User Manager card lists, local search, 25/50/100/200-row paging, page-limited selection and confirmed bulk actions (maximum 100 IDs per operation).
- **Bulk deletion safety:** exact RouterOS IDs are validated. For User Manager v7, only profile links belonging to selected users are removed before those exact users; unrelated users and links are untouched. The first command failure stops the sequence, and no automatic replay is performed.
- **Packages:** list and inspect Hotspot, PPPoE and User Manager profiles; create profiles with service-specific fields.
- **Sessions:** Hotspot/PPPoE active sessions and User Manager session history with all/active/ended filters. Active UM session records are not offered for deletion as a substitute for disconnecting a client.
- **Expired cards:** Hotspot expiry is detected only when positive `limit-uptime` is reached; UM7 requires a `Used` assignment with a known past end-time compared with the router clock; UM6 results remain review-only where an expiry timestamp cannot be proven. Hotspot bulk actions disable/delete selected cards; UM7 removes only selected profile assignments, not user accounts.
- **Maintenance:** database size with UM6 full-print fallback, free disk space, available database timestamps, UMB backup list with confirmed exact-file deletion, standalone verified backup, backup-before-maintenance, UM6 rebuild plus rebuild-log, UM7 optimize-db, extended maintenance command timeouts and a direct button to the expired-cards page. Maintenance requires confirmation and a verified backup first.
- **Reports/device:** actual RouterOS service counts, active sessions, system logs (with password/token-like values redacted), system information, memory/storage and interface data. No fabricated sales or revenue figures are shown.
- **Security:** password fields are excluded from list/detail projections. Router credentials are stored using Android Keystore AES-GCM.

## Voucher creation and A4 PDF

- Preview is generated locally before any router write. Existing usernames are checked first; only after confirmation are vouchers created.
- Supports Hotspot/User Manager, profile, Hotspot server, UM6 customer, UM7 group, shared users, quantity (1–100 per batch), username length, prefix and numeric/lowercase/uppercase/mixed character sets.
- Vouchers are created username-only with an empty password to match the original panel's generation behavior. Confirm the target Hotspot/User Manager authentication policy allows this before distributing cards.
- Partial or ambiguous API outcomes stop the batch. No blind retry is performed, and only confirmed created usernames are included in the PDF.
- A4 defaults match the original panel: 4 columns × 20 rows, card size 52.2 × 14.47 mm, 0.4 mm gap and zero margin. Supports custom background image, username position/size, optional serial numbers, price label and page-range export.

## Validation and limits

- Pure Kotlin RouterOS/repository/privacy/dashboard/expiry/print-layout sources compile locally with Kotlin 1.9.
- Targeted checks pass for A4 80-card RTL geometry and Hotspot/UM6 expiry rules.
- Full Android Compose compilation, unit tests, Android Lint, APK assembly, signature and checksum must run in GitHub Actions or Android Studio. This workspace has no Android SDK or Gradle dependency cache.
- No emulator, physical Android phone or live MikroTik v6/v7 router is attached. CI success is not proof of phone or live-router integration.
- The current repository workflow produces a debug APK. In-place upgrades require the same signing certificate as the installed APK. Do not uninstall a working app until signing compatibility and data preservation are confirmed.

## Replacing the repository source archive

The existing workflow on `feature/smart-manager-enterprise-v4` watches the exact file path `Smart-Sanaa-V5-Android-Source.zip` and expects a top-level folder named `Smart-Sanaa-V5-Android-Source`. This V8 replacement intentionally retains both names. Replace the entire existing ZIP under that same filename on the feature branch; do not rename the file, rename the workflow or edit individual Kotlin files in GitHub. Run Actions and verify tests, lint, APK package/version, signature and SHA-256 before installing or merging. Do not push to `main` or merge the open PR until the new run and authorized device/router tests pass.
