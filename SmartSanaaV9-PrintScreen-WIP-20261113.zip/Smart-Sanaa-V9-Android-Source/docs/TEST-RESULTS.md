# V8 verification record — 2026-11-07

| Check | Result | Evidence / status |
|---|---|---|
| Pure Kotlin compile | PASS | `RouterOs.kt`, `Repository.kt`, `Privacy.kt`, `DashboardCounts.kt`, `ExpiryPolicy.kt`, `PrintLayout.kt` compiled with Kotlin 1.9 and bundled coroutines runtime. |
| A4 geometry | PASS | 4×20 cards at 52.2×14.47 mm with 0.4 mm gap and zero margin fit the A4 210×297 mm sheet exactly; first card is rightmost for RTL. |
| Expiry policy | PASS | Hotspot limit-uptime boundaries and UM6 review-candidate behavior executed in a local Kotlin check. |
| Log privacy | CODE REVIEW / LOCAL CHECK | `message` is displayed in reports after redacting password/secret/token/API-key-like values; credential fields remain excluded. |
| RouterOS v6 context | CODE REVIEW | Discovery probe and UM6 read/write paths use customer=admin by default while allowing the selected customer during user creation. Requires live UM6 verification. |
| Maintenance safety | CODE REVIEW | Backup is saved and verified before rebuild/optimize; exact-ID delete is limited to listed UMB files; free-space check is applied when the router returns parseable sizes; database commands use a 180-second socket/read timeout; no automatic retry. Requires authorized live-router test. |
| Expired bulk operations | CODE REVIEW | Maximum 100 exact IDs per operation; UM7 removes only profile links; UM6 remains read-only for uncertain expiry. Requires live-router test. |
| Voucher batch safety | CODE REVIEW | Local preview and existing-name check precede writes; only confirmed creations are exported; a partial/ambiguous failure stops the batch without replay. |
| Local Kotlin test suite (21 cases) | PASS | RouterOS wire framing, secret redaction, expiry safeguards, storage units, unique voucher codes and A4 RTL template; see `docs/LOCAL-UNIT-TESTS.txt`. These are not Android instrumented tests. |
| Android Compose compile | PENDING | Must run in GitHub Actions with Android Gradle Plugin and Compose dependencies. |
| Android unit tests | PENDING | Run `:app:testDebugUnitTest` in GitHub Actions. |
| Android Lint | PENDING | Run `:app:lintDebug` in GitHub Actions. |
| APK assembly / signature / package / SHA-256 | PENDING | Requires Android SDK and Gradle dependencies in GitHub Actions. Last V5 run #11 signer SHA-256: `e1ebaca7c7526c54fe8e46702345e27ae941d6073f2309c6dc5d909353f34b95`; V4 run #9 signer SHA-256 differed (`5538bd1f4f55391f3275f325d3420dc4f4f8cd519d2c25d498b7d2ebd47e3a69`). Current debug signing is not stable across runs. |
| Emulator / physical Android | NOT RUN | No Android device/emulator attached to this workspace. |
| Live RouterOS v6/v7 | NOT RUN | No authorized test router connected; no live router mutations were performed in this handoff. |

Do not label V8 production-verified until CI, install/update signing compatibility, and authorized live-router tests pass.
