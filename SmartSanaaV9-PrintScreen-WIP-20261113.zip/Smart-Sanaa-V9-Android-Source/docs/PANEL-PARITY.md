# Original Smart Manager screen parity — V8

| Original panel/app area | Native Android location | Behavior |
|---|---|---|
| Main dashboard | Home | RouterOS/CPU/uptime, original banner, primary shortcuts, live Hotspot/PPPoE counters, Hotspot total, User Manager total, quick access and router information at the bottom. |
| Primary shortcuts | Home | الرئيسية، إضافة كروت، العملاء. |
| Hotspot | Drawer → Hotspot | Accounts / active clients / profiles; search, details, create, enable/disable and disconnect. |
| PPPoE | Drawer → PPPoE | Secrets / active sessions / profiles; search, details, create, enable/disable and disconnect. |
| Customers | Bottom navigation → العملاء; Drawer → العملاء | Opens User Manager by default; Hotspot, PPPoE and User Manager sources remain selectable. |
| Cards | Bottom navigation → الكروت | Hotspot and User Manager cards, search, paging, selection, bounded bulk actions and batch creation. |
| Add cards | Home primary shortcut | Preview unique usernames first, then confirm creation on the router; no write occurs during preview. |
| Packages | Home quick access → الباقات | Hotspot, PPPoE and User Manager profiles; create profile using service-specific fields. |
| Sessions | Home quick access / Reports | Hotspot and PPPoE active sessions; User Manager all/active/ended session history. |
| Active clients | Reports → المتصلون الآن | Opens the Hotspot active-clients tab directly. |
| Expired cards | Drawer / Home quick access / Reports / Maintenance button | Hotspot expiry from consumed limit-uptime; UM7 known past end-time; UM6 review-only candidates. Bulk actions are bounded and explicitly confirmed. |
| User Manager maintenance | Drawer → مراجعة وتنظيف | Database size and free space, backup list, create backup, verify backup before maintenance, version-specific repair with extended command timeout and direct expired-cards button. |
| Router information | Drawer → معلومات الراوتر and Home bottom card | Identity, model, RouterOS version, architecture, uptime, CPU, memory, storage and interfaces. |
| Reports | Bottom navigation / Drawer → التقارير | Actual service counts, active sessions, RouterOS system log and operational shortcuts; no invented sales figures. |
| Settings | Bottom navigation / Drawer → الإعدادات | Router API host/port, TLS, encrypted credential storage and persistent theme. |

The drawer excludes the non-functional Smart AI Center and does not duplicate Home, Cards, Packages or Sessions. Those tools remain reachable from the original bottom navigation and dashboard/report shortcuts. The app remains native Kotlin/Compose and connects directly to RouterOS; it is not a WebView wrapper.
