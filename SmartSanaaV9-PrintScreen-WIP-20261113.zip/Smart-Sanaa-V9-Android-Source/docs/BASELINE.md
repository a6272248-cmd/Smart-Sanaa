# Protected baseline and branch policy

Repository: https://github.com/a6272248-cmd/Smart-Sanaa

- Protected `main` baseline: `75dd55836a40d935941c558b3957bd38427d3e8b`.
- Active development branch: `feature/smart-manager-enterprise-v4`.
- Inspected branch head before this source handoff: `e4127fa29bfc074708a23d71255de150291a8be9`.
- Existing source archive watched by the bootstrap workflow: `Smart-Sanaa-V5-Android-Source.zip`.
- V5 baseline build: GitHub Actions run `42303023889` completed successfully (unit tests, Android lint, assembleDebug, signature/package/SHA-256 verification).
- V8 changes are packaged locally for review; no GitHub branch, PR, or `main` ref was modified in this handoff.
- No PHP panel, OpenWrt, modem, firewall, router configuration, database or production service was changed.

The replacement source archive must be uploaded to the same development branch and retain the watched filename and top-level project folder expected by `bootstrap-android.yml`. Do not merge the PR or publish an APK before V8 CI and device/router tests pass.
