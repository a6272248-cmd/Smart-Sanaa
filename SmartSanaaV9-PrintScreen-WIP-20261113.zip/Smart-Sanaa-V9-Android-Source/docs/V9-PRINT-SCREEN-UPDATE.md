# V9 — Add Cards and A4 print screen refinement (2026-11-13)

- Source: integrated V9 native Kotlin Android project.
- Main file changed: `app/src/main/java/com/smartsanaa/manager/Vouchers.kt`.
- Print configuration is now expanded by default and placed before A4 page preview in the same scrollable Add Cards screen.
- Consistent Arabic headings and field names for the print template, A4 dimensions, code position, serial and export.
- No RouterOS writing logic, batch numbering protection, API paths, or the user-facing printing permissions were changed.
- Preview-only names are never sent to PDF save/share/print: export only includes confirmed RouterOS-created cards.
- UI is built with Compose and existing Kotlin components, not a WebView.

## Tests
- `PrintLayout.kt` standalone Kotlin check: 80 RTL cards; A4 page bounds; reject overflowing configuration: PASS.
- Kotlin source balanced braces/section check and ZIP CRC/path/file checks: PASS.
- Android Compose compile, Gradle unit tests, Android lint, APK assembly and real-device testing: NOT RUN in this container (no Android SDK / Gradle installation).
- Dashboard at 10.11.0.5 is a private LAN address and could not be directly browsed from this environment; user-provided screenshots plus available V9 source were used.
- GitHub source and production router remain unchanged.
