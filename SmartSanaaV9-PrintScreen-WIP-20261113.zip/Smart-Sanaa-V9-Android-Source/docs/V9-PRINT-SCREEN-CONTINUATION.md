# Smart Sanaa V9 — print-screen continuation — 2026-11-13

Work-in-progress source only. Not a signed or fully tested release.

- Started from `SmartSanaaV9-PrintScreen-Updated-Source.zip`; the existing RouterOS v6/v7 create operation, A4 PDF rendering, verified-only print/save/share, persisted serial reservations and page navigation remain in place.
- Improved voucher preview: drag the sample number directly across the chosen card image, changing the same X/Y percent values used by the real PDF export. Position can also be adjusted by existing sliders; exact final appearance is shown in the rendered A4 PDF preview.
- Invalid image selections no longer overwrite the previously working background. Successfully replaced app-local old template files are cleaned up.
- `PrintLayout.kt` and `SerialRangePolicy.kt` compiled/executed with the local Kotlin compiler; 7 geometry and serial checks passed. Four code-level integration assertions passed; archive CRC test pending after packaging.
- Android SDK/Gradle unavailable locally. No APK, emulator test, phone printing test, or live MikroTik v6/v7 write test was performed. This source is not verified as fully buildable.
- Source not pushed to GitHub; main branch and installed application untouched.
