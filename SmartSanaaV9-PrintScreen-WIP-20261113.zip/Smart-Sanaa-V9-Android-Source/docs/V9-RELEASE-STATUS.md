# Smart Sanaa V9 — integrated Native Android source (2026-11-08)

## What was changed
- Unified V9 sidebar and V9 voucher-preview work in one native Kotlin Android source tree.
- Drawer: Home, Add Cards, Card Operations and Reports only. Kept all other internal functions navigable from dashboard, reports and administrator settings.
- Administrator card: editable name, phone, optional Telegram handle; WhatsApp numbers validated, no fabricated Telegram account.
- Dashboard: short RouterOS model/image/CPU/memory/disk/uptime card, full information behind the Details button. Live CPU/resource polling from RouterOS `/system/resource/print` every 5 seconds **while Home is visible**. Hotspot/PPPoE/User Manager metric cards open their real management destinations.
- Card Operations: four navigation controls (all, active, expired, sessions), service chips (Hotspot / User Manager 6 or 7 as detected), search, compact rows, 100 rows per page initially, selection and confirmed enable/disable/delete. Existing RouterOS operations and safe interruption handling are retained.
- Add Cards: preserved the V9 native A4 PDF-preview+print flow with RTL 4 × 20 vouchers, per-batch sequence, confirmation before writing, PDF save/print/share only for successfully created users. Serial protection is **local-device-only**.
- `applicationId=com.smartsanaa.manager`, Android native (no WebView), app icon and Arabic name preserved. `versionCode=9`, `versionName=0.9.0`.

## Verification (evidence)
- Local Kotlin core+tests: **28 pass / 0 fail** using a temporary JUnit-compatible runner and locally available `kotlinc`, including new admin contact tests; official JUnit through Gradle **not run** locally.
- Source differences checked: RouterOs.kt, UserCreator.kt, SecureConfig.kt, MaintenanceAndExpired.kt, PrintLayout.kt, Privacy.kt, ExpiryPolicy.kt unchanged from V8. Repository.kt gains only the resource polling method; Vouchers.kt preserves V9 Add Cards commits.
- `git diff --check`: PASS.
- ZIP archive content, CRC, path safety, required Android files, checksums: validated on packaging.
- Android Gradle compile, Compose type-check, Android lint, `assembleDebug`, APK signature, emulator/phone, and live MikroTik v6/v7: **not verified in this environment** (SDK/Gradle not available and network inaccessible). Do not call the app production tested yet.
- Local git branch: `feature/v9-integrated`, original `main` untouched. No GitHub push or router modifications performed.

## Critical checks after uploading
1. Upload the source ZIP as `Smart-Sanaa-V8-FIXED.zip` to the existing `feature/smart-manager-enterprise-v4` branch, replacing **only** the prior ZIP of that same name. This name is an external compatibility shim because the installed GitHub `bootstrap-android.yml` listens only for that path. **The archive's project version is V9**, despite the legacy filename/workflow display name.
2. In GitHub Actions, run `Smart Sanaa V8 - Native Android APK` and check unit tests, lint, `assembleDebug`, signature, package, artifact SHA. If any step fails, inspect that specific step's diagnostics; do not treat ZIP verification as APK success.
3. Installing over an existing Android build requires the **same signing certificate**. GitHub's fresh debug signing key may differ from the installed APK; do not uninstall without first protecting stored app connection settings and private data.
4. Test both RouterOS 6 and 7, network loss and ambiguous batch result, RTL phone layouts, A4 template alignment, native PDF, live CPU and admin contacts on a real device. RouterOS mutations require authorization.
