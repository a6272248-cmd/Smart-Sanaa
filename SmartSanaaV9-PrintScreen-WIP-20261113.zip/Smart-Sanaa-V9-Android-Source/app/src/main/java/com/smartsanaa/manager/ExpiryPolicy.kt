package com.smartsanaa.manager

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Locale

/** Conservative expiry classification: unknown or unparsable dates are never treated as expired. */
object ExpiryPolicy {
    private val unknown = setOf("", "unknown", "غير معروف", "not set", "none", "never", "—", "-", "لم يحدد", "غير محدد")
    private val formats = listOf(
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH),
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm", Locale.ENGLISH),
        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss", Locale.ENGLISH),
        DateTimeFormatter.ofPattern("MMM/d/yyyy HH:mm:ss", Locale.ENGLISH),
        DateTimeFormatter.ofPattern("MMM/dd/yyyy HH:mm:ss", Locale.ENGLISH),
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss", Locale.ENGLISH)
    )

    fun isUnknownExpiry(text: String?): Boolean = text == null || text.trim().lowercase(Locale.ROOT) in unknown

    /** Parse RouterOS durations such as 1w2d3h4m5s without accepting partial garbage. */
    fun durationSeconds(text: String?): Long? {
        if (isUnknownExpiry(text)) return null
        val value = text!!.trim().lowercase(Locale.ROOT)
        if (value == "0" || value == "0s") return 0L
        val matches = Regex("(\\d+)(w|d|h|m|s)").findAll(value).toList()
        if (matches.isEmpty() || matches.joinToString("") { it.value } != value) return null
        var total = 0L
        for (match in matches) {
            val amount = match.groupValues[1].toLongOrNull() ?: return null
            val multiplier = when (match.groupValues[2]) {
                "w" -> 604800L; "d" -> 86400L; "h" -> 3600L; "m" -> 60L; "s" -> 1L; else -> return null
            }
            total = try { Math.addExact(total, Math.multiplyExact(amount, multiplier)) } catch (_: ArithmeticException) { return null }
        }
        return total
    }

    /** Hotspot is expired only when a positive limit-uptime has actually been consumed. */
    fun hotspotExpired(row: Map<String, String>): Boolean {
        val limit = durationSeconds(row["limit-uptime"]) ?: return false
        val used = durationSeconds(row["uptime"]) ?: return false
        return limit > 0L && used >= limit
    }

    /** RouterOS v6 UM exposes no reliable end timestamp here; this is a review candidate only. */
    fun um6ExpiryCandidate(row: Map<String, String>): Boolean {
        val profile = row["actual-profile"].orEmpty().trim()
        val used = durationSeconds(row["uptime-used"]) ?: return false
        return profile.isEmpty() && used > 0L
    }

    fun parseDateTime(text: String?): LocalDateTime? {
        if (isUnknownExpiry(text)) return null
        val value = text!!.trim()
        val normalizedMonth = value.replaceFirstChar { it.uppercase(Locale.ENGLISH) }
        for (format in formats) {
            try { return LocalDateTime.parse(normalizedMonth, format) } catch (_: DateTimeParseException) { }
        }
        return null
    }

    /** User Manager v7 marks consumed assignments as used; date must also be known and in the past. */
    fun v7Expired(row: Map<String, String>, now: LocalDateTime = LocalDateTime.now()): Boolean {
        if (!row["state"].orEmpty().equals("used", ignoreCase = true)) return false
        val end = parseDateTime(row["end-time"]) ?: return false
        return end.isBefore(now)
    }

    /** Kept for compatibility with earlier tests; it is not sufficient on its own to delete a card. */
    fun v7ProfileUsed(row: Map<String, String>): Boolean =
        row["state"]?.trim()?.equals("used", ignoreCase = true) == true && !isUnknownExpiry(row["end-time"])

    /** Automatic deletion is never allowed. Each assignment must be shown and confirmed individually. */
    fun autoDeleteAllowed(): Boolean = false
}
