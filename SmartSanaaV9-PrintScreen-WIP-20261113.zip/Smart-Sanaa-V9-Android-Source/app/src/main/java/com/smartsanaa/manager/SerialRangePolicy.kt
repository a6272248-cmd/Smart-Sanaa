package com.smartsanaa.manager

/** Local, monotonic printable serial reservation. Does not claim router-wide coordination. */
object SerialRangePolicy {
    fun nextStart(first: Int, count: Int): Int {
        require(first > 0) { "رقم البداية يجب أن يكون موجبًا" }
        require(count > 0) { "الدفعة يجب أن تحتوي على كروت" }
        val next = first.toLong() + count
        require(next <= Int.MAX_VALUE) { "نطاق التسلسل خارج المدى" }
        return next.toInt()
    }
}
