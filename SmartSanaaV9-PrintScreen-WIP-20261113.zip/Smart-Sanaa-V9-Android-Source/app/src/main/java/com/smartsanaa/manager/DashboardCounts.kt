package com.smartsanaa.manager

/** null means not verified; it must never be shown as zero. */
data class LiveCount(val value: Long? = null, val reason: String? = null) {
    fun text(): String = value?.toString() ?: "—"
}

data class DashboardCounts(
    val hotspot: LiveCount = LiveCount(),
    val hotspotUsers: LiveCount = LiveCount(),
    val pppoe: LiveCount = LiveCount(),
    val userManager: LiveCount = LiveCount(),
    val userManagerActive: LiveCount = LiveCount()
) {
    val hasAnyFailure: Boolean get() = listOf(hotspot, hotspotUsers, pppoe, userManager, userManagerActive).any { it.reason != null }
}

/** All counters are read from RouterOS. Missing permissions/data stay unavailable, never zero. */
suspend fun RouterRepository.dashboardCounts(): DashboardCounts {
    suspend fun safeCount(path: String, query: List<String> = emptyList()): LiveCount = try {
        val count = count(path, query)
        if (count == null) LiveCount(reason = "الراوتر لم يرجع عددًا") else LiveCount(count)
    } catch (e: Exception) {
        LiveCount(reason = (e as? RouterOsException)?.kind?.name ?: "تعذر القراءة")
    }

    val umBase = um.path
    val umCount = umBase?.let { safeCount("$it/user/print") } ?: LiveCount(reason = um.status)
    val umActiveQuery = when {
        umBase == null -> emptyList()
        umBase.startsWith("/tool/") -> listOf("?status=start,interim")
        else -> listOf("?active=yes")
    }
    val umActive = umBase?.let { safeCount("$it/session/print", umActiveQuery) } ?: LiveCount(reason = um.status)

    return DashboardCounts(
        hotspot = safeCount("/ip/hotspot/active/print"),
        hotspotUsers = safeCount("/ip/hotspot/user/print"),
        pppoe = safeCount("/ppp/active/print"),
        userManager = umCount,
        userManagerActive = umActive
    )
}
