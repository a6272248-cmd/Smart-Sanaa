package com.smartsanaa.manager

import java.util.Locale

/** Parses RouterOS byte quantities such as 4.2KiB, 68.6 MiB or 1024. */
fun parseRouterBytes(value: String?): Long? {
    val raw = value?.trim()?.replace(",", "") ?: return null
    val match = Regex("^([0-9]+(?:\\.[0-9]+)?)\\s*(B|KiB|MiB|GiB|TiB|KB|MB|GB)?$", RegexOption.IGNORE_CASE).matchEntire(raw) ?: return null
    val amount = match.groupValues[1].toDoubleOrNull() ?: return null
    val unit = match.groupValues[2].uppercase(Locale.ROOT)
    val multiplier = when (unit) {
        "B", "" -> 1.0
        "KIB", "KB" -> 1024.0
        "MIB", "MB" -> 1024.0 * 1024.0
        "GIB", "GB" -> 1024.0 * 1024.0 * 1024.0
        "TIB" -> 1024.0 * 1024.0 * 1024.0 * 1024.0
        else -> return null
    }
    val bytes = amount * multiplier
    return bytes.takeIf { it.isFinite() && it >= 0.0 && it <= Long.MAX_VALUE.toDouble() }?.toLong()
}
