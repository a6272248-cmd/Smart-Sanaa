package com.smartsanaa.manager

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class PartialMaintenanceException(message: String) : IllegalStateException(message)

/** Reads the full legacy UM6 print row; v7 asks only for documented database fields. */
suspend fun RouterRepository.databaseInfo(): Map<String, String> {
    val base = um.path ?: return emptyMap()
    val path = "$base/database/print"
    val first = if (base.startsWith("/tool/")) {
        api.execute(path).data.firstOrNull().orEmpty()
    } else {
        api.execute(path, mapOf(".proplist" to "db-path,db-size,free-disk-space,enabled")).data.firstOrNull().orEmpty()
    }
    val fallback = if (!first["db-size"].isNullOrBlank() || !first["size"].isNullOrBlank()) {
        emptyMap()
    } else {
        runCatching { api.execute(path).data.firstOrNull().orEmpty() }.getOrDefault(emptyMap())
    }
    var merged = first + fallback
    if (merged["db-size"].isNullOrBlank() && merged["size"].isNullOrBlank()) {
        val projected = runCatching {
            api.execute(path, mapOf(".proplist" to "db-size,size,free-disk-space,db-path,db-usage,last-rebuild,last-backup,last-restore")).data.firstOrNull().orEmpty()
        }.getOrDefault(emptyMap())
        merged = merged + projected
    }
    if (!merged["free-disk-space"].isNullOrBlank()) return merged
    val resourceFree = runCatching {
        api.execute("/system/resource/print", mapOf(".proplist" to "free-hdd-space")).data.firstOrNull()?.get("free-hdd-space")
    }.getOrNull()
    return if (resourceFree.isNullOrBlank()) merged else merged + ("free-disk-space" to resourceFree)
}

suspend fun RouterRepository.databaseBackups(): List<Map<String, String>> =
    api.execute("/file/print", mapOf(".proplist" to ".id,name,size,creation-time")).data
        .filter { it["name"].orEmpty().endsWith(".umb", ignoreCase = true) }
        .map(Privacy::safe)
        .sortedWith(compareByDescending<Map<String, String>> { it["creation-time"].orEmpty() }.thenByDescending { it["name"].orEmpty() })

private suspend fun RouterRepository.saveVerifiedDatabaseBackup(): String {
    val base = um.path ?: error("User Manager غير متاح")
    val info = databaseInfo()
    val databaseSize = parseRouterBytes(info["db-size"] ?: info["size"])
    val freeSpace = parseRouterBytes(info["free-disk-space"])
    if (databaseSize != null && freeSpace != null) {
        val required = databaseSize + maxOf(1L * 1024L * 1024L, databaseSize / 4L)
        require(freeSpace >= required) {
            "المساحة الحرة غير كافية لنسخة آمنة. حجم القاعدة ${info["db-size"] ?: info["size"]} والمساحة الحرة ${info["free-disk-space"]}."
        }
    }
    val suffix = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS"))
    val name = "smart-sanaa-android-$suffix"
    api.execute("$base/database/save", mapOf("name" to name), timeoutMs = 180_000L)
    val files = api.execute("/file/print", mapOf(".proplist" to ".id,name,size"), listOf("?name=$name.umb")).data
    val verified = files.any { row ->
        row["name"] == "$name.umb" && !row["size"].isNullOrBlank() && row["size"] != "0"
    }
    if (!verified) throw IllegalStateException("لم يتم التحقق من ملف النسخة الاحتياطية؛ لم تبدأ الصيانة")
    return "$name.umb"
}

/** Backup is verified on the router before any maintenance command. No mutation is replayed. */
suspend fun RouterRepository.createDatabaseBackup(): String = saveVerifiedDatabaseBackup()

suspend fun RouterRepository.backupThenMaintain(): String {
    val base = um.path ?: error("User Manager غير متاح")
    val backupName = saveVerifiedDatabaseBackup()
    if (base.startsWith("/tool/")) {
        try {
            api.execute("$base/database/rebuild", timeoutMs = 180_000L)
        } catch (e: Exception) {
            throw PartialMaintenanceException("تم حفظ النسخة $backupName والتحقق منها، لكن إعادة بناء قاعدة UM6 لم تكتمل. افحص القاعدة قبل إعادة المحاولة. ${e.message}")
        }
        try {
            api.execute("$base/database/rebuild-log", timeoutMs = 180_000L)
        } catch (e: Exception) {
            throw PartialMaintenanceException("اكتمل rebuild لقاعدة User Manager 6 لكن rebuild-log لم يكتمل. النسخة المحفوظة: $backupName. افحص الراوتر قبل إعادة المحاولة. ${e.message}")
        }
        return "اكتمل بناء قاعدة User Manager 6 وإعادة بناء السجل. النسخة: $backupName"
    }
    try {
        api.execute("$base/database/optimize-db", timeoutMs = 180_000L)
    } catch (e: Exception) {
        throw PartialMaintenanceException("تم حفظ النسخة $backupName والتحقق منها، لكن تحسين قاعدة UM7 لم يكتمل. افحص القاعدة قبل إعادة المحاولة. ${e.message}")
    }
    return "اكتمل تحسين قاعدة User Manager 7. النسخة: $backupName"
}

@Composable
fun MaintenanceScreen(repo: RouterRepository?, connected: Boolean, openExpired: () -> Unit) {
    val scope = rememberCoroutineScope()
    var info by remember(repo) { mutableStateOf<Map<String, String>>(emptyMap()) }
    var backups by remember(repo) { mutableStateOf<List<Map<String, String>>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }
    var confirmMaintenance by remember { mutableStateOf(false) }
    var pendingBackupDelete by remember { mutableStateOf<Map<String, String>?>(null) }
    val base = repo?.um?.path

    suspend fun refreshData(r: RouterRepository) {
        runCatching { r.databaseInfo() }
            .onSuccess { info = it }
            .onFailure { result = it.message ?: "تعذرت قراءة معلومات القاعدة" }
        runCatching { r.databaseBackups() }
            .onSuccess { backups = it }
            .onFailure { result = it.message ?: "تعذرت قراءة النسخ الاحتياطية" }
    }

    fun refresh() {
        val r = repo ?: return
        scope.launch {
            busy = true
            refreshData(r)
            result = if (!info["db-size"].isNullOrBlank() || !info["size"].isNullOrBlank()) {
                "تم تحديث معلومات القاعدة والنسخ الاحتياطية"
            } else if (result.isBlank()) {
                "لم يرجع الراوتر حجم قاعدة البيانات؛ تحقق من صلاحيات User Manager ونسخة RouterOS."
            } else result
            busy = false
        }
    }

    fun createBackupOnly() {
        val r = repo ?: return
        scope.launch {
            busy = true
            result = "جار إنشاء النسخة والتحقق من وجودها على الراوتر…"
            runCatching { r.createDatabaseBackup() }
                .onSuccess { result = "تم إنشاء النسخة والتحقق منها: $it" }
                .onFailure { result = "تعذر إنشاء نسخة مؤكدة: ${it.message}" }
            refreshData(r)
            busy = false
        }
    }

    fun deleteBackup(file: Map<String, String>) {
        val r = repo ?: return
        val id = file[".id"] ?: return
        scope.launch {
            busy = true
            result = "جار حذف ملف النسخة المحدد…"
            runCatching { r.bulkRemoveRecords("/file", listOf(id)) }
                .onSuccess { outcome ->
                    result = if (outcome.complete) "تم حذف ملف النسخة ${file["name"] ?: "UMB"}." else "لم يكتمل حذف النسخة؛ افحص قائمة الملفات على الراوتر. ${outcome.detail}"
                }
                .onFailure { result = "تعذر حذف ملف النسخة: ${it.message}" }
            refreshData(r)
            busy = false
        }
    }

    fun runMaintenance() {
        val r = repo ?: return
        scope.launch {
            busy = true
            result = "جار حفظ النسخة والتحقق منها قبل بدء الصيانة…"
            runCatching { r.backupThenMaintain() }
                .onSuccess { result = it }
                .onFailure { result = "توقفت العملية أو لم تكتمل: ${it.message}. افحص حالة القاعدة والنسخة على الراوتر قبل أي إعادة محاولة." }
            refreshData(r)
            busy = false
        }
    }

    LaunchedEffect(repo, connected) { if (connected) refresh() }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageHeading("صيانة User Manager", "حجم القاعدة والنسخ الاحتياطية وأدوات الإصلاح") }
        item {
            PanelCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("حالة الخدمة", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Surface(
                        color = if (connected && base != null) Color(0xFFE1F5EC) else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            if (connected && base != null) "متاح" else "غير متصل",
                            Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                            color = if (connected && base != null) Color(0xFF16764B) else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(if (base?.startsWith("/tool/") == true) "User Manager 6" else if (base != null) "User Manager 7" else "User Manager", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                InfoLine("إصدار RouterOS", repo?.routerVersion ?: "—")
                InfoLine("مسار القاعدة", base ?: repo?.um?.status ?: "—")
                InfoLine("حجم القاعدة", info["db-size"]?.takeIf { it.isNotBlank() } ?: info["size"]?.takeIf { it.isNotBlank() } ?: "غير متاح من الراوتر")
                info["db-usage"]?.takeIf { it.isNotBlank() }?.let { InfoLine("نسبة الاستخدام", it) }
                InfoLine("المساحة الحرة", info["free-disk-space"]?.takeIf { it.isNotBlank() } ?: "غير متاحة")
                InfoLine("مسار التخزين", info["db-path"]?.takeIf { it.isNotBlank() } ?: "المسار الافتراضي")
                (info["last-rebuild"] ?: info["db-last-rebuild"])?.takeIf { it.isNotBlank() }?.let { InfoLine("آخر إعادة بناء", it) }
                (info["last-backup"] ?: info["db-last-backup"])?.takeIf { it.isNotBlank() }?.let { InfoLine("آخر نسخة احتياطية", it) }
                (info["last-restore"] ?: info["db-last-restore"])?.takeIf { it.isNotBlank() }?.let { InfoLine("آخر استعادة", it) }
                OutlinedButton(onClick = ::refresh, enabled = connected && !busy && base != null, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(7.dp)); Text(if (busy) "جار التحديث…" else "تحديث معلومات القاعدة")
                }
            }
        }
        item {
            PanelCard {
                Text("النسخ الاحتياطية", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("تُحفظ ملفات UMB على الراوتر، ولا تبدأ الصيانة إلا بعد التحقق من النسخة.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Button(onClick = ::createBackupOnly, enabled = connected && !busy && base != null, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Storage, null); Spacer(Modifier.width(8.dp)); Text("إنشاء نسخة احتياطية الآن")
                }
                if (backups.isEmpty()) Text("لم تُكتشف ملفات UMB محفوظة.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                backups.take(8).forEach { file ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(file["name"] ?: "ملف UMB", fontWeight = FontWeight.SemiBold)
                            Text("${file["size"] ?: "الحجم غير متاح"}${file["creation-time"]?.let { " · $it" }.orEmpty()}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { pendingBackupDelete = file }, enabled = !busy && !file[".id"].isNullOrBlank()) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "حذف النسخة", tint = Color(0xFFC94A54))
                        }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
        }
        item {
            PanelCard {
                Text("تنظيف الكروت", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Button(
                    onClick = openExpired,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFEFF1), contentColor = Color(0xFFAA3542)),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 15.dp)
                ) {
                    Icon(Icons.Default.EventBusy, null)
                    Spacer(Modifier.width(9.dp))
                    Text("فتح صفحة الكروت المنتهية", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.ArrowBack, null)
                }
            }
        }
        item {
            PanelCard {
                Text("صيانة قاعدة البيانات", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (base?.startsWith("/tool/") == true)
                        "ينشئ نسخة UMB ويتحقق منها، ثم يعيد بناء قاعدة User Manager 6 وسجلها."
                    else "ينشئ نسخة UMB ويتحقق منها، ثم ينفذ تحسين قاعدة User Manager 7.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = { confirmMaintenance = true }, enabled = connected && !busy && base != null,
                    modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC94A54))
                ) {
                    Icon(Icons.Default.Build, null); Spacer(Modifier.width(8.dp)); Text(if (busy) "جار التنفيذ…" else "نسخ احتياطي ثم صيانة")
                }
            }
        }
        if (result.isNotBlank()) item { Text(result, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }
    }

    if (confirmMaintenance) AlertDialog(
        onDismissRequest = { confirmMaintenance = false },
        title = { Text("تأكيد صيانة User Manager") },
        text = {
            Text(
                "سيُنشئ التطبيق نسخة UMB ويتحقق منها أولًا، ثم ينفذ صيانة قاعدة البيانات بحسب الإصدار. قد تتوقف المصادقة مؤقتًا. لا تغلق التطبيق أو الراوتر أثناء التنفيذ، ولا تكرر العملية إذا انقطع الاتصال؛ افحص النسخة وحالة القاعدة أولًا."
            )
        },
        confirmButton = {
            TextButton(onClick = { confirmMaintenance = false; runMaintenance() }, enabled = connected && !busy) {
                Text("تأكيد وبدء الصيانة", color = Color(0xFFC94A54))
            }
        },
        dismissButton = { TextButton(onClick = { confirmMaintenance = false }) { Text("إلغاء") } }
    )

    pendingBackupDelete?.let { file ->
        AlertDialog(
            onDismissRequest = { pendingBackupDelete = null },
            title = { Text("حذف النسخة الاحتياطية") },
            text = { Text("سيتم حذف ملف UMB المحدد فقط من ملفات الراوتر:\n${file["name"] ?: "UMB"}") },
            confirmButton = {
                TextButton(onClick = { pendingBackupDelete = null; deleteBackup(file) }, enabled = connected && !busy) {
                    Text("حذف الملف", color = Color(0xFFC94A54))
                }
            },
            dismissButton = { TextButton(onClick = { pendingBackupDelete = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun ExpiredScreen(repo: RouterRepository?, connected: Boolean) {
    val scope = rememberCoroutineScope()
    val base = repo?.um?.path
    var backend by remember(repo) { mutableStateOf("Hotspot") }
    var candidates by remember(repo) { mutableStateOf<List<Map<String, String>>>(emptyList()) }
    var allCount by remember(repo) { mutableStateOf<Int?>(null) }
    var expiredCount by remember(repo) { mutableStateOf<Int?>(null) }
    var selectedIds by remember(repo) { mutableStateOf<Set<String>>(emptySet()) }
    var batchPage by remember(repo) { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("") }
    var actionResult by remember { mutableStateOf("") }
    var actionWarning by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var pendingBulkAction by remember { mutableStateOf<String?>(null) }

    fun load(preserveActionResult: Boolean = false) {
        val r = repo ?: return
        if (!preserveActionResult) { actionResult = ""; actionWarning = false }
        if (backend == "User Manager" && base == null) {
            status = r.um.status
            return
        }
        scope.launch {
            busy = true
            candidates = emptyList()
            selectedIds = emptySet()
            batchPage = 0
            allCount = null
            expiredCount = null
            runCatching {
                when (backend) {
                    "Hotspot" -> {
                        val records = r.api.execute(
                            "/ip/hotspot/user/print",
                            mapOf(".proplist" to ".id,name,profile,uptime,limit-uptime,disabled,comment")
                        ).data
                        Triple(records, records.filter { ExpiryPolicy.hotspotExpired(it) }, "Hotspot")
                    }
                    else -> {
                        val currentBase = base ?: error(r.um.status)
                        if (currentBase.startsWith("/tool/")) {
                            val path = "$currentBase/user/print"
                            val records = r.api.execute(
                                path,
                                r.requestParams(path, mapOf(".proplist" to ".id,username,actual-profile,uptime-used,customer,disabled,comment"))
                            ).data
                            Triple(records, records.filter { ExpiryPolicy.um6ExpiryCandidate(it) }, "UM6")
                        } else {
                            val routerNow = r.routerNow() ?: error("تعذرت قراءة تاريخ ووقت الراوتر؛ لم يتم تصنيف أي كرت")
                            val path = "$currentBase/user-profile/print"
                            val records = r.api.execute(
                                path,
                                r.requestParams(path, mapOf(".proplist" to ".id,user,profile,end-time,state"))
                            ).data
                            Triple(records, records.filter { ExpiryPolicy.v7Expired(it, routerNow) }, "UM7 · $routerNow")
                        }
                    }
                }
            }.onSuccess { (records, expired, label) ->
                allCount = records.size
                expiredCount = expired.size
                candidates = expired.take(500)
                status = when (label) {
                    "Hotspot" -> "تم فحص ${records.size} حسابًا. يظهر فقط من استهلك حد limit-uptime كاملًا."
                    "UM6" -> "تم فحص ${records.size} مستخدمًا. هذه مرشحات مراجعة فقط؛ لا يُحذف أي حساب تلقائيًا من UM6."
                    else -> "${label}. تم فحص ${records.size} تخصيص؛ تظهر حالة Used ذات تاريخ انتهاء معروف وماضٍ بحسب ساعة الراوتر."
                }
                if (expired.size > 500) status += " عُرض أول 500 سجل؛ استخدم إدارة الكروت للبحث في البقية."
            }.onFailure { status = "تعذر فحص الكروت المنتهية: ${it.message}" }
            busy = false
        }
    }

    fun visibleIds(): Set<String> = candidates.drop(batchPage * 100).take(100)
        .mapNotNull { it[".id"]?.takeIf(String::isNotBlank) }.toSet()

    fun startBulk(action: String) {
        val allowed = visibleIds()
        if (selectedIds.isEmpty()) {
            status = "حدد كرتًا واحدًا على الأقل."
            return
        }
        if (selectedIds.size > 100 || !allowed.containsAll(selectedIds)) {
            status = "العملية الواحدة محدودة بـ 100 كرت من المجموعة الحالية."
            return
        }
        pendingBulkAction = action
    }

    fun executeBulk(action: String) {
        val r = repo ?: return
        val ids = selectedIds.toList()
        val currentBase = base
        scope.launch {
            pendingBulkAction = null
            busy = true
            var reloadAfter = false
            actionResult = "جار تنفيذ العملية على ${ids.size} كرت…"
            actionWarning = false
            runCatching {
                when (action) {
                    "disable" -> r.bulkSetDisabled("/ip/hotspot/user", ids, true)
                    "delete" -> r.bulkDeleteUsers("Hotspot", ids)
                    "unlink" -> r.bulkRemoveRecords("${currentBase ?: error("User Manager غير متاح")}/user-profile", ids)
                    else -> error("عملية غير معروفة")
                }
            }.onSuccess { outcome ->
                actionResult = if (outcome.complete) {
                    when (action) {
                        "disable" -> "تم تعطيل ${outcome.confirmedIds.size} كرت Hotspot."
                        "delete" -> "تم حذف ${outcome.confirmedIds.size} كرت Hotspot."
                        else -> "تمت إزالة ${outcome.confirmedIds.size} علاقة باقة منتهية؛ لم تُحذف حسابات المستخدمين."
                    }
                } else {
                    "تم تأكيد ${outcome.confirmedIds.size} من ${ids.size}. ${if (outcome.uncertain) "النتيجة الأخيرة غير مؤكدة؛ افحص الراوتر قبل إعادة المحاولة." else "راجع السجلات التي رفضها الراوتر."} ${outcome.detail}"
                }
                actionWarning = !outcome.complete
                selectedIds = emptySet()
                reloadAfter = outcome.complete
            }.onFailure {
                actionWarning = true
                actionResult = "لم تكتمل العملية: ${it.message}. افحص الراوتر قبل إعادة المحاولة."
            }
            busy = false
            if (reloadAfter) load(preserveActionResult = true)
        }
    }

    val selectableIds = visibleIds()
    val allVisibleSelected = selectableIds.isNotEmpty() && selectedIds.containsAll(selectableIds)

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageHeading("الكروت المنتهية", "فحص دقيق مع تحديد جماعي وعمليات آمنة") }
        item {
            PanelCard {
                Text("مصدر الفحص", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = backend == "Hotspot", onClick = { backend = "Hotspot"; candidates = emptyList(); allCount = null; expiredCount = null; selectedIds = emptySet(); batchPage = 0; status = ""; actionResult = ""; actionWarning = false }, label = { Text("Hotspot") })
                    FilterChip(selected = backend == "User Manager", onClick = { backend = "User Manager"; candidates = emptyList(); allCount = null; expiredCount = null; selectedIds = emptySet(); batchPage = 0; status = ""; actionResult = ""; actionWarning = false }, enabled = base != null, label = { Text(if (base?.startsWith("/tool/") == true) "User Manager 6" else "User Manager 7") })
                }
                Text(
                    when {
                        backend == "Hotspot" -> "يعتمد الفحص على limit-uptime مقابل uptime الفعلي."
                        base?.startsWith("/tool/") == true -> "نتائج UM6 مرشحة للمراجعة؛ لا يوجد تاريخ انتهاء موثوق في جميع السجلات."
                        else -> "يعتمد الفحص على حالة Used وتاريخ انتهاء معروف مقارنة بساعة الراوتر."
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall
                )
                InfoLine("السجلات المفحوصة", allCount?.toString() ?: "—")
                InfoLine("الكروت المنتهية / المرشحة", expiredCount?.toString() ?: "—")
                Button(onClick = { load() }, enabled = connected && !busy && (backend == "Hotspot" || base != null), modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(7.dp)); Text(if (busy) "جار الفحص…" else "فحص الكروت المنتهية")
                }
                if (status.isNotBlank()) Text(status, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                if (actionResult.isNotBlank()) Text(actionResult, color = if (actionWarning) Color(0xFFC94A54) else Color(0xFF16835A), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (candidates.isNotEmpty() && !(backend == "User Manager" && base?.startsWith("/tool/") == true)) item {
            PanelCard {
                val firstIndex = batchPage * 100 + 1
                val lastIndex = minOf((batchPage + 1) * 100, candidates.size)
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Checkbox(checked = allVisibleSelected, onCheckedChange = { checked -> selectedIds = if (checked) selectableIds else emptySet() })
                    Column(Modifier.weight(1f)) {
                        Text("تحديد النتائج $firstIndex–$lastIndex", fontWeight = FontWeight.Bold)
                        Text("المحدد: ${selectedIds.size} / 100", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (candidates.size > 100) Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    OutlinedButton(onClick = { batchPage = (batchPage - 1).coerceAtLeast(0); selectedIds = emptySet() }, enabled = batchPage > 0, modifier = Modifier.weight(1f)) { Text("السابق") }
                    Text("${batchPage + 1} / ${(candidates.size + 99) / 100}", modifier = Modifier.padding(horizontal = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedButton(onClick = { batchPage = (batchPage + 1).coerceAtMost((candidates.size - 1) / 100); selectedIds = emptySet() }, enabled = lastIndex < candidates.size, modifier = Modifier.weight(1f)) { Text("التالي") }
                }
                if (backend == "Hotspot") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { startBulk("disable") }, enabled = selectedIds.isNotEmpty() && !busy, modifier = Modifier.weight(1f)) { Text("تعطيل المحدد") }
                        Button(onClick = { startBulk("delete") }, enabled = selectedIds.isNotEmpty() && !busy, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC94A54))) { Text("حذف المحدد") }
                    }
                } else {
                    Button(onClick = { startBulk("unlink") }, enabled = selectedIds.isNotEmpty() && !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC94A54))) {
                        Icon(Icons.Default.DeleteOutline, null); Spacer(Modifier.width(7.dp)); Text("إزالة ربط الباقة المحدد")
                    }
                    Text("هذه العملية تزيل علاقة الباقة فقط، ولا تحذف حساب المستخدم.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        items(candidates, key = { it[".id"].orEmpty() }) { row ->
            val id = row[".id"].orEmpty()
            val username = row["name"] ?: row["username"] ?: row["user"] ?: "مستخدم غير معروف"
            PanelCard {
                if (!(backend == "User Manager" && base?.startsWith("/tool/") == true)) {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Checkbox(checked = id.isNotBlank() && id in selectedIds, enabled = id in selectableIds, onCheckedChange = { checked ->
                            if (id.isNotBlank() && id in selectableIds) selectedIds = if (checked) selectedIds + id else selectedIds - id
                        })
                        Text(username, fontWeight = FontWeight.Bold)
                    }
                } else Text(username, fontWeight = FontWeight.Bold)
                InfoLine("الباقة", row["profile"]?.takeIf { it.isNotBlank() } ?: row["actual-profile"]?.takeIf { it.isNotBlank() } ?: "غير محددة")
                when (backend) {
                    "Hotspot" -> {
                        InfoLine("الاستخدام", row["uptime"] ?: "—")
                        InfoLine("حد الاستخدام", row["limit-uptime"] ?: "—")
                    }
                    else -> if (base?.startsWith("/tool/") == true) {
                        InfoLine("الاستخدام المسجل", row["uptime-used"] ?: "—")
                        InfoLine("الحالة", "مرشح للمراجعة فقط")
                    } else InfoLine("تاريخ الانتهاء", row["end-time"] ?: "غير معروف")
                }
            }
        }
        if (candidates.isEmpty() && expiredCount != null && !busy) item {
            PanelCard { Text("لا توجد كروت منتهية أو مرشحة للمراجعة وفق شروط الفحص.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }

    pendingBulkAction?.let { action ->
        val count = selectedIds.size
        val title = when (action) { "disable" -> "تأكيد تعطيل الكروت"; "delete" -> "تأكيد حذف الكروت"; else -> "تأكيد إزالة تخصيصات الباقات" }
        val body = when (action) {
            "disable" -> "سيتم تعطيل $count حساب Hotspot المحدد فقط. يمكن إعادة تفعيله لاحقًا."
            "delete" -> "سيتم حذف $count حساب Hotspot المحدد نهائيًا. لا يمكن التراجع عن الحذف."
            else -> "سيتم إزالة $count علاقة باقة من User Manager 7 فقط. حسابات المستخدمين نفسها لن تُحذف."
        }
        AlertDialog(
            onDismissRequest = { pendingBulkAction = null },
            title = { Text(title) },
            text = { Text(body) },
            confirmButton = { TextButton(onClick = { executeBulk(action) }) { Text("تأكيد التنفيذ", color = Color(0xFFC94A54)) } },
            dismissButton = { TextButton(onClick = { pendingBulkAction = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
internal fun PanelCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        content = { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) }
    )
}

@Composable
internal fun PageHeading(title: String, subtitle: String = "") {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
        if (subtitle.isNotBlank()) Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
internal fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Text(value, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
}
