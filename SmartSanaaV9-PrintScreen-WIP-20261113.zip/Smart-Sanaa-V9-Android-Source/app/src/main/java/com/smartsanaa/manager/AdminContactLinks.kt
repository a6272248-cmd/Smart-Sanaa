package com.smartsanaa.manager

/** Validates outbound administrator contacts; no URL is opened unless configured. */
object AdminContactLinks {
    fun whatsApp(number: String): String? {
        val input = number.trim().replace(Regex("""[\s()+-]"""), "")
        if (!input.matches(Regex("[0-9]{9,15}"))) return null
        val international = when {
            input.startsWith("967") && input.length == 12 -> input
            input.length == 9 -> "967$input"
            else -> input
        }
        return "https://wa.me/$international"
    }

    fun telegram(handle: String): String? {
        val account = handle.trim().removePrefix("@").removePrefix("https://t.me/").removePrefix("http://t.me/")
        if (!account.matches(Regex("[A-Za-z][A-Za-z0-9_]{4,31}"))) return null
        return "https://t.me/$account"
    }
}
