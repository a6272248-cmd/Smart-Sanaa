package com.smartsanaa.manager

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

@Composable
fun UserCreatorScreen(
    repository: RouterRepository?,
    connected: Boolean,
    initialService: String,
    onCreated: (String, String) -> Unit,
    onCancel: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var service by remember { mutableStateOf(initialService.takeIf { it in listOf("Hotspot", "PPPoE", "User Manager") } ?: "Hotspot") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var profile by remember { mutableStateOf("") }
    var customer by remember { mutableStateOf("admin") }
    var group by remember { mutableStateOf("default") }
    var sharedUsers by remember { mutableStateOf("1") }
    var limitUptime by remember { mutableStateOf("") }
    var localAddress by remember { mutableStateOf("") }
    var remoteAddress by remember { mutableStateOf("") }
    var comment by remember { mutableStateOf("") }
    var profiles by remember { mutableStateOf<List<String>>(emptyList()) }
    var servers by remember { mutableStateOf<List<String>>(emptyList()) }
    var server by remember { mutableStateOf("all") }
    var serverMenu by remember { mutableStateOf(false) }
    var loadingProfiles by remember { mutableStateOf(false) }
    var loadingServers by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    LaunchedEffect(repository, connected, service, customer) {
        delay(350)
        profiles = emptyList()
        val repo = repository ?: return@LaunchedEffect
        if (!connected) return@LaunchedEffect
        val root = repo.profileRoot(service) ?: return@LaunchedEffect
        loadingProfiles = true
        val profileParams = if (service == "User Manager" && root.startsWith("/tool/")) mapOf(".proplist" to "name", "customer" to customer.ifBlank { "admin" }) else mapOf(".proplist" to "name")
        runCatching { repo.api.execute("$root/print", repo.requestParams("$root/print", profileParams)).data.mapNotNull { it["name"] }.distinct().sorted() }
            .onSuccess { profiles = it; if (profile !in it) profile = it.firstOrNull().orEmpty() }
            .onFailure { message = "تعذر تحميل الباقات: ${it.message}" }
        loadingProfiles = false
        if (service == "Hotspot") {
            loadingServers = true
            runCatching { repo.api.execute("/ip/hotspot/print", mapOf(".proplist" to "name")).data.mapNotNull { it["name"] }.distinct().sorted() }
                .onSuccess { servers = listOf("all") + it; if (server !in servers) server = "all" }
                .onFailure { message = "تعذر تحميل خوادم Hotspot: ${it.message}" }
            loadingServers = false
        } else {
            servers = emptyList()
            server = "all"
        }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageHeading("إضافة مستخدم جديد", "إنشاء حساب فعلي في Hotspot أو PPPoE أو User Manager") }
        item {
            PanelCard {
                Text("نوع الخدمة", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Hotspot", "PPPoE", "User Manager").forEach { item ->
                        FilterChip(selected = service == item, onClick = { service = item; message = "" }, enabled = item != "User Manager" || repository?.um?.path != null, label = { Text(item) })
                    }
                }
                UserField("اسم المستخدم", username) { username = it }
                OutlinedTextField(password, { password = it }, label = { Text("كلمة المرور") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
                if (service == "User Manager" && repository?.isRouterOsV6 == true) {
                    UserField("Customer (الافتراضي admin)", customer) { customer = it }
                    Text("RouterOS v6 يحتاج Customer. في v7 يستخدم التطبيق صيغة User Manager الجديدة تلقائيًا.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else if (service == "User Manager") {
                    UserField("مجموعة المستخدمين Group", group) { group = it }
                }
                if (service == "User Manager") UserField("عدد المستخدمين المتزامنين", sharedUsers) { sharedUsers = it }
                UserField("اسم الباقة (اختياري)", profile) { profile = it }
                if (loadingProfiles) LinearProgressIndicator(Modifier.fillMaxWidth())
                if (profiles.isNotEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        profiles.take(3).forEach { name -> FilterChip(selected = profile == name, onClick = { profile = name }, label = { Text(name) }) }
                    }
                }
                when (service) {
                    "Hotspot" -> {
                        Text("خادم Hotspot", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        androidx.compose.foundation.layout.Box {
                            OutlinedButton(onClick = { serverMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (server == "all") "كل الخوادم" else server, modifier = Modifier.weight(1f))
                            }
                            DropdownMenu(expanded = serverMenu, onDismissRequest = { serverMenu = false }) {
                                (listOf("all") + servers.filter { it != "all" }).distinct().forEach { item ->
                                    DropdownMenuItem(text = { Text(if (item == "all") "كل الخوادم" else item) }, onClick = { server = item; serverMenu = false })
                                }
                            }
                        }
                        if (loadingServers) LinearProgressIndicator(Modifier.fillMaxWidth())
                        UserField("حد الاستخدام مثال 1d أو 2h (اختياري)", limitUptime) { limitUptime = it }
                    }
                    "PPPoE" -> {
                        UserField("العنوان المحلي أو Pool (اختياري)", localAddress) { localAddress = it }
                        UserField("العنوان البعيد أو Pool (اختياري)", remoteAddress) { remoteAddress = it }
                    }
                }
                UserField("ملاحظات الحساب (اختياري)", comment) { comment = it }
                Button(
                    onClick = {
                        val repo = repository
                        if (repo == null || !connected) { message = "اتصل بالراوتر أولًا"; return@Button }
                        if (username.isBlank() || password.isBlank()) { message = "اسم المستخدم وكلمة المرور مطلوبان"; return@Button }
                        if (service == "User Manager" && repo.um.path == null) { message = repo.um.status; return@Button }
                        if (service == "User Manager" && sharedUsers.toIntOrNull()?.let { it > 0 } != true) { message = "عدد المستخدمين المتزامنين يجب أن يكون رقمًا موجبًا"; return@Button }
                        if (service == "Hotspot" && limitUptime.isNotBlank() && ExpiryPolicy.durationSeconds(limitUptime)?.let { it > 0L } != true) { message = "اكتب حد استخدام صحيحًا مثل 1d أو 2h30m"; return@Button }
                        if (profile.isNotBlank() && profiles.isNotEmpty() && profile !in profiles) { message = "اختر باقة موجودة على الراوتر"; return@Button }
                        busy = true
                        message = "جار التحقق وإنشاء الحساب…"
                        val selectedService = service
                        val values = buildMap {
                            put("username", username.trim())
                            put("password", password)
                            if (profile.isNotBlank()) put("profile", profile)
                            if (comment.isNotBlank()) put("comment", comment)
                            if (service == "User Manager") {
                                put("customer", customer.ifBlank { "admin" })
                                put("group", group.ifBlank { "default" })
                                put("shared-users", sharedUsers.ifBlank { "1" })
                            }
                            if (service == "Hotspot") {
                                if (limitUptime.isNotBlank()) put("limit-uptime", limitUptime)
                                if (server.isNotBlank() && server != "all") put("server", server)
                            }
                            if (service == "PPPoE") {
                                if (localAddress.isNotBlank()) put("local-address", localAddress)
                                if (remoteAddress.isNotBlank()) put("remote-address", remoteAddress)
                            }
                        }
                        scope.launch {
                            runCatching { repo.createUser(selectedService, values) }
                                .onSuccess { onCreated(selectedService, it) }
                                .onFailure { message = it.message ?: "تعذر إنشاء الحساب" }
                            busy = false
                        }
                    },
                    enabled = connected && !busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (busy) "جار الإنشاء…" else "إنشاء المستخدم على الراوتر") }
                OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("إلغاء والعودة") }
                if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun UserField(label: String, value: String, update: (String) -> Unit) {
    OutlinedTextField(value, update, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
}
