package com.smartsanaa.manager

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.*
import java.net.*
import java.security.MessageDigest
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.SSLSocket

// Never include credentials in generated toString output.
data class RouterConfig(val host: String = "", val port: Int = 8728, val username: String = "admin", val password: String = "", val tls: Boolean = false) {
    override fun toString() = "RouterConfig(tls=$tls, credentials=REDACTED)"
    fun validate() { require(host.isNotBlank() && !host.contains('/') && !host.any { it.isWhitespace() }) { "عنوان الراوتر غير صالح" }; require(port in 1..65535) { "المنفذ يجب أن يكون بين 1 و65535" }; require(username.isNotBlank()) { "اسم المستخدم مطلوب" } }
}
data class ApiResponse(val records: List<Map<String, String>>, val completion: Map<String,String> = emptyMap()) {
    val data get() = records.filter { it["!type"] == "!re" }
    val count get() = completion["ret"]?.toLongOrNull()
}
enum class ApiError { AUTH, DENIED, UNSUPPORTED, COMMAND, NETWORK, PROTOCOL, TLS }
class RouterOsException(val kind: ApiError, message: String): IOException(message)

/** Bounded native framing. Public for deterministic fragmented-stream tests. */
object RouterWire {
    const val MAX_WORD = 1_048_576
    private fun InputStream.byte(): Int = read().also { if (it < 0) throw EOFException() }
    fun writeLength(out: OutputStream, n: Int) {
        require(n >= 0)
        when {
            n < 0x80 -> out.write(n)
            n < 0x4000 -> { out.write((n shr 8) or 0x80); out.write(n and 255) }
            n < 0x200000 -> { out.write((n shr 16) or 0xC0); out.write((n shr 8) and 255); out.write(n and 255) }
            n < 0x10000000 -> { out.write((n shr 24) or 0xE0); for(s in intArrayOf(16,8,0)) out.write((n shr s) and 255) }
            else -> { out.write(0xF0); for(s in intArrayOf(24,16,8,0)) out.write((n shr s) and 255) }
        }
    }
    fun readLength(input: InputStream): Int {
        val a=input.byte()
        return when {
            a < 0x80 -> a
            a < 0xC0 -> ((a and 0x3F) shl 8) or input.byte()
            a < 0xE0 -> ((a and 0x1F) shl 16) or (input.byte() shl 8) or input.byte()
            a < 0xF0 -> ((a and 15) shl 24) or (input.byte() shl 16) or (input.byte() shl 8) or input.byte()
            a == 0xF0 -> (input.byte() shl 24) or (input.byte() shl 16) or (input.byte() shl 8) or input.byte()
            else -> throw RouterOsException(ApiError.PROTOCOL,"رد بروتوكول غير صالح")
        }.also { if(it < 0) throw RouterOsException(ApiError.PROTOCOL,"طول غير صالح") }
    }
    fun send(out: OutputStream, words: List<String>) { words.forEach { val b=it.toByteArray(Charsets.UTF_8); require(b.size<=MAX_WORD); writeLength(out,b.size);out.write(b) };out.write(0);out.flush() }
    fun receive(input: InputStream): List<String> {
        val words=mutableListOf<String>();var total=0
        while(true) { val n=readLength(input);if(n==0)return words
            total+=n
            if(n>MAX_WORD || total>4*MAX_WORD || words.size>=256) throw RouterOsException(ApiError.PROTOCOL,"رد أكبر من الحد الآمن")
            val bytes=ByteArray(n);DataInputStream(input).readFully(bytes);words+=String(bytes,Charsets.UTF_8)
        }
    }
    fun parse(words: List<String>): Map<String,String> = buildMap {
        put("!type",words.firstOrNull().orEmpty())
        words.drop(1).forEach { val v=it.removePrefix("=");val i=v.indexOf('=');if(i>0)put(v.substring(0,i),v.substring(i+1)) }
    }
    fun challenge(password: String, hex: String): String {
        require(hex.length==32 && hex.all { it.digitToIntOrNull(16)!=null })
        val bytes=hex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        return "00"+MessageDigest.getInstance("MD5").digest(byteArrayOf(0)+password.toByteArray(Charsets.UTF_8)+bytes).joinToString("") { "%02x".format(it.toInt() and 255) }
    }
}

/** One authenticated session, serialized requests; mutations are NEVER automatically replayed. */
class RouterOsApi(private val config: RouterConfig): Closeable {
    private val mutex=Mutex()
    @Volatile private var socket: Socket?=null
    private var serial=0L
    private var nextAttempt=0L
    private var failures=0
    private fun connect() {
        config.validate()
        if(System.nanoTime()<nextAttempt) throw RouterOsException(ApiError.NETWORK,"انتظر قليلًا قبل إعادة الاتصال")
        val plain=Socket();socket=plain
        try {
            plain.connect(InetSocketAddress(config.host.removeSurrounding("[","]"),config.port),6000);plain.soTimeout=10000;plain.keepAlive=true
            if(config.tls) {
                val ssl=(SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(plain,config.host.removeSurrounding("[","]"),config.port,true) as SSLSocket
                socket=ssl;ssl.soTimeout=10000
                ssl.sslParameters=ssl.sslParameters.apply { endpointIdentificationAlgorithm="HTTPS" };ssl.startHandshake()
            }
            var login=exchange(listOf("/login","=name=${config.username}","=password=${config.password}"),null,true)
            login.completion["ret"]?.let { challenge -> login=exchange(listOf("/login","=name=${config.username}","=response=${RouterWire.challenge(config.password,challenge)}"),null,true) }
            if(login.completion["ret"]!=null) throw RouterOsException(ApiError.AUTH,"فشلت المصادقة")
            failures=0
        } catch(e: Exception) { close();failures=(failures+1).coerceAtMost(5);nextAttempt=System.nanoTime()+(1L shl failures)*500_000_000L;throw e }
    }
    private fun exchange(words: List<String>, tag: String?, login: Boolean=false, timeoutMs: Long=30_000L): ApiResponse {
        val s=socket ?: throw EOFException();RouterWire.send(s.getOutputStream(),words)
        val rows=mutableListOf<Map<String,String>>();var error: RouterOsException?=null;var bytes=0L
        val deadline=System.nanoTime()+timeoutMs*1_000_000L
        while(true) {
            if(System.nanoTime()>deadline)throw SocketTimeoutException()
            val row=RouterWire.parse(RouterWire.receive(s.getInputStream()));val type=row["!type"]
            if(tag!=null && row[".tag"]!=tag)throw RouterOsException(ApiError.PROTOCOL,"علامة الرد لا تطابق الطلب")
            when(type) {
                "!trap" -> { val msg=row["message"].orEmpty().lowercase();val kind=when { login->ApiError.AUTH; "permission" in msg || "not enough" in msg ->ApiError.DENIED; "no such command" in msg || "bad command" in msg ->ApiError.UNSUPPORTED;else->ApiError.COMMAND }
                    error=RouterOsException(kind,when(kind){ApiError.AUTH->"فشلت المصادقة؛ تحقق من بيانات الدخول";ApiError.DENIED->"لا يملك الحساب صلاحية هذه العملية";ApiError.UNSUPPORTED->"الأمر غير متاح على هذا الجهاز";else->"رفض الراوتر العملية؛ تحقق من الحقول والخدمة"}) }
                "!fatal" -> throw RouterOsException(if(login)ApiError.AUTH else ApiError.NETWORK,"أنهى الراوتر الاتصال")
                "!done" -> { error?.let { throw it };return ApiResponse(rows,row) }
                "!empty" -> Unit
                "!re" -> { bytes+=row.entries.sumOf { it.key.length+it.value.length };if(rows.size>=50000 || bytes>16_000_000)throw RouterOsException(ApiError.PROTOCOL,"تجاوزت النتائج الحد الآمن؛ ضيق نطاق الاستعلام");rows+=row }
                else -> throw RouterOsException(ApiError.PROTOCOL,"نوع رد غير مدعوم")
            }
        }
    }
    suspend fun execute(
        path: String,
        params: Map<String,String> = emptyMap(),
        query: List<String> = emptyList(),
        timeoutMs: Long = 30_000L
    ): ApiResponse = withContext(Dispatchers.IO) {
        mutex.withLock {
            require(path.startsWith("/") && !path.any { it.isWhitespace() })
            require(query.all { it.startsWith("?") })
            require(timeoutMs in 1_000L..300_000L) { "مهلة RouterOS يجب أن تكون بين ثانية و300 ثانية" }
            try {
                if(socket==null)connect()
                val activeSocket = socket ?: throw EOFException()
                val previousTimeout = activeSocket.soTimeout
                activeSocket.soTimeout = timeoutMs.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                try {
                    val tag=(++serial).toString()
                    exchange(listOf(path)+params.map { "=${it.key}=${it.value}" }+query+".tag=$tag",tag,timeoutMs=timeoutMs)
                } finally {
                    if (socket === activeSocket && !activeSocket.isClosed) activeSocket.soTimeout = previousTimeout
                }
            } catch(e: Exception) {
                if(e !is RouterOsException || e.kind !in setOf(ApiError.COMMAND,ApiError.DENIED,ApiError.UNSUPPORTED))close()
                throw when(e) { is RouterOsException->e;is javax.net.ssl.SSLException->RouterOsException(ApiError.TLS,"فشل التحقق من شهادة TLS أو اسم المضيف");else->RouterOsException(ApiError.NETWORK,"انقطع الاتصال أو انتهت المهلة؛ أعد المحاولة يدويًا") }
            }
        }
    }
    override fun close() { val old=socket;socket=null;runCatching { old?.close() } }
}

object RouterCommands {
    fun list(screen: Screen, version7: Boolean, umPath: String? = null): String? = when (screen) {
        Screen.USERS, Screen.CARDS -> if (umPath != null && umPath.startsWith("/tool/")) "$umPath/user/print" else if (umPath != null) "$umPath/user/print" else "/ip/hotspot/user/print"
        Screen.PACKAGES -> if (umPath != null) "$umPath/profile/print" else "/ip/hotspot/user/profile/print"
        Screen.HOTSPOT -> "/ip/hotspot/active/print"
        Screen.PPPOE -> "/ppp/active/print"
        Screen.SESSIONS -> umPath?.plus("/session/print") ?: "/ip/hotspot/active/print"
        Screen.DEVICE -> "/interface/print"
        Screen.REPORTS -> "/log/print"
        else -> null
    }
}
