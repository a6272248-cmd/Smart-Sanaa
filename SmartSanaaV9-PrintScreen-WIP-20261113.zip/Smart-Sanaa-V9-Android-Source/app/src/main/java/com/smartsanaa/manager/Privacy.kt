package com.smartsanaa.manager

/** Positive field projection: RouterOS secrets never reach list, detail, or search UI. */
object Privacy {
    val fields = setOf(
        ".id", "name", "user", "username", "customer", "profile", "actual-profile", "group",
        "disabled", "running", "uptime", "uptime-used", "limit-uptime", "bytes-in", "bytes-out", "message",
        "rx-byte", "tx-byte", "address", "mac-address", "service", "rate-limit", "session-timeout",
        "idle-timeout", "validity", "time", "topics", "type", "mtu", "default-name", "caller-id",
        "local-address", "remote-address", "download-used", "upload-used", "shared-users", "transfer-limit",
        "starts-at", "ends-at", "end-time", "state", "comment", "last-logged-in", "last-seen",
        "total-uptime", "download", "upload", "started", "ended", "active", "user-address",
        "nas-ip-address", "nas-port-id", "nas-port-type", "terminate-cause", "status",
        "last-accounting-packet", "db-size", "free-disk-space", "db-path", "db-usage", "last-rebuild", "last-backup", "last-restore", "size", "creation-time", "name-for-users",
        "starts-when", "price", "override-shared-users", "download-limit", "upload-limit", "uptime-limit",
        "architecture-name", "board-name", "version", "cpu-load", "uptime", "free-memory", "total-memory",
        "free-hdd-space", "total-hdd-space", "identity", "actual-profile", "limit-bytes-total"
    )
    val sessionFields = setOf(
        ".id", "name", "user", "username", "profile", "address", "user-address", "ip-address", "user-ip", "host-ip",
        "mac-address", "caller-id", "uptime", "bytes-in", "bytes-out", "download", "upload", "download-used", "upload-used",
        "started", "from-time", "start-time", "ended", "active", "service", "nas-ip-address", "nas-port-id",
        "last-accounting-packet", "status", "terminate-cause"
    )
    val profileFields = setOf(
        ".id", "name", "name-for-users", "comment", "rate-limit", "shared-users", "session-timeout",
        "idle-timeout", "validity", "starts-when", "price", "override-shared-users", "local-address",
        "remote-address", "only-one", "download-limit", "upload-limit", "uptime-limit", "transfer-limit"
    )
    private val secretInLog = Regex("(?i)(password|secret|token|api[-_]?key)\\s*[:=]\\s*[^\\s,;]+")
    private fun redactLog(value: String): String = secretInLog.replace(value) { match -> "${match.groupValues[1]}=[REDACTED]" }
    fun safe(row: Map<String, String>) = row.filterKeys { it in fields || it in sessionFields || it in profileFields }
        .mapValues { (key, value) -> if (key == "message") redactLog(value) else value }
    fun display(row: Map<String, String>) = safe(row).filterKeys { it != ".id" }
}
