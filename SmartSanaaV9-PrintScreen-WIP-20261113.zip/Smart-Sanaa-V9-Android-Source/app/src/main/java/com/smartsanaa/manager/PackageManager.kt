package com.smartsanaa.manager

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun PackageCreatorScreen(
    repo: RouterRepository?,
    connected: Boolean,
    initialService: String,
    onCreated: (String, String) -> Unit,
    onCancel: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var service by remember { mutableStateOf(initialService) }
    var name by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var rateLimit by remember { mutableStateOf("") }
    var sharedUsers by remember { mutableStateOf("1") }
    var sessionTimeout by remember { mutableStateOf("") }
    var idleTimeout by remember { mutableStateOf("") }
    var localAddress by remember { mutableStateOf("") }
    var remoteAddress by remember { mutableStateOf("") }
    var onlyOne by remember { mutableStateOf("yes") }
    var validity by remember { mutableStateOf("1d") }
    var startsWhen by remember { mutableStateOf("first-auth") }
    var price by remember { mutableStateOf("0") }
    var overrideShared by remember { mutableStateOf("off") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    LazyPackageColumn {
        item { PageHeading("إضافة باقة جديدة", "إنشاء ملف تعريف فعلي على الراوتر المتصل") }
        item {
            PanelCard {
                Text("نوع الباقة", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Hotspot", "PPPoE", "User Manager").forEach { item ->
                        FilterChip(selected = service == item, onClick = { service = item }, enabled = item != "User Manager" || repo?.um?.path != null, label = { Text(item) })
                    }
                }
                PackageField("اسم الباقة", name) { name = it }
                when (service) {
                    "Hotspot" -> {
                        PackageField("حد السرعة مثال 2M/2M", rateLimit) { rateLimit = it }
                        PackageField("عدد الأجهزة المتزامنة", sharedUsers) { sharedUsers = it }
                        PackageField("مهلة الجلسة", sessionTimeout) { sessionTimeout = it }
                        PackageField("مهلة الخمول", idleTimeout) { idleTimeout = it }
                    }
                    "PPPoE" -> {
                        PackageField("حد السرعة مثال 4M/2M", rateLimit) { rateLimit = it }
                        PackageField("Local Address أو Pool", localAddress) { localAddress = it }
                        PackageField("Remote Address أو Pool", remoteAddress) { remoteAddress = it }
                        PackageField("مهلة الجلسة", sessionTimeout) { sessionTimeout = it }
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("اتصال واحد فقط", modifier = Modifier.weight(1f))
                            Switch(checked = onlyOne == "yes", onCheckedChange = { onlyOne = if (it) "yes" else "no" })
                        }
                    }
                    else -> {
                        PackageField("الاسم الظاهر للمشترك", displayName) { displayName = it }
                        PackageField("الصلاحية مثال 30d أو 1w", validity) { validity = it }
                        PackageField("السعر (بيانات تعريفية فقط)", price) { price = it }
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("تبدأ الصلاحية عند أول تسجيل دخول", modifier = Modifier.weight(1f))
                            Switch(checked = startsWhen == "first-auth", onCheckedChange = { startsWhen = if (it) "first-auth" else "assigned" })
                        }
                        Text("السعر هنا خاص بملف User Manager؛ لا يمثل عملية تحصيل أو إيرادًا مسجلًا.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Button(
                    onClick = {
                        val r = repo
                        if (r == null || !connected) { message = "اتصل بالراوتر أولًا"; return@Button }
                        if (name.isBlank()) { message = "أدخل اسم الباقة"; return@Button }
                        busy = true
                        message = "جار التحقق وإنشاء الباقة…"
                        val selectedService = service
                        val values = when (selectedService) {
                            "Hotspot" -> mapOf("name" to name, "rate-limit" to rateLimit, "shared-users" to sharedUsers, "session-timeout" to sessionTimeout, "idle-timeout" to idleTimeout)
                            "PPPoE" -> mapOf("name" to name, "rate-limit" to rateLimit, "local-address" to localAddress, "remote-address" to remoteAddress, "only-one" to onlyOne, "session-timeout" to sessionTimeout)
                            else -> mapOf("name" to name, "name-for-users" to displayName, "validity" to validity, "starts-when" to startsWhen, "price" to price, "override-shared-users" to overrideShared)
                        }
                        scope.launch {
                            runCatching { r.createProfile(selectedService, values) }
                                .onSuccess { onCreated(selectedService, "تم إنشاء باقة $name على $selectedService") }
                                .onFailure { message = "تعذر إنشاء الباقة: ${it.message}" }
                            busy = false
                        }
                    },
                    enabled = connected && !busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (busy) "جار الإنشاء…" else "إنشاء الباقة على الراوتر") }
                OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("رجوع") }
                if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun PackageField(label: String, value: String, update: (String) -> Unit) {
    OutlinedTextField(value, update, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
}

@Composable
private fun LazyPackageColumn(content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    androidx.compose.foundation.lazy.LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}
