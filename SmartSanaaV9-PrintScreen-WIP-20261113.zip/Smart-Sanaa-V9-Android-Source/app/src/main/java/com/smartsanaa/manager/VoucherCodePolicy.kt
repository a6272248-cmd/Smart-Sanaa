package com.smartsanaa.manager

import java.security.SecureRandom

/** Cryptographically strong username-only voucher codes, matching the original panel. */
object VoucherCodePolicy {
    private val random = SecureRandom()
    private const val DIGITS = "0123456789"
    private const val LOWER = "abcdefghjkmnpqrstuvwxyz23456789"
    private const val UPPER = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
    private const val MIXED = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789"

    fun generate(
        quantity: Int,
        totalLength: Int,
        prefix: String,
        type: String,
        existing: Set<String>
    ): List<String> {
        require(quantity in 1..100) { "عدد الكروت يجب أن يكون بين 1 و100 في الدفعة الواحدة" }
        require(totalLength in 3..18) { "طول اسم المستخدم يجب أن يكون بين 3 و18 خانة" }
        require(prefix.length < totalLength) { "طول البادئة يجب أن يكون أقل من طول اسم المستخدم" }
        require(prefix.matches(Regex("^[A-Za-z0-9_-]*$"))) { "البادئة تقبل الحروف الإنجليزية والأرقام والشرطة فقط" }
        val alphabet = when (type) {
            "lowercase" -> LOWER
            "uppercase" -> UPPER
            "mixed" -> MIXED
            else -> DIGITS
        }
        val names = linkedSetOf<String>()
        var attempts = 0
        while (names.size < quantity && attempts < quantity * 200) {
            attempts++
            val suffixLength = totalLength - prefix.length
            val suffix = buildString(suffixLength) {
                repeat(suffixLength) { append(alphabet[random.nextInt(alphabet.length)]) }
            }
            val candidate = prefix + suffix
            if (candidate !in existing && candidate !in names) names += candidate
        }
        require(names.size == quantity) { "تعذر توليد أسماء فريدة بهذه الإعدادات؛ زد طول الكود أو غيّر نوعه" }
        return names.toList()
    }
}
