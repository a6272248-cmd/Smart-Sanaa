package com.smartsanaa.manager

/** A4 geometry matching the Smart Manager card template; the first card is on the RTL right. */
object PrintLayout {
    const val A4_WIDTH_MM = 210f
    const val A4_HEIGHT_MM = 297f
    const val POINTS_PER_MM = 72f / 25.4f

    data class CardRect(val xMm: Float, val yMm: Float, val widthMm: Float, val heightMm: Float)

    fun page(
        columns: Int,
        rows: Int,
        cardWidth: Float,
        cardHeight: Float,
        margin: Float,
        gap: Float
    ): List<CardRect> {
        require(columns in 1..6) { "عدد الأعمدة يجب أن يكون من 1 إلى 6" }
        require(rows in 1..40) { "عدد الصفوف يجب أن يكون من 1 إلى 40" }
        require(cardWidth >= 20f && cardHeight >= 10f && margin >= 0f && gap >= 0f)
        require(2f * margin + columns * cardWidth + (columns - 1) * gap <= A4_WIDTH_MM + 0.0001f) {
            "تجاوز عرض الكروت مساحة ورقة A4"
        }
        require(2f * margin + rows * cardHeight + (rows - 1) * gap <= A4_HEIGHT_MM + 0.0001f) {
            "تجاوز ارتفاع الكروت مساحة ورقة A4"
        }
        return List(rows * columns) { index ->
            val column = columns - 1 - (index % columns)
            val row = index / columns
            CardRect(
                xMm = margin + column * (cardWidth + gap),
                yMm = margin + row * (cardHeight + gap),
                widthMm = cardWidth,
                heightMm = cardHeight
            )
        }
    }
}
