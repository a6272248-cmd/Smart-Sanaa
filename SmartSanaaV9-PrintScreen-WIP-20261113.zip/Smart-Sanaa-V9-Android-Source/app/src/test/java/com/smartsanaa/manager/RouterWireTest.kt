package com.smartsanaa.manager

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class RouterWireTest {
    @Test fun lengthRoundTrip() {
        listOf(0,1,127,128,16383,16384,1_000_000).forEach { n ->
            val out=ByteArrayOutputStream(); RouterWire.writeLength(out,n)
            assertEquals(n,RouterWire.readLength(ByteArrayInputStream(out.toByteArray())))
        }
    }
    @Test fun secretFieldsAreExcluded() {
        val safe=Privacy.display(mapOf("name" to "u","password" to "secret","otp-secret" to "x","profile" to "p"))
        assertEquals(mapOf("name" to "u","profile" to "p"),safe)
    }
    @Test fun sessionProjectionKeepsAddressAndStatusButNeverPassword() {
        val safe=Privacy.safe(mapOf("user" to "voucher01","ip-address" to "10.0.0.8","status" to "interim","password" to "secret"))
        assertEquals("10.0.0.8",safe["ip-address"])
        assertEquals("interim",safe["status"])
        assertFalse(safe.containsKey("password"))
    }
    @Test fun challengeHasExpectedPrefix() { assertTrue(RouterWire.challenge("pw","00112233445566778899aabbccddeeff").startsWith("00")) }
}
