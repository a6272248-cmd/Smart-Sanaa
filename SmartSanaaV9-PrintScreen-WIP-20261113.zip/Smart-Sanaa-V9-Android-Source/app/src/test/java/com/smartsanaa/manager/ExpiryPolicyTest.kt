package com.smartsanaa.manager

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDateTime

class ExpiryPolicyTest {
    @Test fun unknownDatesAreProtected() {
        listOf(null, "", "غير معروف", "unknown", "Not Set", "—", "لم يحدد").forEach {
            assertTrue("Unknown expiry should be protected: $it", ExpiryPolicy.isUnknownExpiry(it))
        }
    }

    @Test fun v7NeedsUsedStateAndKnownPastEndTime() {
        val now = LocalDateTime.of(2026, 11, 7, 12, 0)
        assertFalse(ExpiryPolicy.v7Expired(mapOf("state" to "used", "end-time" to "unknown"), now))
        assertFalse(ExpiryPolicy.v7Expired(mapOf("state" to "running", "end-time" to "2026-10-01 12:00:00"), now))
        assertFalse(ExpiryPolicy.v7Expired(mapOf("state" to "used", "end-time" to "2026-11-08 12:00:00"), now))
        assertTrue(ExpiryPolicy.v7Expired(mapOf("state" to "used", "end-time" to "2026-10-01 12:00:00"), now))
        assertTrue(ExpiryPolicy.v7Expired(mapOf("state" to "used", "end-time" to "oct/30/2026 08:00:34"), now))
        assertFalse(ExpiryPolicy.autoDeleteAllowed())
    }

    @Test fun oldV7PredicateStillProtectsUnknownDates() {
        assertFalse(ExpiryPolicy.v7ProfileUsed(mapOf("state" to "used", "end-time" to "unknown")))
        assertTrue(ExpiryPolicy.v7ProfileUsed(mapOf("state" to "used", "end-time" to "2026-10-01 12:00:00")))
    }

    @Test fun routerOsDurationParsingIsStrictAndBounded() {
        assertEquals(183845L, ExpiryPolicy.durationSeconds("2d3h4m5s"))
        assertEquals(604800L, ExpiryPolicy.durationSeconds("1w"))
        assertEquals(0L, ExpiryPolicy.durationSeconds("0s"))
        assertNull(ExpiryPolicy.durationSeconds("unknown"))
        assertNull(ExpiryPolicy.durationSeconds("2days"))
    }

    @Test fun hotspotExpiryRequiresLimitToBeReached() {
        assertTrue(ExpiryPolicy.hotspotExpired(mapOf("limit-uptime" to "1d", "uptime" to "1d2h")))
        assertFalse(ExpiryPolicy.hotspotExpired(mapOf("limit-uptime" to "1d", "uptime" to "23h")))
        assertFalse(ExpiryPolicy.hotspotExpired(mapOf("limit-uptime" to "0s", "uptime" to "3d")))
        assertFalse(ExpiryPolicy.hotspotExpired(mapOf("limit-uptime" to "unknown", "uptime" to "3d")))
    }

    @Test fun um6IsOnlyAReviewCandidateNotAnAutomaticDeletion() {
        assertTrue(ExpiryPolicy.um6ExpiryCandidate(mapOf("actual-profile" to "", "uptime-used" to "2h")))
        assertFalse(ExpiryPolicy.um6ExpiryCandidate(mapOf("actual-profile" to "default", "uptime-used" to "2h")))
        assertFalse(ExpiryPolicy.um6ExpiryCandidate(mapOf("actual-profile" to "", "uptime-used" to "unknown")))
        assertFalse(ExpiryPolicy.autoDeleteAllowed())
    }
}
