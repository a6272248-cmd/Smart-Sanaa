package com.smartsanaa.manager

import org.junit.Assert.*
import org.junit.Test

class RouterStorageTest {
    @Test fun parsesRouterOsDiskUnits() {
        assertEquals(4L * 1024L * 1024L, parseRouterBytes("4 MiB") ?: -1L)
        assertEquals((68.6 * 1024 * 1024).toLong(), parseRouterBytes("68.6MiB") ?: -1L)
        assertEquals(4096L, parseRouterBytes("4 KiB") ?: -1L)
        assertEquals(1024L, parseRouterBytes("1024") ?: -1L)
    }

    @Test fun rejectsUnknownOrNegativeSizes() {
        assertNull(parseRouterBytes("unknown"))
        assertNull(parseRouterBytes("-4 MiB"))
    }
}
