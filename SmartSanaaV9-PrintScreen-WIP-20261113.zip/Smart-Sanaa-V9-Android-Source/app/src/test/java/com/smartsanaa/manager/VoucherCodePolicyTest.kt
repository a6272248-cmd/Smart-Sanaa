package com.smartsanaa.manager

import org.junit.Assert.*
import org.junit.Test

class VoucherCodePolicyTest {
    @Test fun generatedCodesAreUniqueAndDoNotMatchExistingNames() {
        val existing = setOf("SM000001", "SM000002")
        val codes = VoucherCodePolicy.generate(80, 8, "SM", "numbers", existing)
        assertEquals(80, codes.size)
        assertEquals(80, codes.toSet().size)
        assertTrue(codes.all { it.length == 8 && it.startsWith("SM") && it.drop(2).all(Char::isDigit) })
        assertTrue(codes.none { it in existing })
    }

    @Test fun alphabetModesAndPrefixAreApplied() {
        val lower = VoucherCodePolicy.generate(10, 9, "ab-", "lowercase", emptySet())
        assertTrue(lower.all { it.startsWith("ab-") && it.drop(3).all { ch -> ch.isLowerCase() || ch.isDigit() } })
        val upper = VoucherCodePolicy.generate(10, 9, "", "uppercase", emptySet())
        assertTrue(upper.all { it.all { ch -> ch.isUpperCase() || ch.isDigit() } })
    }

    @Test(expected = IllegalArgumentException::class)
    fun quantityAboveSafeBatchLimitIsRejected() {
        VoucherCodePolicy.generate(101, 8, "", "numbers", emptySet())
    }

    @Test(expected = IllegalArgumentException::class)
    fun nonAsciiPrefixIsRejected() {
        VoucherCodePolicy.generate(1, 8, "سمارت", "numbers", emptySet())
    }
}
