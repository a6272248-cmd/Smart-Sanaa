package com.smartsanaa.manager

import org.junit.Assert.assertEquals
import org.junit.Test

class SerialRangePolicyTest {
    @Test fun eightyVouchersUseRange3911To3990() {
        assertEquals(3991, SerialRangePolicy.nextStart(3911, 80))
    }
    @Test(expected = IllegalArgumentException::class)
    fun startMustBePositive() { SerialRangePolicy.nextStart(0, 80) }
    @Test(expected = IllegalArgumentException::class)
    fun overflowIsRejected() { SerialRangePolicy.nextStart(Int.MAX_VALUE - 5, 80) }
}
