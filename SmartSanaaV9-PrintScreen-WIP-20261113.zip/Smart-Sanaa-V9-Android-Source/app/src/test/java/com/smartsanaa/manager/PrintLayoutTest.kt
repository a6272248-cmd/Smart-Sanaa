package com.smartsanaa.manager

import org.junit.Assert.*
import org.junit.Test

class PrintLayoutTest {
    @Test fun originalSmartManagerA4TemplateFitsExactly() {
        val cards = PrintLayout.page(4, 20, 52.2f, 14.47f, 0f, 0.4f)
        assertEquals(80, cards.size)
        assertEquals(157.8f, cards.first().xMm, 0.001f)
        assertEquals(0f, cards.first().yMm, 0.001f)
        cards.forEach {
            assertTrue(it.xMm >= 0f && it.yMm >= 0f)
            assertTrue(it.xMm + it.widthMm <= 210.001f)
            assertTrue(it.yMm + it.heightMm <= 297.001f)
        }
    }

    @Test fun firstVoucherStartsOnRightForRtl() {
        val cards = PrintLayout.page(3, 7, 61f, 37f, 10f, 2f)
        assertEquals(21, cards.size)
        assertTrue(cards.first().xMm > cards[1].xMm)
        assertTrue(cards[1].xMm > cards[2].xMm)
    }

    @Test(expected = IllegalArgumentException::class)
    fun invalidSizingIsRejected() {
        PrintLayout.page(4, 20, 54f, 14.47f, 0f, 0.4f)
    }

    @Test(expected = IllegalArgumentException::class)
    fun cardTooTallForA4IsRejected() {
        PrintLayout.page(4, 20, 52.2f, 15f, 0f, 0.4f)
    }
}
