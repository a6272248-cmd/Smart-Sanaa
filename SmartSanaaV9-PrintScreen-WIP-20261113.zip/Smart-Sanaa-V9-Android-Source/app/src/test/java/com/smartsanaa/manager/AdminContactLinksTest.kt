package com.smartsanaa.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AdminContactLinksTest {
    @Test fun localYemenNumberIsExpanded() {
        assertEquals("https://wa.me/967775070442", AdminContactLinks.whatsApp("775 070 442"))
    }
    @Test fun internationalNumberIsPreserved() {
        assertEquals("https://wa.me/967775070442", AdminContactLinks.whatsApp("+967 775-070-442"))
    }
    @Test fun malformedContactIsRejected() {
        assertNull(AdminContactLinks.whatsApp("abc@web"))
        assertNull(AdminContactLinks.whatsApp("123"))
    }
    @Test fun telegramIsOptionalAndValidated() {
        assertNull(AdminContactLinks.telegram(""))
        assertNull(AdminContactLinks.telegram("bad/path"))
        assertEquals("https://t.me/SmartSanaaOfficial", AdminContactLinks.telegram("@SmartSanaaOfficial"))
    }
}
