package com.smartsanaa.manager

import org.junit.Assert.*
import org.junit.Test

class PrivacyTest {
    @Test fun credentialsAreRemovedAndLogSecretsAreRedacted() {
        val safe = Privacy.safe(
            mapOf(
                ".id" to "*1",
                "name" to "router",
                "password" to "plain-secret",
                "message" to "login failed password=secret123 token=abc123 user=test"
            )
        )
        assertFalse(safe.containsKey("password"))
        assertTrue(safe["message"].orEmpty().contains("password=[REDACTED]"))
        assertTrue(safe["message"].orEmpty().contains("token=[REDACTED]"))
        assertFalse(safe["message"].orEmpty().contains("secret123"))
        assertFalse(safe["message"].orEmpty().contains("abc123"))
    }
}
