# Smart Manager Enterprise V4

- Protected baseline `75dd55836a40d935941c558b3957bd38427d3e8b`; work is isolated on `feature/smart-manager-enterprise-v4`.
- Added a reusable authenticated RouterOS session with bounded framing, tags, `!trap`/`!fatal`/`!empty`, v6 challenge handling, TLS hostname verification, timeout/backoff, and redacted errors.
- Added capability probing for User Manager and separate Hotspot, PPPoE, and User Manager paths. Permission and missing service states remain distinct.
- Added positive field projection and redacted detail views; passwords/secrets never enter the UI list or detail screen.
- Decoupled TLS from the port field and disallowed cleartext Android traffic by default.
- Added drawer navigation, responsive touch targets, source tabs, interface traffic refresh, and real-data unavailable states.
- Voucher creation uses one session and a batch UUID comment; partial results are reported instead of claiming success.

Known limits: emulator/device and RouterOS v6/v7 live tests were not available in this environment. PDF rendering still needs Android print/RTL validation. The APK is debug-signed unless a release key is supplied.
