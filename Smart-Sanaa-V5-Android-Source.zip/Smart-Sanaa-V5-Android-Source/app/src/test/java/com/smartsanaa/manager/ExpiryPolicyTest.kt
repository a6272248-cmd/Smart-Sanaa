package com.smartsanaa.manager

import org.junit.Assert.*
import org.junit.Test

class ExpiryPolicyTest {
    @Test fun unknownDatesAreProtected() {
        listOf(null, "", "غير معروف", "unknown", "Not Set", "—", "لم يحدد").forEach {
            assertTrue("Unknown expiry should be protected: $it", ExpiryPolicy.isUnknownExpiry(it))
        }
    }
    @Test fun v7NeedsUsedStateAndKnownEndTime() {
        assertFalse(ExpiryPolicy.v7ProfileUsed(mapOf("state" to "used", "end-time" to "unknown")))
        assertFalse(ExpiryPolicy.v7ProfileUsed(mapOf("state" to "running", "end-time" to "2026-10-01 12:00:00")))
        assertTrue(ExpiryPolicy.v7ProfileUsed(mapOf("state" to "used", "end-time" to "2026-10-01 12:00:00")))
        assertFalse(ExpiryPolicy.autoDeleteAllowed())
    }
}
