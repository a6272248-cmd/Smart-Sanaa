package com.smartsanaa.manager

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class RouterWireTest {
    @Test fun lengthRoundTrip() {
        listOf(0,1,127,128,16383,16384,1_000_000).forEach { n ->
            val out=ByteArrayOutputStream(); RouterWire.writeLength(out,n)
            assertEquals(n,RouterWire.readLength(ByteArrayInputStream(out.toByteArray())))
        }
    }
    @Test fun secretFieldsAreExcluded() {
        val safe=Privacy.display(mapOf("name" to "u","password" to "secret","otp-secret" to "x","profile" to "p"))
        assertEquals(mapOf("name" to "u","profile" to "p"),safe)
    }
    @Test fun challengeHasExpectedPrefix() { assertTrue(RouterWire.challenge("pw","00112233445566778899aabbccddeeff").startsWith("00")) }
}
