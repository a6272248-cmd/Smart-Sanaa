package com.smartsanaa.manager

import org.junit.Assert.*
import org.junit.Test

class PrintLayoutTest {
    @Test fun allCardsStayInsideA4() {
        val cards=PrintLayout.page(3,7,61f,37f,10f,2f)
        assertEquals(21,cards.size)
        assertTrue(cards.first().xMm > cards[1].xMm)
        cards.forEach { assertTrue(it.xMm>=0);assertTrue(it.yMm>=0);assertTrue(it.xMm+it.widthMm<=210);assertTrue(it.yMm+it.heightMm<=297) }
    }
    @Test(expected=IllegalArgumentException::class) fun invalidSizingIsRejected() {
        PrintLayout.page(3,7,70f,40f,10f,2f)
    }
}
