package com.smartsanaa.manager

/** Positive projection: unknown RouterOS fields must never reach a view or search index. */
object Privacy {
    val fields = setOf(".id", "name", "user", "username", "profile", "actual-profile", "group", "disabled", "running", "uptime", "limit-uptime", "bytes-in", "bytes-out", "rx-byte", "tx-byte", "address", "mac-address", "service", "rate-limit", "session-timeout", "validity", "time", "topics", "type", "mtu", "default-name", "caller-id", "local-address", "remote-address", "download-used", "upload-used", "shared-users", "transfer-limit", "starts-at", "ends-at")
    fun safe(row: Map<String, String>) = row.filterKeys { it in fields }
    fun display(row: Map<String, String>) = safe(row).filterKeys { it != ".id" }
}
