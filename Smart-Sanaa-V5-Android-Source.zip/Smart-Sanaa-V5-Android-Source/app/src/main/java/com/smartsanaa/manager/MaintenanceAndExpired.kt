package com.smartsanaa.manager

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/** Safe readback of native User Manager database properties; version-specific, no guessed values. */
suspend fun RouterRepository.databaseInfo(): Map<String, String> {
    val base = um.path ?: return emptyMap()
    return api.execute("$base/database/print").data.firstOrNull().orEmpty()
}

/** A write is issued only after a verified UMB backup and explicit in-app confirmation. No automatic retry. */
suspend fun RouterRepository.backupThenMaintain(): String {
    val base=um.path ?: error("User Manager غير متاح")
    val suffix=LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"))
    val name="smart-sanaa-android-$suffix"
    api.execute("$base/database/save", mapOf("name" to name))
    // Reject operation unless the router reports a real backup file in its filesystem.
    val files=api.execute("/file/print", mapOf(".proplist" to ".id,name,size"), listOf("?name=$name.umb")).data
    val found=files.any { file -> file["name"]=="$name.umb" && !file["size"].isNullOrBlank() && !file["size"].orEmpty().startsWith("0") }
    if(!found) throw IllegalStateException("لم يتم التحقق من ملف النسخة الاحتياطية؛ لم تبدأ الصيانة")
    if(base.startsWith("/tool/")) {
        api.execute("$base/database/rebuild")
        // If rebuild returned success, rebuild the log separately (v6 only).
        api.execute("$base/database/rebuild-log")
        return "اكتمل أمر إعادة بناء User Manager 6 والسجل. النسخة: $name.umb"
    }
    // V7 does not expose the old v6 rebuild commands; use the actual v7 optimize-db operation.
    api.execute("$base/database/optimize-db")
    return "اكتمل أمر تحسين قاعدة User Manager 7. النسخة: $name.umb"
}

@Composable
fun MaintenanceScreen(repo: RouterRepository?, connected: Boolean) {
    val scope=rememberCoroutineScope()
    var info by remember(repo) { mutableStateOf<Map<String,String>>(emptyMap()) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    val base=repo?.um?.path
    fun refresh() {
        val r=repo ?: return
        scope.launch { busy=true
            runCatching { r.databaseInfo() }.onSuccess { info=it;result=if(it.isEmpty())"تعذرت قراءة خصائص القاعدة" else "تمت القراءة من الراوتر" }
                .onFailure {result=it.message ?: "فشلت القراءة"}
            busy=false
        }
    }
    LaunchedEffect(repo,connected) {if(connected) refresh()}
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { Text("صيانة قاعدة بيانات User Manager",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold) }
        item { Card { Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
            Text(if(base==null) "User Manager غير متاح لهذا الاتصال" else if(base.startsWith("/tool/"))"User Manager 6" else "User Manager 7",fontWeight=FontWeight.Bold)
            Text("مسار القاعدة: ${base ?: "—"}")
            Text("حجم القاعدة: ${info["db-size"] ?: info["size"] ?: "غير متاح من API"}")
            Text("المساحة الحرة: ${info["free-disk-space"] ?: "غير متاح من API"}")
            OutlinedButton(onClick={refresh()},enabled=connected&&!busy) {Text("تحديث معلومات القاعدة")} }
        } }
        item { Card { Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Text("نسخة احتياطية وصيانة أصلية",fontWeight=FontWeight.Bold)
            Text("يحفظ ملف UMB على الراوتر ويتحقق منه قبل بدء إعادة البناء في الإصدار 6، أو تحسين القاعدة في الإصدار 7. قد تتوقف مصادقة المشتركين مؤقتًا.",style=MaterialTheme.typography.bodySmall)
            Button(onClick={confirm=true},enabled=connected&&!busy&&base!=null,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFC94A54))){Text(if(busy)"جار التنفيذ..." else "نسخ احتياطي ثم صيانة القاعدة")}
        } } }
        item { if(result.isNotBlank()) Text(result,color=MaterialTheme.colorScheme.onSurfaceVariant) }
    }
    if(confirm) AlertDialog(onDismissRequest={confirm=false},title={Text("تأكيد صيانة User Manager")},text={Text("سيُنشأ ملف UMB ويتم التحقق منه، ثم يُنفذ أمر الصيانة الحقيقي. قد ينقطع اتصال API أو مصادقة المشتركين. لا تكرر الأمر إذا انتهت مهلة الاتصال قبل التحقق من الراوتر.")},confirmButton={TextButton(onClick={confirm=false;val r=repo ?: return@TextButton;scope.launch {busy=true;runCatching{r.backupThenMaintain()}.onSuccess{result=it}.onFailure{result="تعذرت معرفة نتيجة الصيانة: ${it.message}. افحص الراوتر قبل أي إعادة محاولة"};busy=false}}){Text("تأكيد التنفيذ")}},dismissButton={TextButton(onClick={confirm=false}){Text("إلغاء")}})
}

@Composable
fun ExpiredScreen(repo: RouterRepository?, connected:Boolean) {
    val scope=rememberCoroutineScope()
    var candidates by remember(repo) { mutableStateOf<List<Map<String,String>>>(emptyList()) }
    var allCount by remember(repo) { mutableStateOf<Int?>(null) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val base=repo?.um?.path
    fun load() { val r=repo ?: return;val path=if(base?.startsWith("/tool/")==true)"$base/user/print" else "$base/user-profile/print"
        scope.launch {busy=true
            runCatching {r.api.execute(path,mapOf(".proplist" to if(base?.startsWith("/tool/")==true)".id,username,actual-profile,uptime-used,till-time" else ".id,user,profile,end-time,state")).data}
                .onSuccess {allCount=it.size; candidates=if(base?.startsWith("/tool/")==true)emptyList() else it.filter(ExpiryPolicy::v7ProfileUsed).take(200);status=if(base?.startsWith("/tool/")==true) "في RouterOS 6 يلزم فحص حالة انتهاء المستخدم من بيانات User Manager التفصيلية. الحذف التلقائي متوقف لحماية الكروت الجديدة." else "نتائج مستخدمي الملفات المستهلكة للمراجعة، وليست أمر حذف"}
                .onFailure{status="تعذرت القراءة: ${it.message}"}
            busy=false
        }
    }
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item{Text("الكروت المنتهية",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)}
        item{Card{Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("حماية الكروت الجديدة",fontWeight=FontWeight.Bold)
            Text("التاريخ «غير معروف» لا يعني انتهاء الكرت؛ لا يُحذف المستخدم تلقائيًا. الحذف يحتاج مراجعة مؤكدة لكل كرت.",style=MaterialTheme.typography.bodySmall)
            Button(onClick={load()},enabled=connected&&!busy&&base!=null,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Refresh,null);Text(" فحص User Manager")}
            Text("إجمالي السجلات المفحوصة: ${allCount ?: "—"}")
            if(status.isNotBlank())Text(status,style=MaterialTheme.typography.bodySmall)
        }}}
        items(candidates){row -> Card {Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text("المستخدم: ${row["user"] ?: "—"}",fontWeight=FontWeight.Bold)
            Text("الباقة: ${row["profile"] ?: "—"}")
            Text("آخر تاريخ: ${row["end-time"] ?: "غير معروف"}")
        }}}
        item{Text("لا توجد عملية حذف تلقائي في التطبيق قبل التحقق من ربط كل ملف منتهٍ بمستخدمه وسجلاته. استخدم صفحة الكروت المنتهية الموثوقة في لوحة الويب للحذف.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
    }
}
