package com.smartsanaa.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.launch
import java.time.LocalDateTime

private val Bg = Color(0xFFF5F8FC)
private val Surface = Color(0xFFFFFFFF)
private val Cyan = Color(0xFF1599D2)
private val Blue = Color(0xFF2563A8)
private val Muted = Color(0xFF5B6B7D)
private val Ink = Color(0xFF102A43)
private val Green = Color(0xFF22C55E)
private val Red = Color(0xFFEF4444)
private val Amber = Color(0xFFF59E0B)

enum class Screen(val arabic: String) {
    SPLASH("البداية"), LOGIN("تسجيل الدخول"), HOME("الرئيسية"), USERS("المستخدمون"), USER_DETAILS("تفاصيل المستخدم"),
    CARDS("الكروت"), CREATE_CARD("إنشاء كرت"), PACKAGES("الباقات"), HOTSPOT("Hotspot"), PPPOE("PPPoE"),
    REPORTS("التقارير"), AI("Smart AI Center"), DEVICE("معلومات الجهاز"), NOTIFICATIONS("الإشعارات"),
    SETTINGS("الإعدادات"), PROFILE("الملف الشخصي"), EXPIRED("الكروت المنتهية"), MAINTENANCE("صيانة User Manager"), MENU("القائمة الجانبية")
}

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); setContent { SmartManagerApp() } }
}

@Composable
fun SmartManagerApp() {
    val context = LocalContext.current
    val store = remember { SecureConfig(context) }
    var config by remember { mutableStateOf(store.get()) }
    var page by remember { mutableStateOf(Screen.LOGIN) }
    var previous by remember { mutableStateOf(Screen.HOME) }
    var connected by remember { mutableStateOf(false) }
    var version by remember { mutableStateOf("—") }
    var board by remember { mutableStateOf<Map<String,String>>(emptyMap()) }
    var liveCounts by remember { mutableStateOf(DashboardCounts()) }
    val uiPrefs = remember { context.getSharedPreferences("smart_sanaa_ui",android.content.Context.MODE_PRIVATE) }
    var darkMode by remember { mutableStateOf(uiPrefs.getBoolean("dark_mode",false)) }
    var rows by remember { mutableStateOf<List<Map<String,String>>>(emptyList()) }
    var selected by remember { mutableStateOf<Map<String,String>>(emptyMap()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var currentPath by remember { mutableStateOf("") }
    val scope=rememberCoroutineScope()
    var api by remember { mutableStateOf<RouterOsApi?>(null) }
    var repository by remember { mutableStateOf<RouterRepository?>(null) }
    var source by remember { mutableStateOf("Hotspot") }
    var tab by remember { mutableStateOf(0) }
    var detailOrigin by remember { mutableStateOf(Screen.USERS) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    DisposableEffect(Unit) { onDispose { api?.close() } }
    fun logout() { api?.close();api=null;repository=null;store.clear();config=config.copy(password="");connected=false;board=emptyMap();liveCounts=DashboardCounts();rows=emptyList();selected=emptyMap();page=Screen.LOGIN }
    fun goto(next: Screen) { previous=page; page=next; rows=emptyList(); search=""; message="" }
    fun fetch(next: Screen) {
        goto(next)
        val path=repository?.path(next,source,tab)
        if(path != null && connected) {
            busy=true; currentPath=path
            scope.launch { runCatching { repository!!.list(path) }.onSuccess { rows=it;message="تم تحديث البيانات من $path" }.onFailure { message=it.message ?: "فشل الاتصال"; if(it is RouterOsException && it.kind in setOf(ApiError.NETWORK,ApiError.AUTH,ApiError.TLS)) connected=false };busy=false }
        } else if(path==null && next in listOf(Screen.USERS,Screen.PACKAGES)) message=repository?.um?.status ?: "اتصل بالراوتر أولًا"
    }
    fun refreshDashboard() {
        val repo=repository ?: return
        scope.launch {
            // Counts are never replaced by fabricated numbers; unavailable reads stay null.
            liveCounts=repo.dashboardCounts()
            if(liveCounts.hasAnyFailure) message="تعذرت قراءة بعض إحصاءات الراوتر؛ تحقق من الصلاحيات"
        }
    }
    fun connect() {
        busy=true;message="جار الاتصال بالراوتر…"
        scope.launch {
            runCatching {
                config.validate()
                api?.close()
                val session=RouterOsApi(config);api=session
                val repo=RouterRepository(session);repository=repo
                repo.discover()
            }.onSuccess { store.save(config);board=it;version=it["version"] ?: "—";connected=true;page=Screen.HOME;message="تم الاتصال"; refreshDashboard() }
             .onFailure { connected=false;message=it.message ?: "فشل الاتصال بالراوتر" }
            busy=false
        }
    }
    BackHandler(drawerState.isOpen) { scope.launch { drawerState.close() } }
    BackHandler(page != Screen.SPLASH && page != Screen.LOGIN && page != Screen.HOME) { page=if(page==Screen.USER_DETAILS) detailOrigin else Screen.HOME }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme=if(darkMode) darkColorScheme(primary=Color(0xFF39C9E6),secondary=Color(0xFF78A8FF),background=Color(0xFF08182B),surface=Color(0xFF12273E),onSurface=Color(0xFFF2F7FC),onBackground=Color.White,onSurfaceVariant=Color(0xFFC0CFDF)) else lightColorScheme(primary=Cyan,secondary=Blue,background=Bg,surface=Surface,onSurface=Ink,onBackground=Ink,onSurfaceVariant=Muted)) {
            ModalNavigationDrawer(drawerState=drawerState, drawerContent={ ModalDrawerSheet(drawerContainerColor=MaterialTheme.colorScheme.background) { SideMenu(connected,{ next -> scope.launch { drawerState.close() };fetch(next) },{logout()}) } }) {
            Box(Modifier.fillMaxSize().safeDrawingPadding().imePadding().background(MaterialTheme.colorScheme.background)) {
                Column(Modifier.fillMaxSize()) {
                    if(page !in listOf(Screen.SPLASH,Screen.LOGIN)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=12.dp), verticalAlignment=Alignment.CenterVertically) {
                            IconButton(onClick={scope.launch { drawerState.open() }}){Icon(Icons.Default.Menu,"القائمة",tint=Cyan)}
                            Column(Modifier.weight(1f)) { Text("سمارت صنعاء",fontWeight=FontWeight.ExtraBold,fontSize=20.sp,color=MaterialTheme.colorScheme.onSurface);Text(page.arabic,fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) }
                            IconButton(onClick={darkMode=!darkMode;uiPrefs.edit().putBoolean("dark_mode",darkMode).apply()}) { Icon(if(darkMode) Icons.Default.LightMode else Icons.Default.DarkMode,"تبديل المظهر",tint=Cyan) }
                            IconButton(onClick={fetch(Screen.NOTIFICATIONS)}){Icon(Icons.Default.Notifications,"الإشعارات",tint=Cyan)}
                            Box(Modifier.size(9.dp).background(if(connected) Green else Red,CircleShape))
                        }
                    }
                    Box(Modifier.weight(1f)) {
                        when(page) {
                            Screen.SPLASH -> Splash { page=Screen.LOGIN }
                            Screen.LOGIN -> Login(config, {config=it}, {connect()},busy,message)
                            Screen.HOME -> Home(board,liveCounts,connected,message,{refreshDashboard()},{fetch(it)},api)
                            Screen.USERS,Screen.CARDS,Screen.PACKAGES,Screen.HOTSPOT,Screen.PPPOE,Screen.DEVICE,Screen.NOTIFICATIONS -> {
                                Column {
                                if(page in listOf(Screen.USERS,Screen.PACKAGES)) Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) { listOf("Hotspot","PPPoE","User Manager").forEach { label -> FilterChip(selected=source==label,onClick={source=label;fetch(page)},label={Text(label)}) } }
                                if(page in listOf(Screen.HOTSPOT,Screen.PPPOE)) Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) { listOf("الحسابات","المتصلون","الباقات").forEachIndexed { i,label -> FilterChip(selected=tab==i,onClick={tab=i;fetch(page)},label={Text(label)}) } }
                                Listing(page,rows,busy,message,search,{search=it},{fetch(page)},{ row -> selected=row;detailOrigin=page;goto(Screen.USER_DETAILS) },{goto(Screen.CREATE_CARD)})
                                }
                            }
                            Screen.USER_DETAILS -> Detail(selected){page=detailOrigin}
                            Screen.CREATE_CARD -> VoucherCreator(config,api,connected){msg->message=msg}
                            Screen.REPORTS -> Reports(connected,rows){fetch(Screen.HOTSPOT)}
                            Screen.AI -> Insights(board,connected)
                            Screen.SETTINGS -> Settings(config,{config=it}, {connect()},message,busy)
                            Screen.PROFILE -> Profile({goto(Screen.SETTINGS)},{logout()})
                            Screen.MAINTENANCE -> MaintenanceScreen(repository,connected)
                            Screen.EXPIRED -> ExpiredScreen(repository,connected)
                            Screen.MENU -> SideMenu(connected,{fetch(it)},{logout()})
                        }
                    }
                    if(page !in listOf(Screen.SPLASH,Screen.LOGIN,Screen.MENU)) BottomNav(page){fetch(it)}
                }
            }
            }
        }
    }
}

@Composable private fun Glass(modifier:Modifier=Modifier, content:@Composable ColumnScope.()->Unit) {
    Column(modifier.clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp,MaterialTheme.colorScheme.outlineVariant,RoundedCornerShape(22.dp)).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp),content=content)
}
@Composable private fun Heading(title:String,sub:String="") { Column { Text(title,fontSize=20.sp,fontWeight=FontWeight.Bold);if(sub.isNotEmpty()) Text(sub,fontSize=14.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) } }
@Composable private fun Indicator(name:String,value:String,color:Color=Cyan) { Glass(Modifier.fillMaxWidth()){ Text(name,fontSize=14.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(value,fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=color) } }
@Composable private fun Action(title:String,icon:ImageVector,modifier:Modifier=Modifier,onClick:()->Unit) {
    OutlinedButton(onClick,modifier.heightIn(min=64.dp),shape=RoundedCornerShape(17.dp),colors=ButtonDefaults.outlinedButtonColors(containerColor=MaterialTheme.colorScheme.surface),border=BorderStroke(1.dp,Cyan.copy(alpha=.35f))) {
        Icon(icon,null,tint=Cyan,modifier=Modifier.size(20.dp)); Spacer(Modifier.width(7.dp));Text(title,fontSize=14.sp)
    }
}
@Composable private fun Splash(next:()->Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Icon(Icons.Default.Router,null,tint=Cyan,modifier=Modifier.size(100.dp))
        Spacer(Modifier.height(32.dp));Text("سمارت مانجر",fontSize=34.sp,fontWeight=FontWeight.Black,color=MaterialTheme.colorScheme.onSurface)
        Text("SMART MANAGER ENTERPRISE",fontSize=13.sp,color=Cyan)
        Spacer(Modifier.height(18.dp));Text("منصة احترافية لإدارة شبكات MikroTik",color=MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(50.dp));Button(onClick=next,modifier=Modifier.fillMaxWidth()){Text("ابدأ الآن")}
    }
}
@Composable private fun Login(config:RouterConfig,update:(RouterConfig)->Unit,submit:()->Unit,busy:Boolean,message:String) {
    var portText by remember(config.host) { mutableStateOf(config.port.toString()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.Center) {
        Text("سمارت صنعاء",modifier=Modifier.align(Alignment.CenterHorizontally),fontWeight=FontWeight.Black,fontSize=29.sp,color=MaterialTheme.colorScheme.onSurface)
        Text("MikroTik Network Management",modifier=Modifier.align(Alignment.CenterHorizontally),fontSize=12.sp,color=Cyan)
        Spacer(Modifier.height(10.dp))
        Image(painterResource(R.drawable.smart_sanaa_banner),"Smart Sanaa",Modifier.fillMaxWidth().height(152.dp).clip(RoundedCornerShape(18.dp)),contentScale=ContentScale.FillBounds)
        Spacer(Modifier.height(16.dp))
        Heading("الاتصال بالراوتر","أدخل بيانات MikroTik للمتابعة")
        Spacer(Modifier.height(20.dp))
        Glass(Modifier.fillMaxWidth()) {
            Entry("عنوان IP أو اسم المضيف",config.host,{update(config.copy(host=it))})
            Entry("اسم المستخدم",config.username,{update(config.copy(username=it))})
            Entry("كلمة المرور",config.password,{update(config.copy(password=it))},secret=true)
            Entry("منفذ API",portText,{portText=it;update(config.copy(port=it.toIntOrNull() ?: 0))},number=true)
            Row(verticalAlignment=Alignment.CenterVertically) { Switch(config.tls,{update(config.copy(tls=it))});Spacer(Modifier.width(8.dp));Text("اتصال TLS مشفر؛ المنفذ مستقل",fontSize=13.sp) }
            Text("تنبيه: المنفذ 8728 غير مشفر، استخدمه داخل شبكة موثوقة فقط.",fontSize=14.sp,color=Amber)
            Button(onClick=submit,modifier=Modifier.fillMaxWidth(),enabled=!busy&&config.host.isNotBlank()&&config.username.isNotBlank()&&config.port in 1..65535){Text(if(busy)"جار الاتصال..." else "تسجيل الدخول إلى الراوتر")}
            if(message.isNotBlank())Text(message,color=if(message.startsWith("تم"))Green else Amber,fontSize=14.sp)
        }
    }
}
@Composable private fun Entry(title:String,value:String,onChange:(String)->Unit,secret:Boolean=false,number:Boolean=false) {
    OutlinedTextField(value,onChange,label={Text(title)},modifier=Modifier.fillMaxWidth(),singleLine=true,visualTransformation=if(secret)PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,keyboardOptions=KeyboardOptions(keyboardType=if(secret)KeyboardType.Password else if(number)KeyboardType.Number else KeyboardType.Text),colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Cyan,unfocusedBorderColor=MaterialTheme.colorScheme.outlineVariant,focusedLabelColor=Cyan,unfocusedLabelColor=MaterialTheme.colorScheme.onSurfaceVariant))
}

@Composable private fun TrafficPanel(api: RouterOsApi?) {
    var sample by remember { mutableStateOf<Map<String,String>>(emptyMap()) }
    var loading by remember { mutableStateOf(false) }
    val scope=rememberCoroutineScope()
    Glass(Modifier.fillMaxWidth()) { Heading("حركة الشبكة","آخر قراءة فعلية من واجهات الراوتر"); Button(enabled=api!=null&&!loading,onClick={scope.launch { loading=true; sample=runCatching { api!!.execute("/interface/print",params=mapOf(".proplist" to ".id,name,rx-byte,tx-byte,running")).data.firstOrNull().orEmpty() }.getOrDefault(emptyMap());loading=false }},modifier=Modifier.fillMaxWidth()){Text(if(loading)"جار القراءة…" else "تحديث القياس")}; if(sample.isEmpty()) Text("لا توجد عينة متاحة؛ اضغط تحديث بعد الاتصال.",color=MaterialTheme.colorScheme.onSurfaceVariant) else Text("${sample["name"] ?: "واجهة"} · تنزيل ${sample["rx-byte"] ?: "—"} · رفع ${sample["tx-byte"] ?: "—"}",color=Cyan) }
}
@Composable private fun MiniStatus(name:String,value:String,accent:Color,modifier:Modifier=Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp,accent.copy(alpha=.28f),RoundedCornerShape(18.dp)).padding(horizontal=8.dp,vertical=12.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(5.dp)) {
        Text(name,fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)
        Text(value,fontSize=15.sp,fontWeight=FontWeight.ExtraBold,color=MaterialTheme.colorScheme.onSurface,maxLines=2,textAlign=TextAlign.Center,overflow=TextOverflow.Ellipsis)
    }
}
@Composable private fun LiveMetric(title:String,value:String,caption:String,icon:ImageVector,accent:Color,modifier:Modifier=Modifier) {
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp,accent.copy(alpha=.25f),RoundedCornerShape(20.dp)).padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Icon(icon,null,tint=accent,modifier=Modifier.size(27.dp))
        Text(title,fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=2)
        Text(value,fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=MaterialTheme.colorScheme.onSurface)
        Text(caption,fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=1)
    }
}
@Composable private fun Home(board:Map<String,String>,counts:DashboardCounts,connected:Boolean,message:String,reload:()->Unit,navigate:(Screen)->Unit,api:RouterOsApi?) {
    val routerName=board["board-name"].orEmpty()
    val routerImage=when {
        routerName.contains("RB2011",true)->R.drawable.router_rb2011
        routerName.contains("RB951",true)->R.drawable.router_rb951
        routerName.contains("RB1100",true)->R.drawable.router_rb1100
        else->R.drawable.router_generic
    }
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(start=12.dp,end=12.dp,top=12.dp,bottom=26.dp),verticalArrangement=Arrangement.spacedBy(15.dp)) {
        item { Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            MiniStatus("RouterOS",board["version"]?.substringBefore(' ').orEmpty().ifBlank {"—"},Blue,Modifier.weight(1.2f))
            MiniStatus("CPU",board["cpu-load"]?.let {"$it%"} ?: "—",Color(0xFF7655D5),Modifier.weight(1f))
            MiniStatus("مدة التشغيل",board["uptime"] ?: "—",Color(0xFF219F75),Modifier.weight(1.2f))
        } }
        item { Image(painterResource(R.drawable.smart_sanaa_banner),"سمارت صنعاء لإدارة شبكات MikroTik",Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).height(176.dp),contentScale=ContentScale.FillBounds) }
        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Action("الرئيسية",Icons.Default.Home,Modifier.weight(1f)){navigate(Screen.HOME)}
            Action("إضافة كروت",Icons.Default.CreditCard,Modifier.weight(1f)){navigate(Screen.CREATE_CARD)}
            Action("عمليات الكروت",Icons.Default.ManageAccounts,Modifier.weight(1f)){navigate(Screen.CARDS)}
        } }
        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            LiveMetric("Hotspot نشط",counts.hotspot.text(),"جلسات مباشرة",Icons.Default.Wifi,Color(0xFF12A6BB),Modifier.weight(1f))
            LiveMetric("PPPoE نشط",counts.pppoe.text(),"جلسات مباشرة",Icons.Default.Schedule,Color(0xFF7C5DE3),Modifier.weight(1f))
        } }
        item { LiveMetric("إجمالي كروت User Manager",counts.userManager.text(),if(counts.userManager.value==null) "غير متاح للحساب أو الجهاز" else "قراءة حقيقية من الراوتر",Icons.Default.Groups,Color(0xFF0C9B84),Modifier.fillMaxWidth()) }
        item { Heading("الوصول السريع") }
        item { Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Action("الباقات",Icons.Default.Layers,Modifier.weight(1f)){navigate(Screen.PACKAGES)}
                Action("الجلسات",Icons.Default.AccessTime,Modifier.weight(1f)){navigate(Screen.HOTSPOT)}
            }
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Action("الكروت المنتهية",Icons.Default.DeleteOutline,Modifier.weight(1f)){navigate(Screen.EXPIRED)}
                Action("مراجعة وصيانة",Icons.Default.Build,Modifier.weight(1f)){navigate(Screen.MAINTENANCE)}
            }
        } }
        item { Glass(Modifier.fillMaxWidth()) {
            Heading("معلومات النظام",if(connected)"تمت القراءة من RouterOS" else "اتصل بالراوتر لعرض المعلومات")
            Image(painterResource(routerImage),"صورة الراوتر: ${routerName.ifBlank {"MikroTik"}}",Modifier.fillMaxWidth().height(155.dp),contentScale=ContentScale.Fit)
            listOf("اللوحة" to routerName.ifBlank {"—"},"المعمارية" to (board["architecture-name"] ?: "—"),"وقت التشغيل" to (board["uptime"] ?: "—"),"استخدام CPU" to (board["cpu-load"]?.let {"$it%"} ?: "—"),"الذاكرة" to percentageUsed(board["free-memory"],board["total-memory"]),"التخزين" to percentageUsed(board["free-hdd-space"],board["total-hdd-space"])).forEach { (label,value)->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                    Text(label,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=13.sp)
                    Text(value,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurface,fontSize=13.sp)
                }
                HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant)
            }
        } }
        item { OutlinedButton(onClick=reload,enabled=connected,modifier=Modifier.fillMaxWidth()) {Icon(Icons.Default.Refresh,null);Text(" تحديث إحصاءات الراوتر") } }
        if(message.isNotBlank()) item { Text(message,fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}
private fun percentageUsed(free:String?,total:String?):String {
    val f=free?.toDoubleOrNull();val t=total?.toDoubleOrNull()
    return if(f!=null&&t!=null&&t>0.0) "${((1.0-f/t)*100).toInt().coerceIn(0,100)}%" else "—"
}
@Composable private fun Listing(page:Screen,rows:List<Map<String,String>>,busy:Boolean,message:String,search:String,onSearch:(String)->Unit,reload:()->Unit,details:(Map<String,String>)->Unit,create:()->Unit) {
    val filtered=rows.map(Privacy::display).filter { it.values.any { v->v.contains(search,ignoreCase=true) } }
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Heading(page.arabic,"بيانات حقيقية من جهاز MikroTik المتصل") }
        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.weight(1f)){Indicator("السجلات المحملة",if(busy || message.isEmpty() || !message.startsWith("تم")) "—" else rows.size.toString())};IconButton(onClick=reload){Icon(Icons.Default.Refresh,"تحديث",tint=Cyan)}
            if(page==Screen.CARDS) IconButton(onClick=create){Icon(Icons.Default.Add,"إنشاء كرت",tint=Green)}
        } }
        item { Entry("بحث في النتائج",search,onSearch) }
        if(busy)item { CircularProgressIndicator(color=Cyan) }
        if(message.isNotEmpty())item {Text(message,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=14.sp)}
        if(!busy&&filtered.isEmpty())item {Glass(Modifier.fillMaxWidth()){Text("لا توجد بيانات للعرض. تحقق من الاتصال والصلاحيات والخدمة على الراوتر.",color=MaterialTheme.colorScheme.onSurfaceVariant)} }
        items(filtered){ item ->
            val name=item["name"] ?: item["user"] ?: item[".id"] ?: "سجل"
            Glass(Modifier.fillMaxWidth().clickable{details(item)}) {
                Row(verticalAlignment=Alignment.CenterVertically) {Icon(when(page){Screen.HOTSPOT->Icons.Default.Wifi;Screen.PPPOE->Icons.Default.Router;Screen.PACKAGES->Icons.Default.Layers;Screen.DEVICE->Icons.Default.SettingsEthernet;else->Icons.Default.Person},null,tint=Cyan);Spacer(Modifier.width(10.dp));Text(name,Modifier.weight(1f),fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Icon(Icons.Default.ChevronLeft,null,tint=Muted)}
                val fields=item.filterKeys { it !in listOf("name","user","!type") }.entries.take(4)
                fields.forEach { (k,v)->Text("$k: $v",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=14.sp,maxLines=1,overflow=TextOverflow.Ellipsis) }
            }
        }
    }
}
@Composable private fun Detail(row:Map<String,String>,back:()->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {Heading("تفاصيل السجل","معلومات مستردة من RouterOS")}
        item {Glass(Modifier.fillMaxWidth()){Icon(Icons.Default.AccountCircle,null,tint=Cyan,modifier=Modifier.size(66.dp));Text(row["name"] ?: row["user"] ?: "—",fontSize=20.sp,fontWeight=FontWeight.Bold)} }
        items(Privacy.display(row).entries.toList()){(k,v)->Glass(Modifier.fillMaxWidth()){Text(k,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=14.sp);Text(v)} }
        item {Button(back){Text("العودة للقائمة")}}
    }
}
@Composable private fun Reports(connected:Boolean,rows:List<Map<String,String>>,go:()->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item {Heading("التقارير والتحليلات","بيانات الشبكة وتقارير النشاط")}
        item {Glass(Modifier.fillMaxWidth()){Text("تقارير الإيرادات والمبيعات تحتاج إلى سجل مالي أو قاعدة بيانات للمدفوعات.",color=Amber);Text("لن نعرض مبالغ افتراضية باعتبارها إيرادات حقيقية.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=14.sp)} }
        item {Indicator("حالة الراوتر",if(connected)"متصل" else "غير متصل",if(connected)Green else Red)}
        item {Action("فتح الجلسات الفعلية",Icons.Default.BarChart,Modifier.fillMaxWidth(),go)}
    }
}
@Composable private fun Insights(board:Map<String,String>,connected:Boolean) {
    val cpu=board["cpu-load"]?.toIntOrNull()
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {Heading("Smart AI Center","مساعد مراقبة محلي قائم على قواعد واضحة")}
        item {Glass(Modifier.fillMaxWidth()){Icon(Icons.Default.AutoAwesome,null,tint=Cyan,modifier=Modifier.size(50.dp));Text("تحليل صحة الشبكة",fontSize=20.sp,fontWeight=FontWeight.Bold);Text(if(!connected)"اتصل بالراوتر أولاً" else if(cpu!=null&&cpu>=85)"تحذير: استهلاك CPU مرتفع ($cpu%). راجع العمليات النشطة." else if(cpu==null) "قراءة CPU غير متاحة" else "استهلاك CPU في النطاق المعتاد (${cpu ?: "—"}%).",color=if(cpu!=null&&cpu>=85)Amber else Green)} }
        item {Glass(Modifier.fillMaxWidth()){Heading("التوقعات الذكية");Text("التنبؤ بالاستهلاك يتطلب تخزين سلسلة زمنية من القياسات؛ غير مفعل في هذا الإصدار.",color=MaterialTheme.colorScheme.onSurfaceVariant)} }
        item {Glass(Modifier.fillMaxWidth()){Heading("التنبيهات الأمنية");Text("راجع سجلات النظام وشاشة الإشعارات لمشاهدة أحداث الراوتر الفعلية.",color=MaterialTheme.colorScheme.onSurfaceVariant)} }
    }
}
@Composable private fun Settings(config:RouterConfig,save:(RouterConfig)->Unit,connect:()->Unit,message:String,busy:Boolean) {
    var portText by remember { mutableStateOf(config.port.toString()) }
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item {Heading("الإعدادات","الشبكة والأمان والمظهر")}
        item {Glass(Modifier.fillMaxWidth()) {
            Heading("إعدادات الاتصال")
            Entry("عنوان الراوتر",config.host,{save(config.copy(host=it))})
            Entry("المستخدم",config.username,{save(config.copy(username=it))})
            Entry("كلمة المرور",config.password,{save(config.copy(password=it))},secret=true)
            Entry("المنفذ",portText,{portText=it;save(config.copy(port=it.toIntOrNull() ?: 0))},number=true)
            Row(verticalAlignment=Alignment.CenterVertically) {Switch(config.tls,{save(config.copy(tls=it))});Text("  API-SSL / TLS")}
            Button(onClick=connect,enabled=!busy&&config.port in 1..65535,modifier=Modifier.fillMaxWidth()){Text("حفظ واختبار الاتصال")}
            if(message.isNotEmpty())Text(message,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=14.sp)
        } }
        item {Glass(Modifier.fillMaxWidth()){Heading("الأمان");Text("بيانات الاعتماد مشفرة بـ Android Keystore. يوصى باتصال TLS وشهادة موثوقة.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=13.sp)} }
        item {Glass(Modifier.fillMaxWidth()){Heading("عن التطبيق");Text("Smart Sanaa Android Native · Source V5",color=MaterialTheme.colorScheme.onSurfaceVariant)} }
    }
}
@Composable private fun Profile(settings:()->Unit,logout:()->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(15.dp)) {
        item {Glass(Modifier.fillMaxWidth(),){Icon(Icons.Default.AccountCircle,null,tint=Cyan,modifier=Modifier.size(90.dp).align(Alignment.CenterHorizontally));Text("مدير الشبكة",fontSize=22.sp,fontWeight=FontWeight.Bold);Text("حساب إدارة MikroTik",color=MaterialTheme.colorScheme.onSurfaceVariant)} }
        item {Action("إعدادات الاتصال والأمان",Icons.Default.Security,Modifier.fillMaxWidth(),settings)}
        item {Button(onClick=logout,colors=ButtonDefaults.buttonColors(containerColor=Red),modifier=Modifier.fillMaxWidth()){Text("تسجيل الخروج")}}
    }
}
@Composable private fun SideMenu(connected:Boolean,navigate:(Screen)->Unit,logout:()->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        item {Glass(Modifier.fillMaxWidth()){Text("SMART SANAA",fontSize=22.sp,fontWeight=FontWeight.Black,color=Cyan);Text(if(connected)"● متصل" else "● غير متصل",color=if(connected)Green else Red)} }
        items(listOf(Screen.HOME,Screen.USERS,Screen.CARDS,Screen.CREATE_CARD,Screen.PACKAGES,Screen.HOTSPOT,Screen.PPPOE,Screen.REPORTS,Screen.AI,Screen.DEVICE,Screen.NOTIFICATIONS,Screen.EXPIRED,Screen.MAINTENANCE,Screen.SETTINGS,Screen.PROFILE)){s->Action(s.arabic,Icons.Default.ChevronLeft,Modifier.fillMaxWidth()){navigate(s)} }
        item {Button(onClick=logout,colors=ButtonDefaults.buttonColors(containerColor=Red),modifier=Modifier.fillMaxWidth()){Text("تسجيل الخروج")}}
    }
}
@Composable private fun BottomNav(active:Screen,navigate:(Screen)->Unit) {
    val options=listOf(Triple(Screen.HOME,"الرئيسية",Icons.Default.Home),Triple(Screen.CREATE_CARD,"إضافة",Icons.Default.CreditCard),Triple(Screen.CARDS,"الكروت",Icons.Default.ManageAccounts),Triple(Screen.REPORTS,"التقارير",Icons.Default.BarChart),Triple(Screen.SETTINGS,"الإعدادات",Icons.Default.Settings))
    NavigationBar(containerColor=MaterialTheme.colorScheme.surface,tonalElevation=0.dp) {
        options.forEach { (screen,label,icon)->NavigationBarItem(selected=screen==active,onClick={navigate(screen)},icon={Icon(icon,label)},label={Text(label,fontSize=12.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Cyan,selectedTextColor=Cyan,unselectedIconColor=Muted,unselectedTextColor=Muted,indicatorColor=Cyan.copy(alpha=.12f)))}
    }
}
