package com.smartsanaa.manager

/** Pure mm geometry: exact A4 bounds, unit-tested without requiring Android UI. */
object PrintLayout {
    const val A4_WIDTH_MM=210f
    const val A4_HEIGHT_MM=297f
    const val POINTS_PER_MM=72f/25.4f
    data class CardRect(val xMm:Float,val yMm:Float,val widthMm:Float,val heightMm:Float)
    fun page(columns:Int,rows:Int,cardWidth:Float,cardHeight:Float,margin:Float,gap:Float):List<CardRect> {
        require(columns in 1..8 && rows in 1..20)
        require(cardWidth>=20 && cardHeight>=20 && margin>=0 && gap>=0)
        require(2*margin+columns*cardWidth+(columns-1)*gap<=A4_WIDTH_MM+0.0001f) {"تجاوز عرض الكروت مساحة ورقة A4"}
        require(2*margin+rows*cardHeight+(rows-1)*gap<=A4_HEIGHT_MM+0.0001f) {"تجاوز ارتفاع الكروت مساحة ورقة A4"}
        return List(rows*columns){i->
            val col=columns-1-(i%columns) // RTL: first voucher on the right
            val row=i/columns
            CardRect(margin+col*(cardWidth+gap),margin+row*(cardHeight+gap),cardWidth,cardHeight)
        }
    }
}
