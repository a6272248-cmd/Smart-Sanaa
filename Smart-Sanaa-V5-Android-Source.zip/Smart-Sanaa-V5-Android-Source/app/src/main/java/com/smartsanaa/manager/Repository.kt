package com.smartsanaa.manager

import kotlinx.coroutines.CancellationException

/** Capability is determined by successful read probes, never by version alone. */
data class Capability(val path: String?, val status: String)
class RouterRepository(val api: RouterOsApi) {
    var um=Capability(null,"لم يتم الفحص");private set
    suspend fun discover(): Map<String,String> {
        val resource=api.execute("/system/resource/print").data.firstOrNull().orEmpty()
        val identity=api.execute("/system/identity/print").data.firstOrNull().orEmpty()
        // Package permission failure must not be treated as an absent installation.
        val packages=try { api.execute("/system/package/print",mapOf(".proplist" to "name,disabled,version")).data } catch(e: RouterOsException) { emptyList() }
        val disabled=packages.any { it["name"]=="user-manager" && it["disabled"]=="true" }
        if(disabled)um=Capability(null,"حزمة User Manager معطلة") else {
            val paths=if(resource["version"].orEmpty().startsWith("6."))listOf("/tool/user-manager","/user-manager") else listOf("/user-manager","/tool/user-manager")
            var denied=false
            for(base in paths) {
                try { api.execute("$base/user/print",mapOf("count-only" to ""));um=Capability(base,"متاح");break }
                catch(e: RouterOsException) { if(e.kind==ApiError.DENIED)denied=true;else if(e.kind!=ApiError.UNSUPPORTED) { um=Capability(null,e.message.orEmpty());return resource+mapOf("identity" to identity["name"].orEmpty()) } }
            }
            if(um.path==null)um=Capability(null,if(denied)"لا صلاحية لفحص User Manager" else "مسارات User Manager غير متاحة للحساب أو الجهاز")
        }
        return resource+mapOf("identity" to identity["name"].orEmpty())
    }
    suspend fun list(path: String): List<Map<String,String>> {
        // Logs carry arbitrary user-supplied secrets in message; only metadata is collected.
        val props=if(path=="/log/print")".id,time,topics" else Privacy.fields.joinToString(",")
        return api.execute(path,mapOf(".proplist" to props)).data.map(Privacy::safe)
    }
    fun path(screen: Screen, source: String, tab: Int): String? {
        val base=when(source) { "Hotspot"->"/ip/hotspot";"PPPoE"->"/ppp";else->um.path ?: return null }
        return when(screen) {
            Screen.USERS -> when(source){"Hotspot"->"$base/user/print";"PPPoE"->"$base/secret/print";else->"$base/user/print"}
            Screen.CARDS -> "/ip/hotspot/user/print"
            Screen.PACKAGES -> "$base/profile/print"
            Screen.HOTSPOT -> "/ip/hotspot/"+listOf("user","active","user/profile")[tab.coerceIn(0,2)]+"/print"
            Screen.PPPOE -> "/ppp/"+listOf("secret","active","profile")[tab.coerceIn(0,2)]+"/print"
            Screen.DEVICE -> "/interface/print"
            Screen.NOTIFICATIONS -> "/log/print"
            else -> null
        }
    }
}
