package com.smartsanaa.manager

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Locale

/** Capability is determined by successful RouterOS probes, never by version alone. */
data class Capability(val path: String?, val status: String)

class PartialUserCreationException(message: String) : IllegalStateException(message)

data class BulkOperationResult(
    val confirmedIds: List<String>,
    val failedIds: List<String>,
    val uncertain: Boolean = false,
    val detail: String = ""
) {
    val complete: Boolean get() = failedIds.isEmpty() && !uncertain
}

class RouterRepository(val api: RouterOsApi) {
    var um = Capability(null, "لم يتم الفحص")
        private set
    var routerVersion: String = ""
        private set

    val isRouterOsV6: Boolean get() = routerVersion.startsWith("6.") || um.path?.startsWith("/tool/") == true

    /** RouterOS v6 User Manager is customer-scoped; keep every legacy UM request on admin. */
    fun requestParams(path: String, params: Map<String, String>): Map<String, String> =
        if (um.path?.startsWith("/tool/") == true && path.startsWith(um.path!!)) params + ("customer" to params["customer"].orEmpty().ifBlank { "admin" }) else params

    suspend fun discover(): Map<String, String> {
        val resource = api.execute("/system/resource/print").data.firstOrNull().orEmpty()
        val identity = api.execute("/system/identity/print").data.firstOrNull().orEmpty()
        routerVersion = resource["version"].orEmpty()
        val packages = try {
            api.execute("/system/package/print", mapOf(".proplist" to "name,disabled,version")).data
        } catch (_: RouterOsException) {
            emptyList()
        }
        val disabled = packages.any { it["name"] == "user-manager" && it["disabled"] == "true" }
        if (disabled) {
            um = Capability(null, "حزمة User Manager معطلة")
        } else {
            val paths = if (routerVersion.startsWith("6.")) {
                listOf("/tool/user-manager", "/user-manager")
            } else {
                listOf("/user-manager", "/tool/user-manager")
            }
            var denied = false
            for (base in paths) {
                try {
                    val probePath = "$base/user/print"
                    val probeParams = if (base.startsWith("/tool/")) mapOf("count-only" to "", "customer" to "admin") else mapOf("count-only" to "")
                    api.execute(probePath, probeParams)
                    um = Capability(base, "متاح")
                    break
                } catch (e: RouterOsException) {
                    if (e.kind == ApiError.DENIED) denied = true
                    else if (e.kind != ApiError.UNSUPPORTED) {
                        um = Capability(null, e.message.orEmpty())
                        return resource + mapOf("identity" to identity["name"].orEmpty())
                    }
                }
            }
            if (um.path == null) {
                um = Capability(null, if (denied) "لا صلاحية لفحص User Manager" else "مسارات User Manager غير متاحة للحساب أو الجهاز")
            }
        }
        return resource + mapOf("identity" to identity["name"].orEmpty())
    }

    fun userRoot(service: String): String? = when (service) {
        "Hotspot" -> "/ip/hotspot/user"
        "PPPoE" -> "/ppp/secret"
        "User Manager" -> um.path?.let { "$it/user" }
        else -> null
    }

    fun profileRoot(service: String): String? = when (service) {
        "Hotspot" -> "/ip/hotspot/user/profile"
        "PPPoE" -> "/ppp/profile"
        "User Manager" -> um.path?.let { "$it/profile" }
        else -> null
    }

    fun sessionRoot(service: String): String? = when (service) {
        "Hotspot" -> "/ip/hotspot/active"
        "PPPoE" -> "/ppp/active"
        "User Manager" -> um.path?.let { "$it/session" }
        else -> null
    }

    fun path(screen: Screen, source: String, tab: Int): String? = when (screen) {
        Screen.USERS, Screen.CARDS -> userRoot(source)?.plus("/print")
        Screen.PACKAGES -> profileRoot(source)?.plus("/print")
        Screen.HOTSPOT -> when (tab.coerceIn(0, 2)) {
            0 -> "/ip/hotspot/user/print"
            1 -> "/ip/hotspot/active/print"
            else -> "/ip/hotspot/user/profile/print"
        }
        Screen.PPPOE -> when (tab.coerceIn(0, 2)) {
            0 -> "/ppp/secret/print"
            1 -> "/ppp/active/print"
            else -> "/ppp/profile/print"
        }
        Screen.SESSIONS -> sessionRoot(source)?.plus("/print")
        Screen.DEVICE -> "/interface/print"
        Screen.REPORTS -> "/log/print"
        else -> null
    }

    fun recordRoot(screen: Screen, source: String, tab: Int): String? = when (screen) {
        Screen.USERS, Screen.CARDS -> userRoot(source)
        Screen.PACKAGES -> profileRoot(source)
        Screen.HOTSPOT -> when (tab.coerceIn(0, 2)) {
            0 -> "/ip/hotspot/user"
            1 -> "/ip/hotspot/active"
            else -> "/ip/hotspot/user/profile"
        }
        Screen.PPPOE -> when (tab.coerceIn(0, 2)) {
            0 -> "/ppp/secret"
            1 -> "/ppp/active"
            else -> "/ppp/profile"
        }
        Screen.SESSIONS -> sessionRoot(source)
        else -> null
    }

    suspend fun list(path: String): List<Map<String, String>> {
        val props = when {
            path == "/log/print" -> ".id,time,topics,message"
            path.endsWith("/session/print") || path.endsWith("/active/print") -> Privacy.sessionFields.joinToString(",")
            path.endsWith("/profile/print") -> Privacy.profileFields.joinToString(",")
            else -> Privacy.fields.joinToString(",")
        }
        return api.execute(path, requestParams(path, mapOf(".proplist" to props))).data.map(Privacy::safe)
    }

    /** Use RouterOS-side filters for the large User Manager session history table. */
    suspend fun listSessions(service: String, filter: String): List<Map<String, String>> {
        val root = sessionRoot(service) ?: error(if (service == "User Manager") um.status else "مسار الجلسات غير متاح")
        val query = when {
            service != "User Manager" -> emptyList()
            root.startsWith("/tool/") && filter == "active" -> listOf("?status=start,interim")
            root.startsWith("/tool/") && filter == "ended" -> listOf("?status=start,stop,closed")
            root.startsWith("/user-manager/") && filter == "active" -> listOf("?active=yes")
            root.startsWith("/user-manager/") && filter == "ended" -> listOf("?active=no")
            else -> emptyList()
        }
        val rows = api.execute("$root/print", requestParams("$root/print", mapOf(".proplist" to Privacy.sessionFields.joinToString(","))), query)
            .data.map(Privacy::safe)
        if (service != "User Manager" || !root.startsWith("/tool/") || filter == "all") return rows
        return rows.filter { row ->
            val tokens = row["status"].orEmpty().lowercase(Locale.ROOT).split(',').map(String::trim).filter(String::isNotBlank)
            val active = !tokens.contains("closed") && !tokens.contains("stop") && (tokens.contains("start") || tokens.contains("interim"))
            if (filter == "active") active else !active
        }
    }

    suspend fun count(path: String, query: List<String> = emptyList()): Long? =
        api.execute(path, requestParams(path, mapOf("count-only" to "")), query).count

    /** Use the router's clock for expiry decisions; never substitute the phone clock silently. */
    suspend fun routerNow(): LocalDateTime? {
        val row = api.execute("/system/clock/print", mapOf(".proplist" to "date,time")).data.firstOrNull() ?: return null
        val rawDate = row["date"]?.trim().orEmpty()
        val rawTime = row["time"]?.trim().orEmpty()
        if (rawDate.isBlank() || rawTime.isBlank()) return null
        val dateFormats = listOf("MMM/d/yyyy", "MMM/dd/yyyy", "yyyy-MM-dd")
        var date: LocalDate? = null
        for (pattern in dateFormats) {
            try {
                date = LocalDate.parse(rawDate.replaceFirstChar { it.uppercase(Locale.ENGLISH) }, DateTimeFormatter.ofPattern(pattern, Locale.ENGLISH))
                break
            } catch (_: DateTimeParseException) { }
        }
        val time = runCatching { LocalTime.parse(rawTime, DateTimeFormatter.ofPattern("H:mm:ss", Locale.ENGLISH)) }.getOrNull()
            ?: runCatching { LocalTime.parse(rawTime, DateTimeFormatter.ofPattern("HH:mm:ss", Locale.ENGLISH)) }.getOrNull()
        return if (date != null && time != null) LocalDateTime.of(date, time) else null
    }

    suspend fun setDisabled(root: String, id: String, disabled: Boolean) {
        require(id.isNotBlank()) { "معرّف السجل غير متاح؛ لن يتم تعديل سجل غير محدد" }
        api.execute("$root/set", requestParams("$root/set", mapOf(".id" to id, "disabled" to if (disabled) "yes" else "no")))
    }

    suspend fun remove(root: String, id: String) {
        require(id.isNotBlank()) { "معرّف السجل غير متاح؛ لن يتم حذف سجل غير محدد" }
        api.execute("$root/remove", requestParams("$root/remove", mapOf(".id" to id)))
    }

    /** Bounded state changes; never retry a request after an ambiguous transport failure. */
    suspend fun bulkSetDisabled(root: String, ids: List<String>, disabled: Boolean): BulkOperationResult {
        validateBulkIds(ids)
        val confirmed = mutableListOf<String>()
        val failed = mutableListOf<String>()
        var uncertain = false
        var detail = ""
        for (id in ids) {
            try {
                setDisabled(root, id, disabled)
                confirmed += id
            } catch (e: Exception) {
                failed += id
                detail = e.message ?: "رفض الراوتر العملية"
                if (e.isAmbiguousRouterFailure()) {
                    uncertain = true
                }
                break
            }
        }
        if (failed.isNotEmpty()) ids.filter { it !in confirmed && it !in failed }.forEach { failed += it }
        return BulkOperationResult(confirmed, failed, uncertain, detail)
    }

    /**
     * Deletes only exact selected user IDs. RouterOS v7 User Manager requires resolving
     * and removing the selected users' profile links first; unrelated links are untouched.
     */
    suspend fun bulkDeleteUsers(service: String, ids: List<String>): BulkOperationResult {
        validateBulkIds(ids)
        val selectedIds = ids.distinct()
        val root = userRoot(service) ?: error(if (service == "User Manager") um.status else "مسار الخدمة غير متاح")
        val confirmed = mutableListOf<String>()
        val failed = mutableListOf<String>()
        var uncertain = false
        var detail = ""

        if (service == "User Manager" && !root.startsWith("/tool/")) {
            val umBase = um.path ?: error(um.status)
            val relationRoot = "$umBase/user-profile"
            val users = api.execute("$root/print", requestParams("$root/print", mapOf(".proplist" to ".id,name"))).data
            val selected = selectedIds.mapNotNull { id -> users.firstOrNull { it[".id"] == id } }
            if (selected.size != selectedIds.size) {
                return BulkOperationResult(emptyList(), selectedIds, detail = "تغيرت قائمة مستخدمي User Manager؛ حدّث القائمة قبل الحذف.")
            }
            val names = selected.map { it["name"].orEmpty() }
            if (names.any { it.isBlank() } || names.distinct().size != names.size) {
                return BulkOperationResult(emptyList(), selectedIds, detail = "هوية أحد مستخدمي User Manager غير واضحة؛ لم يبدأ الحذف.")
            }
            val nameToId = selected.associate { it["name"].orEmpty() to it[".id"].orEmpty() }
            val relations = api.execute("$relationRoot/print", requestParams("$relationRoot/print", mapOf(".proplist" to ".id,user"))).data
            val linksByUser = mutableMapOf<String, MutableList<String>>()
            val seenLinks = mutableSetOf<String>()
            for (link in relations) {
                val owner = link["user"].orEmpty()
                val ownerId = nameToId[owner] ?: owner.takeIf { it in selectedIds } ?: continue
                val linkId = link[".id"].orEmpty()
                if (!validRouterId(linkId) || !seenLinks.add(linkId)) {
                    return BulkOperationResult(emptyList(), selectedIds, detail = "معرّف علاقة باقة غير واضح؛ لم يبدأ الحذف.")
                }
                linksByUser.getOrPut(ownerId) { mutableListOf() } += linkId
            }

            val blocked = mutableSetOf<String>()
            for (id in selectedIds) {
                for (linkId in linksByUser[id].orEmpty()) {
                    try {
                        api.execute("$relationRoot/remove", requestParams("$relationRoot/remove", mapOf(".id" to linkId)))
                    } catch (e: Exception) {
                        blocked += id
                        failed += id
                        detail = e.message ?: "فشل إزالة علاقة الباقة"
                        if (e.isAmbiguousRouterFailure()) uncertain = true
                        break
                    }
                }
                if (blocked.isNotEmpty()) break
            }
            if (blocked.isNotEmpty()) {
                selectedIds.filter { it !in confirmed && it !in failed }.forEach { failed += it }
                return BulkOperationResult(confirmed, failed.distinct(), uncertain, detail)
            }
            for (id in selectedIds) {
                if (id in blocked) continue
                try {
                    api.execute("$root/remove", requestParams("$root/remove", mapOf(".id" to id)))
                    confirmed += id
                } catch (e: Exception) {
                    failed += id
                    detail = e.message ?: "فشل حذف المستخدم"
                    if (e.isAmbiguousRouterFailure()) {
                        uncertain = true
                    }
                    break
                }
            }
            if (failed.isNotEmpty()) selectedIds.filter { it !in confirmed && it !in failed }.forEach { failed += it }
            return BulkOperationResult(confirmed, failed.distinct(), uncertain, detail)
        }

        for (id in selectedIds) {
            try {
                api.execute("$root/remove", requestParams("$root/remove", mapOf(".id" to id)))
                confirmed += id
            } catch (e: Exception) {
                failed += id
                detail = e.message ?: "فشل حذف المستخدم"
                if (e.isAmbiguousRouterFailure()) {
                    uncertain = true
                }
                break
            }
        }
        if (failed.isNotEmpty()) selectedIds.filter { it !in confirmed && it !in failed }.forEach { failed += it }
        return BulkOperationResult(confirmed, failed, uncertain, detail)
    }

    /** Removes only the explicitly selected RouterOS record IDs; no implicit retry. */
    suspend fun bulkRemoveRecords(root: String, ids: List<String>): BulkOperationResult {
        validateBulkIds(ids)
        val confirmed = mutableListOf<String>()
        val failed = mutableListOf<String>()
        var uncertain = false
        var detail = ""
        for (id in ids.distinct()) {
            try {
                remove(root, id)
                confirmed += id
            } catch (e: Exception) {
                failed += id
                detail = e.message ?: "رفض الراوتر الحذف"
                uncertain = e.isAmbiguousRouterFailure()
                break
            }
        }
        if (failed.isNotEmpty()) ids.filter { it !in confirmed && it !in failed }.forEach { failed += it }
        return BulkOperationResult(confirmed, failed.distinct(), uncertain, detail)
    }

    suspend fun existingUsernames(service: String, customer: String = "admin"): Set<String> {
        val root = userRoot(service) ?: error(if (service == "User Manager") um.status else "مسار الخدمة غير متاح")
        val key = if (service == "User Manager" && root.startsWith("/tool/")) "username" else "name"
        val path = "$root/print"
        val params = if (service == "User Manager" && root.startsWith("/tool/")) mapOf(".proplist" to key, "customer" to customer) else mapOf(".proplist" to key)
        return api.execute(path, requestParams(path, params)).data
            .mapNotNull { it[key]?.trim()?.takeIf(String::isNotBlank) }.toSet()
    }

    suspend fun deleteUser(service: String, id: String) {
        val result = bulkDeleteUsers(service, listOf(id))
        if (result.confirmedIds.size != 1 || !result.complete) {
            error(result.detail.ifBlank { "لم يتم تأكيد حذف المستخدم؛ حدّث القائمة قبل أي محاولة أخرى." })
        }
    }

    private fun validateBulkIds(ids: List<String>) {
        require(ids.isNotEmpty()) { "حدد سجلًا واحدًا على الأقل" }
        require(ids.size <= 100) { "الحد الأقصى للعملية الواحدة 100 سجل" }
        require(ids.all(::validRouterId)) { "تحتوي القائمة على معرّف غير صالح؛ أوقف العملية" }
        require(ids.distinct().size == ids.size) { "تكررت معرّفات في القائمة؛ أوقف العملية" }
    }

    private fun validRouterId(id: String): Boolean = Regex("^\\*[0-9A-Fa-f]+$").matches(id)

    private fun Exception.isAmbiguousRouterFailure(): Boolean =
        this is RouterOsException && kind in setOf(ApiError.NETWORK, ApiError.TLS, ApiError.PROTOCOL)

    /** Create one real account. A failed second UM command is reported as partial, never retried. */
    suspend fun createUser(service: String, values: Map<String, String>, allowEmptyPassword: Boolean = false): String {
        val username = values["username"].orEmpty().trim()
        val password = values["password"].orEmpty()
        require(username.isNotBlank()) { "اسم المستخدم مطلوب" }
        require(password.isNotBlank() || allowEmptyPassword) { "كلمة المرور مطلوبة" }
        val root = userRoot(service) ?: error(if (service == "User Manager") um.status else "مسار الخدمة غير متاح")
        val selectedProfile = values["profile"].orEmpty().trim()
        if (selectedProfile.isNotBlank()) {
            val profilePath = profileRoot(service) ?: error("مسار الباقات غير متاح")
            val profileParams = if (service == "User Manager" && profilePath.startsWith("/tool/")) mapOf(".proplist" to "name", "customer" to values["customer"].orEmpty().ifBlank { "admin" }) else mapOf(".proplist" to "name")
            val exists = api.execute("$profilePath/print", requestParams("$profilePath/print", profileParams), listOf("?name=$selectedProfile")).data.any { it["name"] == selectedProfile }
            require(exists) { "الباقة $selectedProfile غير موجودة على الراوتر" }
        }

        when (service) {
            "Hotspot", "PPPoE" -> {
                val existing = api.execute("$root/print", requestParams("$root/print", mapOf(".proplist" to ".id,name")), listOf("?name=$username")).data
                require(existing.none { it["name"] == username }) { "اسم المستخدم موجود مسبقًا" }
                val params = buildMap {
                    put("name", username)
                    put("password", password)
                    values["profile"]?.takeIf { it.isNotBlank() }?.let { put("profile", it) }
                    values["comment"]?.takeIf { it.isNotBlank() }?.let { put("comment", it) }
                    if (service == "Hotspot") {
                        values["limit-uptime"]?.takeIf { it.isNotBlank() }?.let { put("limit-uptime", it) }
                        values["server"]?.takeIf { it.isNotBlank() }?.let { put("server", it) }
                    } else {
                        put("service", "pppoe")
                        values["local-address"]?.takeIf { it.isNotBlank() }?.let { put("local-address", it) }
                        values["remote-address"]?.takeIf { it.isNotBlank() }?.let { put("remote-address", it) }
                    }
                }
                api.execute("$root/add", params)
                return "تم إنشاء المستخدم $username في $service"
            }
            "User Manager" -> {
                val base = um.path ?: error(um.status)
                val customer = values["customer"].orEmpty().ifBlank { "admin" }
                val isV6 = base.startsWith("/tool/")
                val key = if (isV6) "username" else "name"
                val duplicateParams = if (isV6) mapOf(".proplist" to ".id,$key", "customer" to customer) else mapOf(".proplist" to ".id,$key")
                val existing = api.execute("$root/print", requestParams("$root/print", duplicateParams), listOf("?$key=$username")).data
                require(existing.none { it[key] == username }) { "اسم المستخدم موجود مسبقًا في User Manager" }
                val params = buildMap {
                    if (isV6) put("customer", customer)
                    put(key, username)
                    put("password", password)
                    put("shared-users", values["shared-users"].orEmpty().ifBlank { "1" })
                    put("disabled", "no")
                    if (!isV6) put("group", values["group"].orEmpty().ifBlank { "default" })
                    values["comment"]?.takeIf { it.isNotBlank() }?.let { put("comment", it) }
                }
                val created = api.execute("$root/add", params)
                val profile = values["profile"].orEmpty().trim()
                if (profile.isNotBlank()) {
                    try {
                        if (isV6) {
                            val selector = created.completion["ret"]?.takeIf { it.isNotBlank() } ?: username
                            api.execute("$root/create-and-activate-profile", mapOf("customer" to customer, "numbers" to selector, "profile" to profile))
                        } else {
                            api.execute("$base/user-profile/add", mapOf("user" to username, "profile" to profile))
                        }
                    } catch (e: Exception) {
                        throw PartialUserCreationException("تم إنشاء المستخدم $username، لكن تعيين الباقة لم يكتمل. افحص User Manager قبل إعادة المحاولة. السبب: ${e.message}")
                    }
                }
                return "تم إنشاء المستخدم $username في User Manager${if (profile.isNotBlank()) " وربط الباقة $profile" else ""}"
            }
            else -> error("نوع خدمة غير معروف")
        }
    }

    suspend fun createProfile(service: String, values: Map<String, String>) {
        val root = profileRoot(service) ?: error("مسار الباقات غير متاح")
        val name = values["name"].orEmpty().trim()
        require(name.isNotBlank()) { "اسم الباقة مطلوب" }
        val existing = api.execute("$root/print", requestParams("$root/print", mapOf(".proplist" to "name")), listOf("?name=$name")).data
        require(existing.none { it["name"] == name }) { "اسم الباقة موجود مسبقًا" }
        val params = when (service) {
            "Hotspot" -> buildMap {
                put("name", name)
                values["rate-limit"]?.takeIf { it.isNotBlank() }?.let { put("rate-limit", it) }
                values["shared-users"]?.takeIf { it.isNotBlank() }?.let { put("shared-users", it) }
                values["session-timeout"]?.takeIf { it.isNotBlank() }?.let { put("session-timeout", it) }
                values["idle-timeout"]?.takeIf { it.isNotBlank() }?.let { put("idle-timeout", it) }
            }
            "PPPoE" -> buildMap {
                put("name", name)
                values["rate-limit"]?.takeIf { it.isNotBlank() }?.let { put("rate-limit", it) }
                values["local-address"]?.takeIf { it.isNotBlank() }?.let { put("local-address", it) }
                values["remote-address"]?.takeIf { it.isNotBlank() }?.let { put("remote-address", it) }
                values["only-one"]?.takeIf { it.isNotBlank() }?.let { put("only-one", it) }
                values["session-timeout"]?.takeIf { it.isNotBlank() }?.let { put("session-timeout", it) }
            }
            "User Manager" -> buildMap {
                put("name", name)
                values["name-for-users"]?.takeIf { it.isNotBlank() }?.let { put("name-for-users", it) }
                values["validity"]?.takeIf { it.isNotBlank() }?.let { put("validity", it) }
                values["starts-when"]?.takeIf { it.isNotBlank() }?.let { put("starts-when", it) }
                values["price"]?.takeIf { it.isNotBlank() }?.let { put("price", it) }
                values["override-shared-users"]?.takeIf { it.isNotBlank() }?.let { put("override-shared-users", it) }
            }
            else -> error("نوع باقة غير معروف")
        }
        api.execute("$root/add", requestParams("$root/add", params))
    }
}
