package com.smartsanaa.manager

/** null means not verified; it must never be shown as zero. */
data class LiveCount(val value: Long? = null, val reason: String? = null) {
    fun text(): String = value?.toString() ?: "—"
}

data class DashboardCounts(
    val hotspot: LiveCount = LiveCount(),
    val pppoe: LiveCount = LiveCount(),
    val userManager: LiveCount = LiveCount()
) {
    val hasAnyFailure: Boolean get() = listOf(hotspot, pppoe, userManager).any { it.reason != null }
}

/** Read-only counts from the exact RouterOS service. A failed query is unavailable, not 0. */
suspend fun RouterRepository.dashboardCounts(): DashboardCounts {
    suspend fun safeCount(path: String): LiveCount = try {
        val count = api.execute(path, mapOf("count-only" to "")).count
        if (count == null) LiveCount(reason = "الراوتر لم يرجع عددًا") else LiveCount(count)
    } catch (e: Exception) {
        LiveCount(reason = (e as? RouterOsException)?.kind?.name ?: "تعذر القراءة")
    }
    val umCount = um.path?.let { safeCount("$it/user/print") }
        ?: LiveCount(reason = um.status)
    return DashboardCounts(
        hotspot = safeCount("/ip/hotspot/active/print"),
        pppoe = safeCount("/ppp/active/print"),
        userManager = umCount
    )
}
