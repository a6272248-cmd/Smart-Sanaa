package com.smartsanaa.manager

/** Non-destructive triage for User Manager. Never classify an unknown expiry as expired. */
object ExpiryPolicy {
    private val unknown = setOf("", "unknown", "غير معروف", "not set", "none", "never", "—", "-", "لم يحدد", "غير محدد")
    fun isUnknownExpiry(text: String?): Boolean = text == null || text.trim().lowercase() in unknown

    /** RouterOS v7: a consumed profile is not by itself proof that the entire user has expired. */
    fun v7ProfileUsed(row: Map<String, String>): Boolean =
        row["state"]?.trim()?.equals("used", ignoreCase = true) == true &&
        !isUnknownExpiry(row["end-time"])

    /** Deletion needs a separate explicit user review and remains unavailable in this version. */
    fun autoDeleteAllowed(): Boolean = false
}
