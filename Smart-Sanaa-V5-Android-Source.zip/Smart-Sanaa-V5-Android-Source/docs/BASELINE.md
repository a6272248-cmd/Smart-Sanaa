# Protected baseline
Repository: https://github.com/a6272248-cmd/Smart-Sanaa
main: 75dd55836a40d935941c558b3957bd38427d3e8b
Source: SmartManagerEnterprise-BUILD-FIX-V3.zip at that commit.
All source files in the supplied LITE match this archive byte for byte (archive also contains design PNG).
Last successful baseline run: https://github.com/a6272248-cmd/Smart-Sanaa/actions/runs/41773212359
No published releases found. Only other branch: android/native-smart-manager (not used).
Development branch: feature/smart-manager-enterprise-v4 (local; no main writes).
No router, OpenWrt, modem, firewall, or service changes performed.
