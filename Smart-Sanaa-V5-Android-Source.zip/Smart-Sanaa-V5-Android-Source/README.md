# Smart Sanaa — Android Native V5 development source

This is a **real Kotlin + Jetpack Compose Android application**, not a WebView. The stable starting point is the V4 source extracted from verified GitHub Actions run #41979240386. This V5 source changes only the Android project; it does not touch Smart Manager at 10.11.0.5:8088, the original panel, or Al-Sharafi.

## What is implemented

- Direct native MikroTik RouterOS TCP API with v6 legacy login challenge and v7 login, bounded binary framing, per-request result verification, TLS with hostname/certificate validation and independent port selection.
- Device discovery, board-name/RouterOS CPU/uptime/memory/disk and router model images.
- Real Hotspot active, PPPoE active and User Manager total counts; an inaccessible count is shown as unavailable, never a made-up zero.
- Native dashboard organized to match the known `smart-new` homepage and its Arabic RTL mobile layout; real navigation to Hotspot, PPPoE, cards, profiles, device, reports, sessions and settings.
- Light/dark theme button persisted using Android SharedPreferences; sensitive router credentials stored with Android Keystore AES-GCM.
- Real Hotspot voucher generation with profile preflight, per-batch unique identifiers, partial-success reporting, PDF export and RTL A4 grid layout; optional serial numbers visible only if checked. Print parameters (61 x 37 mm by default) are validated against A4.
- Read-only User Manager expired-candidate triage with protection for dates such as `غير معروف` (not evidence of expiry). No automatic expiry deletion.
- Native maintenance functions follow detected UM v6/v7 path; require verified UMB backup and explicit confirmation before v6 rebuild/rebuild-log or v7 optimize. NOT yet tested on production routers. Do not execute these maintenance actions without a verified off-router backup and maintenance window.

## Known limitations — NOT production-final

1. Current live PHP panel V28 source is not accessible from this environment; design was matched against the earlier uploaded V14 source and newer screenshots. Exact PHP/Android parity must be audited against the latest live export.
2. User Manager v6/v7 voucher creation and package/profile assignment beyond Hotspot are not fully integrated. Expired card deletion is intentionally not automated until verified on a test router. Reports/AI are partial. The Android print template is not a pixel-identical clone of the PHP print design.
3. V5 has **not been compiled** against Android SDK or installed on phone/MikroTik. Only pure Kotlin layout/safety tests ran locally. The existing V4 APK was compiled and verified separately; do not represent it as V5.
4. Application ID remains `com.smartsanaa.manager`; debug APK signing keys may differ between GitHub runners, meaning a new APK may not update an older installation. Production updates require one persistent release keystore.
5. Native RouterOS API needs a routable MikroTik API host, which may differ from OpenWrt panel host `10.11.0.5`. TLS verification requires a trusted certificate and matching hostname.

## How to build from the extracted source

Open this folder in Android Studio with JDK 17 and Android SDK 36. Run `gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug`, or place extracted files at a GitHub repository root on an **isolated feature branch** and use `.github/workflows/android.yml`. The workflow tests, lints, assembles and verifies debug APK metadata. Do not overwrite `main` or deploy to a live router for app-building.

Package: `com.smartsanaa.manager`; minSdk 26; targetSdk 35; AGP 8.13.0; Gradle 8.13.

## Reference

- MikroTik official RouterOS API: https://manual.mikrotik.com/docs/developer-guides/api/
- MikroTik official User Manager: https://manual.mikrotik.com/docs/authentication-authorization-accounting/user-manager/
