package com.smartsanaa.manager

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

private val Cyan = Color(0xFF1599D2)
private val Blue = Color(0xFF2563A8)
private val Muted = Color(0xFF66788A)
private val Green = Color(0xFF1D9A70)
private val Red = Color(0xFFC94A54)
private val Amber = Color(0xFFB7791F)

/** The menu intentionally contains only real, useful application sections. */
enum class Screen(val arabic: String) {
    LOGIN("الاتصال بالراوتر"), HOME("الرئيسية"), USERS("العملاء"), USER_DETAILS("تفاصيل السجل"),
    CARDS("الكروت"), CREATE_CARD("إضافة كروت"), CREATE_USER("إضافة مستخدم"), PACKAGES("الباقات"), CREATE_PACKAGE("إضافة باقة"),
    HOTSPOT("Hotspot"), PPPOE("PPPoE"), SESSIONS("الجلسات"), DEVICE("معلومات الراوتر"),
    REPORTS("التقارير"), SETTINGS("الإعدادات"), EXPIRED("الكروت المنتهية"), MAINTENANCE("صيانة User Manager")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartManagerApp() }
    }
}

@Composable
fun SmartManagerApp() {
    val context = LocalContext.current
    val store = remember { SecureConfig(context) }
    var config by remember { mutableStateOf(store.get()) }
    var page by remember { mutableStateOf(Screen.LOGIN) }
    var connected by remember { mutableStateOf(false) }
    var board by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var liveCounts by remember { mutableStateOf(DashboardCounts()) }
    val uiPrefs = remember { context.getSharedPreferences("smart_sanaa_ui", android.content.Context.MODE_PRIVATE) }
    var darkMode by remember { mutableStateOf(uiPrefs.getBoolean("dark_mode", false)) }
    var rememberConnection by remember { mutableStateOf(uiPrefs.getBoolean("remember_connection", true)) }
    var rows by remember { mutableStateOf<List<Map<String, String>>>(emptyList()) }
    var selected by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var selectedRoot by remember { mutableStateOf("") }
    var selectedIsSession by remember { mutableStateOf(false) }
    var detailOrigin by remember { mutableStateOf(Screen.USERS) }
    var createOrigin by remember { mutableStateOf(Screen.USERS) }
    var selectedIsProfile by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var source by remember { mutableStateOf("Hotspot") }
    var tab by remember { mutableStateOf(0) }
    var pendingDelete by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var api by remember { mutableStateOf<RouterOsApi?>(null) }
    var repository by remember { mutableStateOf<RouterRepository?>(null) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)

    DisposableEffect(Unit) { onDispose { api?.close() } }

    // Small live RouterOS resource query while the dashboard is visible. Never replay writes.
    LaunchedEffect(page, connected, repository) {
        val current = repository
        if (connected && page == Screen.HOME && current != null) {
            while (true) {
                delay(5_000L)
                runCatching { current.liveResource() }.onSuccess { snapshot ->
                    // Do not overwrite identity or capability metadata with incomplete readings.
                    if (snapshot.isNotEmpty()) board = board + snapshot
                }
            }
        }
    }

    fun logout() {
        api?.close(); api = null; repository = null
        config = store.get(); connected = false; board = emptyMap()
        liveCounts = DashboardCounts(); rows = emptyList(); selected = emptyMap()
        page = Screen.LOGIN; message = ""
    }

    fun goto(next: Screen) {
        if (next in listOf(Screen.CREATE_USER, Screen.CREATE_CARD, Screen.CREATE_PACKAGE)) createOrigin = if (page in listOf(Screen.CREATE_USER, Screen.CREATE_CARD, Screen.CREATE_PACKAGE)) createOrigin else page
        if (next in listOf(Screen.CARDS, Screen.CREATE_CARD) && source == "PPPoE") source = "Hotspot"
        if (next == Screen.HOTSPOT) { source = "Hotspot"; if (page != next && !(page == Screen.USER_DETAILS && detailOrigin == next)) tab = 0 }
        if (next == Screen.PPPOE) { source = "PPPoE"; if (page != next && !(page == Screen.USER_DETAILS && detailOrigin == next)) tab = 0 }
        if (next == Screen.SESSIONS && page != next) tab = if (source == "User Manager") 1 else 0
        page = next; rows = emptyList(); search = ""; message = ""
    }

    fun fetch(next: Screen, initialTab: Int? = null) {
        goto(next)
        if (initialTab != null) tab = initialTab
        val repo = repository
        val path = repo?.path(next, source, tab)
        if (path == null) {
            if (next in listOf(Screen.USERS, Screen.CARDS, Screen.PACKAGES, Screen.SESSIONS)) {
                message = repo?.um?.status ?: "اتصل بالراوتر أولًا"
            }
            return
        }
        if (!connected) { message = "اتصل بالراوتر أولًا"; return }
        busy = true
        scope.launch {
            runCatching {
                if (next == Screen.SESSIONS) repo.listSessions(source, when (tab) { 1 -> "active"; 2 -> "ended"; else -> "all" })
                else repo.list(path)
            }
                .onSuccess { rows = it; message = "تم تحديث البيانات من الراوتر" }
                .onFailure {
                    message = it.message ?: "فشل جلب البيانات"
                    if (it is RouterOsException && it.kind in setOf(ApiError.NETWORK, ApiError.AUTH, ApiError.TLS)) connected = false
                }
            busy = false
        }
    }

    fun refreshDashboard() {
        val repo = repository ?: return
        scope.launch {
            runCatching { repo.discover() }
                .onSuccess { board = it }
                .onFailure { message = it.message ?: "تعذرت قراءة معلومات النظام" }
            runCatching { repo.dashboardCounts() }
                .onSuccess { liveCounts = it }
                .onFailure { message = it.message ?: "تعذرت قراءة الإحصاءات" }
        }
    }

    fun connect() {
        busy = true; message = "جار الاتصال بالراوتر…"
        scope.launch {
            runCatching {
                config.validate()
                api?.close()
                val session = RouterOsApi(config)
                api = session
                val repo = RouterRepository(session)
                repository = repo
                repo.discover()
            }.onSuccess {
                if (rememberConnection) store.save(config) else store.clear()
                board = it; connected = true; page = Screen.HOME
                message = "تم الاتصال بالراوتر بنجاح"
                refreshDashboard()
            }.onFailure {
                api?.close(); api = null; repository = null
                board = emptyMap(); liveCounts = DashboardCounts()
                connected = false; message = it.message ?: "فشل الاتصال بالراوتر"
            }
            busy = false
        }
    }

    BackHandler(drawerState.isOpen) { scope.launch { drawerState.close() } }
    BackHandler(page != Screen.LOGIN && page != Screen.HOME) {
        when (page) {
            Screen.USER_DETAILS -> { page = detailOrigin; message = "" }
            Screen.CREATE_USER, Screen.CREATE_CARD -> fetch(createOrigin)
            Screen.CREATE_PACKAGE -> fetch(Screen.PACKAGES)
            else -> { page = Screen.HOME; message = "" }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = if (darkMode) darkColorScheme(
                primary = Color(0xFF39C9E6), secondary = Color(0xFF78A8FF),
                background = Color(0xFF0B1725), surface = Color(0xFF14263A),
                onSurface = Color(0xFFF2F7FC), onBackground = Color.White,
                onSurfaceVariant = Color(0xFFB9C8D8), outlineVariant = Color(0xFF30465D)
            ) else lightColorScheme(
                primary = Cyan, secondary = Blue, background = Color(0xFFF3F7FB),
                surface = Color.White, onSurface = Color(0xFF142B45), onBackground = Color(0xFF142B45),
                onSurfaceVariant = Muted, outlineVariant = Color(0xFFDCE6EF)
            )
        ) {
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.background) {
                        SideMenu(page, connected, { next ->
                            scope.launch { drawerState.close() }
                            if (next == Screen.USERS) source = "User Manager"
                            fetch(next)
                            if (next == Screen.HOME) refreshDashboard()
                        }, { scope.launch { drawerState.close() }; logout() })
                    }
                }
            ) {
                Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).safeDrawingPadding().imePadding()) {
                    if (page != Screen.LOGIN) {
                        AppHeader(page, connected, darkMode, { scope.launch { drawerState.open() } }, {
                            darkMode = !darkMode; uiPrefs.edit().putBoolean("dark_mode", darkMode).apply()
                        })
                    }
                    Box(Modifier.weight(1f)) {
                        when (page) {
                            Screen.LOGIN -> LoginScreen(config, { config = it }, { connect() }, busy, message,
                                rememberConnection, { checked ->
                                    rememberConnection = checked
                                    uiPrefs.edit().putBoolean("remember_connection", checked).apply()
                                    if (!checked) store.clear()
                                })
                            Screen.HOME -> HomeScreen(board, liveCounts, connected, message, { refreshDashboard() }, {
                                if (it == Screen.USERS) source = "User Manager"
                                if (it == Screen.SESSIONS && repository?.um?.path != null) source = "User Manager"
                                fetch(it)
                            })
                            Screen.USERS, Screen.CARDS, Screen.PACKAGES, Screen.HOTSPOT, Screen.PPPOE, Screen.SESSIONS -> {
                                ManagementListScreen(
                                    page = page, source = source, tab = tab, rows = rows, busy = busy,
                                    message = message, search = search, repo = repository,
                                    onSource = {
                                        source = it
                                        if (page == Screen.SESSIONS) tab = if (it == "User Manager") 1 else 0
                                        fetch(page)
                                    },
                                    onTab = { tab = it; fetch(page) },
                                    onSearch = { search = it }, onRefresh = { fetch(page) },
                                    onCreate = {
                                        createOrigin = page
                                        when (page) {
                                            Screen.PACKAGES -> goto(Screen.CREATE_PACKAGE)
                                            Screen.CARDS -> goto(Screen.CREATE_CARD)
                                            Screen.USERS, Screen.HOTSPOT, Screen.PPPOE -> goto(Screen.CREATE_USER)
                                            else -> Unit
                                        }
                                    },
                                    onQuickNavigation = { destination ->
                                        if (destination == Screen.SESSIONS && repository?.um?.path != null) source = "User Manager"
                                        if (destination == Screen.HOTSPOT) source = "Hotspot"
                                        fetch(destination, if (destination == Screen.HOTSPOT) 1 else null)
                                    },
                                    onDetails = { row, root ->
                                        selected = row; selectedRoot = root; detailOrigin = page
                                        selectedIsSession = page == Screen.SESSIONS || (page == Screen.HOTSPOT && tab == 1) || (page == Screen.PPPOE && tab == 1)
                                        selectedIsProfile = page == Screen.PACKAGES || (page == Screen.HOTSPOT && tab == 2) || (page == Screen.PPPOE && tab == 2)
                                        page = Screen.USER_DETAILS
                                    }
                                )
                            }
                            Screen.USER_DETAILS -> DetailScreen(
                                row = selected, root = selectedRoot, origin = detailOrigin, isSession = selectedIsSession, isProfile = selectedIsProfile,
                                onBack = { page = detailOrigin },
                                onToggle = { disable ->
                                    val id = selected[".id"].orEmpty(); val r = repository
                                    if (r != null && id.isNotBlank()) scope.launch {
                                        busy = true
                                        runCatching { r.setDisabled(selectedRoot, id, disable) }
                                            .onSuccess { message = if (disable) "تم تعطيل الحساب" else "تم تفعيل الحساب"; fetch(detailOrigin) }
                                            .onFailure { message = it.message ?: "فشل تعديل الحساب" }
                                        busy = false
                                    }
                                },
                                onDelete = { pendingDelete = true }
                            )
                            Screen.CREATE_CARD -> VoucherCreator(repository, connected, source, onFinish = { page = Screen.HOME }) { service, msg ->
                                source = service
                                message = msg
                            }
                            Screen.CREATE_USER -> UserCreatorScreen(repository, connected, source, { service, msg ->
                                source = service
                                message = msg
                                if (msg.startsWith("تم إنشاء")) fetch(when (service) { "Hotspot" -> Screen.HOTSPOT; "PPPoE" -> Screen.PPPOE; else -> Screen.USERS })
                            }, { page = createOrigin; fetch(createOrigin) })
                            Screen.CREATE_PACKAGE -> PackageCreatorScreen(repository, connected, source, { service, msg ->
                                source = service
                                message = msg
                                if (msg.startsWith("تم إنشاء")) fetch(Screen.PACKAGES)
                            }, { page = Screen.PACKAGES; fetch(Screen.PACKAGES) })
                            Screen.DEVICE -> DeviceScreen(board, rows, busy, message, { refreshDashboard(); fetch(Screen.DEVICE) })
                            Screen.REPORTS -> ReportsScreen(
                                liveCounts, board, rows, busy, message, { refreshDashboard(); fetch(Screen.REPORTS) }, connected,
                                { target ->
                                    if (target == Screen.SESSIONS && repository?.um?.path != null) source = "User Manager"
                                    if (target == Screen.USERS) source = "User Manager"
                                    fetch(target)
                                },
                                { source = "Hotspot"; fetch(Screen.HOTSPOT, initialTab = 1) }
                            )
                            Screen.SETTINGS -> SettingsScreen(config, { config = it }, { connect() }, message, busy, darkMode, {
                                darkMode = !darkMode; uiPrefs.edit().putBoolean("dark_mode", darkMode).apply()
                            })
                            Screen.EXPIRED -> ExpiredScreen(repository, connected)
                            Screen.MAINTENANCE -> MaintenanceScreen(repository, connected) { fetch(Screen.EXPIRED) }
                            else -> Unit
                        }
                    }
                    if (page !in listOf(Screen.LOGIN, Screen.USER_DETAILS)) {
                        BottomNav(page) {
                            if (it == Screen.USERS) source = "User Manager"
                            fetch(it)
                            if (it == Screen.HOME) refreshDashboard()
                        }
                    }
                }
            }
        }
    }

    if (pendingDelete) AlertDialog(
        onDismissRequest = { pendingDelete = false },
        title = { Text(when {
            selectedIsSession && selectedRoot.contains("/user-manager/session") -> "تأكيد حذف سجل الجلسة"
            selectedIsSession -> "تأكيد فصل الجلسة"
            selectedIsProfile -> "تأكيد حذف الباقة"
            else -> "تأكيد حذف الحساب"
        }) },
        text = { Text(when {
            selectedIsSession && selectedRoot.contains("/user-manager/session") -> "سيتم حذف سجل الجلسة المحدد فقط. لا يستخدم هذا الأمر لفصل جلسة نشطة."
            selectedIsSession -> "سيتم فصل الجلسة النشطة المحددة من الراوتر."
            selectedIsProfile -> "سيتم حذف ملف الباقة من الراوتر. إذا كان مستخدمًا فقد يرفض الراوتر العملية؛ لن يتم حذف المستخدمين."
            else -> "سيتم حذف الحساب المحدد من الراوتر نهائيًا. لا يمكن التراجع عن هذه العملية."
        }) },
        confirmButton = {
            TextButton(onClick = {
                pendingDelete = false
                val r = repository; val id = selected[".id"].orEmpty()
                if (r != null && id.isNotBlank()) scope.launch {
                    busy = true
                    runCatching {
                        if (selectedIsSession || selectedIsProfile) r.remove(selectedRoot, id)
                        else r.deleteUser(source, id)
                    }
                        .onSuccess { message = when {
                            selectedIsSession && selectedRoot.contains("/user-manager/session") -> "تم حذف سجل الجلسة"
                            selectedIsSession -> "تم فصل الجلسة"
                            selectedIsProfile -> "تم حذف الباقة"
                            else -> "تم حذف السجل"
                        }; fetch(detailOrigin) }
                        .onFailure { message = it.message ?: "فشل الحذف" }
                    busy = false
                }
            }) { Text(when {
                selectedIsSession && selectedRoot.contains("/user-manager/session") -> "حذف سجل الجلسة"
                selectedIsSession -> "فصل الجلسة"
                selectedIsProfile -> "حذف الباقة"
                else -> "حذف نهائي"
            }, color = Red) }
        },
        dismissButton = { TextButton(onClick = { pendingDelete = false }) { Text("إلغاء") } }
    )
}

@Composable
private fun AppHeader(page: Screen, connected: Boolean, darkMode: Boolean, openMenu: () -> Unit, toggleTheme: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        IconButton(onClick = openMenu) { Icon(Icons.Default.Menu, "القائمة", tint = Cyan) }
        Image(painterResource(R.drawable.smart_sanaa_launcher), "شعار سمارت صنعاء", Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)))
        Column(Modifier.weight(1f)) {
            Text("سمارت صنعاء", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
            Text(page.arabic, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton(onClick = toggleTheme) { Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "تبديل المظهر", tint = Cyan) }
        Box(Modifier.size(10.dp).background(if (connected) Green else Red, CircleShape))
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
}

@Composable
private fun LoginScreen(config: RouterConfig, update: (RouterConfig) -> Unit, submit: () -> Unit, busy: Boolean, message: String,
                        rememberMe: Boolean, onRememberMe: (Boolean) -> Unit) {
    var portText by remember { mutableStateOf(config.port.toString()) }
    var passwordVisible by remember { mutableStateOf(false) }
    // Only the UI changes here; authentication still uses the existing native RouterOS API.
    val loginBlue = Color(0xFF0C356B)
    val loginRed = Color(0xFFC71D31)
    val cardShape = RoundedCornerShape(25.dp)
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF073A82), Color(0xFF438DD2), Color(0xFFF0F7FF), Color(0xFFE8F4FF)))
        ),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 26.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {
        item {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("MikroTik", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Text("RouterOS 6 / 7", color = Color.White.copy(alpha = .88f), fontSize = 12.sp)
                }
                Spacer(Modifier.height(16.dp))
                Box(Modifier.size(104.dp).clip(RoundedCornerShape(26.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFFEB4050), loginRed, Color(0xFF850615))))
                    .border(3.dp, Color.White.copy(alpha = .9f), RoundedCornerShape(26.dp))
                    .padding(5.dp), contentAlignment = Alignment.Center) {
                    Image(painterResource(R.drawable.smart_sanaa_launcher), "أيقونة سمارت صنعاء الأصلية",
                        Modifier.fillMaxSize().clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.Fit)
                }
                Spacer(Modifier.height(10.dp))
                Text("سمارت صنعاء", fontWeight = FontWeight.Black, fontSize = 32.sp, color = Color.White)
                Text("إدارة شبكات MikroTik بسهولة واحترافية", color = Color.White, fontSize = 14.sp,
                    textAlign = TextAlign.Center)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().clip(cardShape)
                .background(Color.White.copy(alpha = .98f))
                .border(1.dp, Color(0xFFBBD6EE), cardShape)
                .padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Icon(Icons.Default.Router, null, tint = loginRed, modifier = Modifier.size(28.dp))
                    Text("تسجيل الدخول إلى الراوتر", color = loginBlue,
                        fontWeight = FontWeight.ExtraBold, fontSize = 21.sp)
                }
                Text("أدخل بيانات اتصال الراوتر", fontSize = 12.sp, color = Muted)
                LoginInput("عنوان IP أو اسم المضيف", config.host, Icons.Default.Wifi, { update(config.copy(host = it)) })
                LoginInput("اسم المستخدم", config.username, Icons.Default.Person, { update(config.copy(username = it)) })
                OutlinedTextField(value = config.password, onValueChange = { update(config.copy(password = it)) },
                    label = { Text("كلمة المرور") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Lock, null, tint = loginBlue) },
                    trailingIcon = { IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            if (passwordVisible) "إخفاء كلمة المرور" else "إظهار كلمة المرور")
                    } },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    shape = RoundedCornerShape(15.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = portText, onValueChange = {
                        portText = it.filter(Char::isDigit).take(5)
                        update(config.copy(port = portText.toIntOrNull() ?: 0))
                    }, label = { Text("المنفذ") }, modifier = Modifier.weight(1f), singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(15.dp))
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("اتصال مشفر TLS", fontSize = 12.sp, color = loginBlue)
                        Switch(checked = config.tls, onCheckedChange = { update(config.copy(tls = it)) },
                            colors = SwitchDefaults.colors(checkedTrackColor = loginRed))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Checkbox(checked = rememberMe, onCheckedChange = onRememberMe,
                        colors = CheckboxDefaults.colors(checkedColor = loginRed))
                    Text("تذكرني", color = loginBlue, fontWeight = FontWeight.Medium)
                }
                Text(if (config.tls) "تأكد من شهادة الراوتر قبل الاتصال المشفر."
                    else "الاتصال غير مشفر: استخدم شبكة محلية موثوقة أو VPN.",
                    color = Color(0xFF966016), fontSize = 11.sp)
                Button(onClick = submit,
                    enabled = !busy && config.host.isNotBlank() && config.username.isNotBlank() && config.port in 1..65535,
                    colors = ButtonDefaults.buttonColors(containerColor = loginRed),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    Icon(Icons.Default.Login, null)
                    Spacer(Modifier.width(9.dp))
                    Text(if (busy) "جار الاتصال…" else "دخول", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                if (message.isNotBlank()) Text(message,
                    color = if (message.startsWith("تم")) Green else loginRed, fontSize = 13.sp)
            }
        }
        item {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(21.dp))
                .background(Color.White.copy(alpha = .96f))
                .border(1.dp, Color(0xFFBCD7F0), RoundedCornerShape(21.dp))
                .padding(horizontal = 16.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Icon(Icons.Default.Code, null, tint = loginRed)
                Column(Modifier.weight(1f)) {
                    Text("برمجة وتطوير", color = loginBlue, fontWeight = FontWeight.Medium, fontSize = 12.sp)
                    Text("عبدالله عوض", color = loginRed, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                }
                Icon(Icons.Default.Phone, null, tint = loginRed)
                Text("775070442", color = loginBlue, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun LoginInput(label: String, value: String, icon: ImageVector, onChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = onChange, label = { Text(label) },
        modifier = Modifier.fillMaxWidth(), singleLine = true,
        leadingIcon = { Icon(icon, null, tint = Color(0xFF174A81)) },
        shape = RoundedCornerShape(15.dp))
}

@Composable
private fun EntryField(label: String, value: String, onChange: (String) -> Unit, secret: Boolean = false, number: Boolean = false) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        modifier = Modifier.fillMaxWidth(), singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (secret) KeyboardType.Password else if (number) KeyboardType.Number else KeyboardType.Text)
    )
}

@Composable
private fun HomeScreen(
    board: Map<String, String>, counts: DashboardCounts, connected: Boolean, message: String,
    reload: () -> Unit, navigate: (Screen) -> Unit
) {
    val routerName = board["board-name"].orEmpty()
    val memoryUsed = usedPercent(board["total-memory"], board["free-memory"])
    val storageUsed = usedPercent(board["total-hdd-space"], board["free-hdd-space"])
    val routerImage = when {
        routerName.contains("RB2011", true) -> R.drawable.router_rb2011
        routerName.contains("RB951", true) -> R.drawable.router_rb951
        routerName.contains("RB1100", true) -> R.drawable.router_rb1100
        else -> R.drawable.router_generic
    }
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                MiniStatus("RouterOS", board["version"]?.substringBefore(' ').orEmpty().ifBlank { "—" }, Blue, Modifier.weight(1.1f))
                MiniStatus("CPU", board["cpu-load"]?.let { "$it%" } ?: "—", Color(0xFF7655D5), Modifier.weight(.9f))
                MiniStatus("مدة التشغيل", board["uptime"] ?: "—", Green, Modifier.weight(1.1f))
            }
        }
        item { Image(painterResource(R.drawable.smart_sanaa_banner), "سمارت صنعاء لإدارة MikroTik", Modifier.fillMaxWidth().height(158.dp).clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.Crop) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HomeAction("الرئيسية", Icons.Default.Home, Modifier.weight(1f)) { navigate(Screen.HOME) }
                HomeAction("إضافة كروت", Icons.Default.AddCard, Modifier.weight(1f)) { navigate(Screen.CREATE_CARD) }
                HomeAction("عمليات الكروت", Icons.Default.CreditCard, Modifier.weight(1f)) { navigate(Screen.CARDS) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                LiveMetric("Hotspot نشط", counts.hotspot.text(), if (counts.hotspotUsers.value != null) "من ${counts.hotspotUsers.text()} حساب" else counts.hotspotUsers.reason ?: "عدد الحسابات غير متاح", Icons.Default.Wifi, Color(0xFF12A6BB), Modifier.weight(1f)) { navigate(Screen.HOTSPOT) }
                LiveMetric("PPPoE نشط", counts.pppoe.text(), "جلسات مباشرة", Icons.Default.Router, Color(0xFF7C5DE3), Modifier.weight(1f)) { navigate(Screen.PPPOE) }
            }
        }
        item { LiveMetric("إجمالي كروت User Manager", counts.userManager.text(), if (counts.userManager.value == null) counts.userManager.reason ?: "غير متاح" else "عدد حقيقي من الراوتر", Icons.Default.Groups, Green, Modifier.fillMaxWidth()) { navigate(Screen.USERS) } }
        item { Text("الوصول السريع", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HomeAction("الباقات", Icons.Default.Layers, Modifier.weight(1f)) { navigate(Screen.PACKAGES) }
                    HomeAction("الجلسات", Icons.Default.AccessTime, Modifier.weight(1f)) { navigate(Screen.SESSIONS) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HomeAction("الكروت المنتهية", Icons.Default.EventBusy, Modifier.weight(1f)) { navigate(Screen.EXPIRED) }
                    HomeAction("مراجعة وتنظيف", Icons.Default.Build, Modifier.weight(1f)) { navigate(Screen.MAINTENANCE) }
                }
            }
        }
        item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Image(
                        painterResource(routerImage), "راوتر MikroTik ${routerName.ifBlank { "غير معروف" }}",
                        Modifier.size(102.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Fit
                    )
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("معلومات الراوتر", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                        Text(routerName.ifBlank { "الطراز غير متاح" }, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(board["identity"].orEmpty().ifBlank { "—" }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        Text("RouterOS ${board["version"]?.substringBefore(' ') ?: "—"} · ${board["architecture-name"] ?: "—"}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RouterQuickStat("CPU", board["cpu-load"]?.let { "$it%" } ?: "—", Modifier.weight(1f))
                    RouterQuickStat("الذاكرة", memoryUsed?.let { "$it%" } ?: "—", Modifier.weight(1f))
                    RouterQuickStat("التخزين", storageUsed?.let { "$it%" } ?: "—", Modifier.weight(1f))
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("وقت التشغيل: ${board["uptime"] ?: "—"}", Modifier.weight(1f), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    TextButton(onClick = { navigate(Screen.DEVICE) }) { Text("التفاصيل"); Icon(Icons.Default.ChevronLeft, null, modifier = Modifier.size(17.dp)) }
                }
            }
        }
        item {
            OutlinedButton(onClick = reload, enabled = connected, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(7.dp)); Text("تحديث إحصاءات الراوتر")
            }
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
    }
}

@Composable
private fun RouterQuickStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = .24f), RoundedCornerShape(12.dp)).padding(vertical = 9.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

private fun usedPercent(totalRaw: String?, freeRaw: String?): Int? {
    val total = parseRouterBytes(totalRaw) ?: return null
    val free = parseRouterBytes(freeRaw) ?: return null
    if (total <= 0L || free < 0L) return null
    return (((total - free).coerceAtLeast(0L) * 100.0) / total).toInt().coerceIn(0, 100)
}

@Composable
private fun ResourceProgress(label: String, percent: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("$percent%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
            Box(Modifier.fillMaxWidth(percent / 100f).fillMaxHeight().background(if (percent >= 85) Red else Cyan))
        }
    }
}

@Composable
private fun MiniStatus(name: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(17.dp)).background(MaterialTheme.colorScheme.surface)
            .border(1.dp, accent.copy(alpha = .3f), RoundedCornerShape(17.dp)).padding(horizontal = 7.dp, vertical = 11.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(name, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface, maxLines = 2, textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun LiveMetric(title: String, value: String, caption: String, icon: ImageVector, accent: Color, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    Column(modifier.clip(RoundedCornerShape(19.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, accent.copy(alpha = .25f), RoundedCornerShape(19.dp))
        .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(23.dp)); Text(title, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(value, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface)
        Text(caption, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun HomeAction(title: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick, modifier = modifier.heightIn(min = 57.dp), shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Cyan.copy(alpha = .3f)), contentPadding = PaddingValues(horizontal = 7.dp, vertical = 9.dp)
    ) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(19.dp)); Spacer(Modifier.width(5.dp))
        Text(title, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ManagementListScreen(
    page: Screen, source: String, tab: Int, rows: List<Map<String, String>>, busy: Boolean,
    message: String, search: String, repo: RouterRepository?, onSource: (String) -> Unit, onTab: (Int) -> Unit,
    onSearch: (String) -> Unit, onRefresh: () -> Unit, onCreate: () -> Unit,
    onQuickNavigation: (Screen) -> Unit, onDetails: (Map<String, String>, String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val services = when (page) {
        Screen.CARDS -> listOf("Hotspot", "User Manager")
        else -> listOf("Hotspot", "PPPoE", "User Manager")
    }
    val canChooseSource = page in listOf(Screen.USERS, Screen.CARDS, Screen.PACKAGES, Screen.SESSIONS)
    val canChooseTab = page == Screen.HOTSPOT || page == Screen.PPPOE
    val canFilterSessions = page == Screen.SESSIONS && source == "User Manager"
    val root = repo?.recordRoot(page, source, tab)
    val title = when (page) {
        Screen.USERS -> "إدارة العملاء"
        Screen.CARDS -> "عمليات الكروت"
        Screen.PACKAGES -> "الباقات"
        Screen.HOTSPOT -> "إدارة Hotspot"
        Screen.PPPOE -> "إدارة PPPoE"
        else -> "الجلسات"
    }
    var pageSize by remember(page, source, tab) { mutableStateOf(if (page == Screen.CARDS) 100 else 50) }
    var currentPage by remember(page, source, tab) { mutableStateOf(0) }
    var selectedIds by remember(page, source, tab, currentPage) { mutableStateOf(setOf<String>()) }
    var bulkBusy by remember { mutableStateOf(false) }
    var bulkStatus by remember { mutableStateOf("") }
    var pendingBulkAction by remember { mutableStateOf<String?>(null) }
    var showPageSizeMenu by remember { mutableStateOf(false) }

    LaunchedEffect(search, page, source, tab) {
        currentPage = 0
        selectedIds = emptySet()
        bulkStatus = ""
    }

    val filtered = rows.filter { row ->
        Privacy.display(row).values.any { it.contains(search, ignoreCase = true) }
    }
    val pageCount = maxOf(1, (filtered.size + pageSize - 1) / pageSize)
    val safePage = currentPage.coerceIn(0, pageCount - 1)
    val visibleRows = filtered.drop(safePage * pageSize).take(pageSize)
    val visibleIds = visibleRows.mapNotNull { it[".id"]?.takeIf(String::isNotBlank) }.toSet()
    val selectableIds = visibleIds.take(100).toSet() // same limit enforced by RouterRepository
    val allVisibleSelected = selectableIds.isNotEmpty() && selectedIds.containsAll(selectableIds)
    val canBulk = root != null && (page == Screen.CARDS || page == Screen.USERS ||
        page == Screen.HOTSPOT && tab == 0 || page == Screen.PPPOE && tab == 0)

    fun executeBulk(action: String) {
        val r = repo ?: return
        val target = root ?: return
        val ids = selectedIds.toList()
        if (ids.isEmpty()) return
        scope.launch {
            bulkBusy = true
            bulkStatus = "جار تنفيذ العملية على ${ids.size} سجلًا…"
            runCatching {
                if (action == "delete") r.bulkDeleteUsers(source, ids)
                else r.bulkSetDisabled(target, ids, action == "disable")
            }.onSuccess { outcome ->
                bulkStatus = if (outcome.complete) {
                    "تم ${if (action == "delete") "حذف" else if (action == "disable") "تعطيل" else "تفعيل"} ${outcome.confirmedIds.size} سجلًا بنجاح."
                } else {
                    val failedIds = outcome.failedIds.take(5).joinToString(", ")
                    "تم تأكيد ${outcome.confirmedIds.size} من ${ids.size}. ${if (outcome.uncertain) "النتيجة الأخيرة غير مؤكدة؛ حدّث القائمة قبل أي إعادة محاولة." else "راجع السجلات التي رفضها الراوتر."} ${if (failedIds.isNotBlank()) "المعرّفات غير المؤكدة: $failedIds. " else ""}${outcome.detail}"
                }
                selectedIds = emptySet()
                onRefresh()
            }.onFailure {
                bulkStatus = "لم تكتمل العملية: ${it.message}. حدّث القائمة قبل إعادة المحاولة."
            }
            bulkBusy = false
        }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(if (page == Screen.CARDS) 7.dp else 11.dp)) {
        item { PageHeading(title, if (page == Screen.CARDS) "بحث وتحديد وإدارة الكروت مباشرة من الراوتر" else "بيانات حقيقية من جهاز MikroTik المتصل") }
        if (page == Screen.CARDS) item {
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf(
                    Triple("كل الكروت", Screen.CARDS, Icons.Default.CreditCard),
                    Triple("المتصلون", Screen.HOTSPOT, Icons.Default.Wifi),
                    Triple("المنتهية", Screen.EXPIRED, Icons.Default.EventBusy),
                    Triple("الجلسات", Screen.SESSIONS, Icons.Default.AccessTime)
                ).forEach { (label, destination, icon) ->
                    val active = destination == Screen.CARDS
                    OutlinedButton(
                        onClick = { if (!active) onQuickNavigation(if (destination == Screen.HOTSPOT && source == "User Manager") Screen.SESSIONS else destination) },
                        modifier = Modifier.weight(1f).heightIn(min = 58.dp),
                        border = BorderStroke(1.dp, if (active) Cyan else MaterialTheme.colorScheme.outlineVariant),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = if (active) Cyan.copy(alpha = .13f) else MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(2.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(icon, null, modifier = Modifier.size(17.dp), tint = if (active) Cyan else Muted)
                            Text(label, fontSize = 10.sp, maxLines = 1, color = if (active) Cyan else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        }
        if (canChooseSource) item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                services.forEach { service ->
                    FilterChip(
                        selected = source == service,
                        onClick = { selectedIds = emptySet(); onSource(service) },
                        enabled = service != "User Manager" || repo?.um?.path != null,
                        label = { Text(if (service == "User Manager") repo?.routerVersion?.let { "User Manager ${if (repo.isRouterOsV6) "6" else "7"}" } ?: service else service, fontSize = 12.sp) }
                    )
                }
            }
        }
        if (canChooseTab) item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("الحسابات", "المتصلون", "الباقات").forEachIndexed { index, label ->
                    FilterChip(selected = tab == index, onClick = { selectedIds = emptySet(); onTab(index) }, label = { Text(label, fontSize = 12.sp) })
                }
            }
        }
        if (canFilterSessions) item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("الكل", "نشطة", "منتهية").forEachIndexed { index, label ->
                    FilterChip(selected = tab == index, onClick = { selectedIds = emptySet(); onTab(index) }, label = { Text(label) })
                }
            }
        }
        item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (busy || bulkBusy) "جار تنفيذ العملية…" else "السجلات المطابقة", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        Text(filtered.size.toString(), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    IconButton(onClick = onRefresh, enabled = !bulkBusy) { Icon(Icons.Default.Refresh, "تحديث", tint = Cyan) }
                    if (page in listOf(Screen.CARDS, Screen.PACKAGES, Screen.USERS) || (page == Screen.HOTSPOT && tab == 0) || (page == Screen.PPPOE && tab == 0)) {
                        IconButton(onClick = onCreate, enabled = !bulkBusy) { Icon(Icons.Default.Add, "إضافة", tint = Green) }
                    }
                }
                OutlinedTextField(
                    search, onSearch, modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("بحث بالاسم أو رقم الكرت") }, leadingIcon = { Icon(Icons.Default.Search, null) }
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("عرض ${if (filtered.isEmpty()) 0 else safePage * pageSize + 1}–${minOf((safePage + 1) * pageSize, filtered.size)} من ${filtered.size}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Box {
                        TextButton(onClick = { showPageSizeMenu = true }) { Text("${pageSize} سجلًا") }
                        DropdownMenu(expanded = showPageSizeMenu, onDismissRequest = { showPageSizeMenu = false }) {
                            listOf(25, 50, 100, 200).forEach { size ->
                                DropdownMenuItem(text = { Text("$size سجلًا") }, onClick = {
                                    pageSize = size; currentPage = 0; selectedIds = emptySet(); showPageSizeMenu = false
                                })
                            }
                        }
                    }
                }
            }
        }
        if (canBulk) item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = allVisibleSelected,
                        onCheckedChange = { checked ->
                            selectedIds = if (checked) selectedIds + selectableIds else selectedIds - visibleIds
                        }, enabled = !bulkBusy && visibleIds.isNotEmpty()
                    )
                    Text("تحديد السجلات المعروضة", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    Text("${selectedIds.size} محدد", color = Cyan, fontWeight = FontWeight.Bold)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { pendingBulkAction = "enable" },
                        enabled = !bulkBusy && selectedIds.isNotEmpty(), modifier = Modifier.weight(1f)
                    ) { Text("تفعيل") }
                    OutlinedButton(
                        onClick = { pendingBulkAction = "disable" },
                        enabled = !bulkBusy && selectedIds.isNotEmpty(), modifier = Modifier.weight(1f)
                    ) { Text("تعطيل") }
                    Button(
                        onClick = { pendingBulkAction = "delete" },
                        enabled = !bulkBusy && selectedIds.isNotEmpty(), modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Red)
                    ) { Text("حذف") }
                }
                Text("العمليات تطبق على المحدد فقط. عند انقطاع الاتصال لا تعِد تنفيذها قبل تحديث القائمة والتحقق من النتيجة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (bulkStatus.isNotBlank()) Text(bulkStatus, color = if (bulkStatus.startsWith("تم")) Green else Amber, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (busy || bulkBusy) item { LinearProgressIndicator(Modifier.fillMaxWidth(), color = Cyan) }
        if (message.isNotBlank()) item { Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }
        if (!busy && visibleRows.isEmpty()) item {
            PanelCard { Text("لا توجد سجلات للعرض. تحقق من الخدمة والصلاحيات ثم حدّث القائمة.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        if (page == Screen.CARDS && visibleRows.isNotEmpty()) item {
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = .35f), RoundedCornerShape(10.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckBoxOutlineBlank, null, tint = Muted, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(12.dp))
                Text("المستخدم / الباقة / الحالة", Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("الاستخدام", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        items(visibleRows, key = { it[".id"] ?: (it["name"] ?: it["username"] ?: it.hashCode().toString()) }) { row ->
            val display = Privacy.display(row)
            val name = display["name"] ?: display["username"] ?: display["user"] ?: "سجل"
            val detailRoot = root ?: ""
            val id = row[".id"].orEmpty()
            if (page == Screen.CARDS) {
                val profile = display["actual-profile"] ?: display["profile"] ?: display["group"] ?: "—"
                val disabled = display["disabled"].equals("yes", true) || display["disabled"].equals("true", true)
                val used = display["uptime-used"] ?: display["uptime"] ?: "—"
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                        .clickable { onDetails(row, detailRoot) }.padding(horizontal = 8.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    if (id.isNotBlank()) Checkbox(checked = id in selectedIds, onCheckedChange = { checked ->
                        selectedIds = if (checked) (selectedIds + id).take(100).toSet() else selectedIds - id
                    }, enabled = !bulkBusy && (id in selectedIds || selectedIds.size < 100), modifier = Modifier.size(42.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(name, fontWeight = FontWeight.Bold, maxLines = 1, fontSize = 14.sp, overflow = TextOverflow.Ellipsis)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text(profile, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, maxLines = 1)
                            Text(if (disabled) "معطل" else "فعال", color = if (disabled) Red else Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(used, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        Icon(Icons.Default.ChevronLeft, null, tint = Muted, modifier = Modifier.size(17.dp))
                    }
                }
            } else PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (canBulk && id.isNotBlank()) {
                        Checkbox(checked = id in selectedIds, onCheckedChange = { checked ->
                            selectedIds = if (checked) (selectedIds + id).take(100).toSet() else selectedIds - id
                        }, enabled = !bulkBusy && (id in selectedIds || selectedIds.size < 100))
                    }
                    Row(
                        Modifier.weight(1f).clickable { onDetails(row, detailRoot) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(when (page) {
                            Screen.HOTSPOT -> Icons.Default.Wifi
                            Screen.PPPOE -> Icons.Default.Router
                            Screen.PACKAGES -> Icons.Default.Layers
                            Screen.SESSIONS -> Icons.Default.AccessTime
                            else -> Icons.Default.Person
                        }, null, tint = Cyan)
                        Spacer(Modifier.width(9.dp))
                        Text(name, Modifier.weight(1f), fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Icon(Icons.Default.ChevronLeft, null, tint = Muted)
                    }
                }
                val preferred = listOf("profile", "actual-profile", "group", "disabled", "uptime", "uptime-used", "address", "user-address", "ip-address", "user-ip", "host-ip", "mac-address", "service", "rate-limit", "bytes-in", "bytes-out", "download", "upload", "download-used", "upload-used", "state", "end-time", "started", "from-time", "start-time", "ended", "remote-address")
                preferred.forEach { key ->
                    display[key]?.takeIf { it.isNotBlank() }?.let { InfoLine(arabicField(key), arabicValue(key, it)) }
                }
            }
        }
        if (page == Screen.CARDS && pageCount > 1) item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                (0 until minOf(4, pageCount)).forEach { index ->
                    OutlinedButton(onClick = { currentPage = index; selectedIds = emptySet() },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = if (index == safePage) Cyan.copy(alpha = .16f) else MaterialTheme.colorScheme.surface),
                        contentPadding = PaddingValues(0.dp), modifier = Modifier.size(40.dp)) { Text("${index + 1}") }
                }
                if (pageCount > 5) Text("…", color = Muted)
                if (pageCount > 4) {
                    OutlinedButton(onClick = { currentPage = pageCount - 1; selectedIds = emptySet() },
                        shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(0.dp), modifier = Modifier.size(40.dp)) { Text("$pageCount") }
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { currentPage = (safePage - 1).coerceAtLeast(0); selectedIds = emptySet() }, enabled = safePage > 0) {
                    Icon(Icons.Default.ChevronRight, "السابق")
                }
                IconButton(onClick = { currentPage = (safePage + 1).coerceAtMost(pageCount - 1); selectedIds = emptySet() }, enabled = safePage < pageCount - 1) {
                    Icon(Icons.Default.ChevronLeft, "التالي")
                }
            }
            Text("صفحة ${safePage + 1} من $pageCount", fontSize = 12.sp, color = Muted)
        }
        if (page != Screen.CARDS && pageCount > 1) item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { currentPage = (safePage - 1).coerceAtLeast(0) }, enabled = safePage > 0) { Text("السابق") }
                Text("صفحة ${safePage + 1} من $pageCount", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClick = { currentPage = (safePage + 1).coerceAtMost(pageCount - 1) }, enabled = safePage < pageCount - 1) { Text("التالي") }
            }
        }
    }

    pendingBulkAction?.let { action ->
        val actionLabel = when (action) { "enable" -> "تفعيل"; "disable" -> "تعطيل"; else -> "حذف نهائي" }
        AlertDialog(
            onDismissRequest = { pendingBulkAction = null },
            title = { Text("تأكيد $actionLabel") },
            text = {
                Text(if (action == "delete") {
                    "سيتم حذف ${selectedIds.size} مستخدمًا محددًا من $source. في User Manager 7 ستُزال روابط الباقات الخاصة بالمستخدمين المحددين فقط. لا يمكن التراجع عن الحذف."
                } else "سيتم $actionLabel ${selectedIds.size} مستخدمًا محددًا على الراوتر.")
            },
            confirmButton = {
                TextButton(onClick = { pendingBulkAction = null; executeBulk(action) }) {
                    Text("تأكيد $actionLabel", color = if (action == "delete") Red else Cyan)
                }
            },
            dismissButton = { TextButton(onClick = { pendingBulkAction = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun DetailScreen(
    row: Map<String, String>, root: String, origin: Screen, isSession: Boolean, isProfile: Boolean,
    onBack: () -> Unit, onToggle: (Boolean) -> Unit, onDelete: () -> Unit
) {
    val safe = Privacy.display(row)
    val name = safe["name"] ?: safe["username"] ?: safe["user"] ?: "تفاصيل السجل"
    val canToggle = !isSession && root.isNotBlank() && (origin in listOf(Screen.USERS, Screen.CARDS) || origin == Screen.HOTSPOT && root.endsWith("/user") || origin == Screen.PPPOE && root.endsWith("/secret"))
    val umSession = isSession && root.contains("/user-manager/session")
    val sessionActive = safe["active"].equals("true", true) || safe["status"].orEmpty().lowercase().split(',').any { it.trim() in setOf("active", "start", "interim") }
    val canDelete = canToggle || isSession && !(umSession && sessionActive) || isProfile
    val disabled = safe["disabled"]?.equals("true", true) == true || safe["disabled"]?.equals("yes", true) == true
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageHeading(when { isSession -> "تفاصيل الجلسة"; isProfile -> "تفاصيل الباقة"; else -> "تفاصيل الحساب" }, name) }
        item {
            PanelCard {
                Text(name, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                safe.entries.filter { it.key != "name" && it.key != "username" && it.key != "user" }.forEach { (key, value) ->
                    if (value.isNotBlank()) InfoLine(arabicField(key), arabicValue(key, value))
                }
            }
        }
        if (canDelete) item {
            if (canToggle) {
                Button(onClick = { onToggle(!disabled) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = if (disabled) Green else Amber)) {
                    Text(if (disabled) "تفعيل الحساب" else "تعطيل الحساب")
                }
            }
            Button(onClick = onDelete, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                Text(when {
                    isSession && origin == Screen.SESSIONS && root.contains("/user-manager/session") -> "حذف سجل الجلسة"
                    isSession -> "فصل الجلسة النشطة"
                    isProfile -> "حذف الباقة"
                    else -> "حذف الحساب نهائيًا"
                })
            }
        }
        if (umSession && sessionActive) item {
            Text("هذه جلسة User Manager نشطة؛ لا يمكن حذف سجلها من هنا لتجنب الخلط بين حذف السجل وفصل الاتصال.", color = Amber, style = MaterialTheme.typography.bodySmall)
        }
        item { OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("العودة للقائمة") } }
    }
}

private fun arabicField(key: String): String = when (key) {
    ".id" -> "معرّف السجل"; "name", "username", "user" -> "اسم المستخدم"; "profile", "actual-profile" -> "الباقة";
    "disabled" -> "الحالة"; "uptime" -> "مدة الاتصال"; "uptime-used" -> "الاستخدام"; "limit-uptime" -> "حد الاستخدام";
    "address", "user-address", "ip-address", "user-ip", "host-ip" -> "عنوان IP"; "mac-address" -> "عنوان MAC"; "service" -> "الخدمة";
    "rate-limit" -> "حد السرعة"; "bytes-in", "download", "download-used" -> "التحميل"; "bytes-out", "upload", "upload-used" -> "الرفع";
    "state" -> "حالة الباقة"; "end-time" -> "تاريخ الانتهاء"; "started", "from-time", "start-time" -> "بداية الجلسة"; "ended" -> "نهاية الجلسة";
    "remote-address" -> "العنوان البعيد"; "local-address" -> "العنوان المحلي"; "shared-users" -> "المستخدمون المتزامنون";
    "session-timeout" -> "مهلة الجلسة"; "caller-id" -> "معرّف الاتصال"; "comment" -> "ملاحظات";
    "nas-ip-address" -> "عنوان NAS"; "terminate-cause" -> "سبب الإنهاء"; "status" -> "الحالة";
    "last-accounting-packet" -> "آخر تحديث محاسبي"; "topics" -> "نوع الحدث"; "time" -> "الوقت";
    "customer" -> "عميل User Manager"; "name-for-users" -> "الاسم الظاهر"; "validity" -> "مدة الصلاحية";
    "starts-when" -> "بداية الصلاحية"; "price" -> "السعر التعريفي"; "only-one" -> "اتصال واحد فقط";
    "download-used" -> "التحميل المستخدم"; "upload-used" -> "الرفع المستخدم"; "transfer-limit" -> "حد النقل";
    "free-memory" -> "الذاكرة الحرة"; "total-memory" -> "إجمالي الذاكرة"; "free-hdd-space" -> "التخزين الحر";
    "total-hdd-space" -> "إجمالي التخزين"; "cpu-load" -> "استخدام المعالج"; "version" -> "إصدار RouterOS";
    else -> key
}

private fun arabicValue(key: String, value: String): String = when (key) {
    "disabled" -> if (value.equals("true", true) || value.equals("yes", true)) "معطل" else "مفعل"
    "running" -> if (value.equals("true", true) || value.equals("yes", true)) "يعمل" else "متوقف"
    "state" -> when (value.lowercase()) { "used" -> "منتهية"; "running" -> "صالحة"; "running active" -> "نشطة"; else -> value }
    "only-one" -> if (value.equals("true", true) || value.equals("yes", true)) "نعم" else "لا"
    else -> value
}

@Composable
private fun DeviceScreen(board: Map<String, String>, rows: List<Map<String, String>>, busy: Boolean, message: String, reload: () -> Unit) {
    val memoryUsed = usedPercent(board["total-memory"], board["free-memory"])
    val storageUsed = usedPercent(board["total-hdd-space"], board["free-hdd-space"])
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageHeading("معلومات الراوتر", "بيانات النظام والواجهات من RouterOS") }
        item {
            PanelCard {
                InfoLine("اسم الجهاز", board["identity"] ?: "—")
                InfoLine("الطراز", board["board-name"] ?: "—")
                InfoLine("إصدار RouterOS", board["version"] ?: "—")
                InfoLine("المعمارية", board["architecture-name"] ?: "—")
                InfoLine("مدة التشغيل", board["uptime"] ?: "—")
                InfoLine("استخدام CPU", board["cpu-load"]?.let { "$it%" } ?: "—")
                InfoLine("الذاكرة الحرة", board["free-memory"] ?: "—")
                InfoLine("إجمالي الذاكرة", board["total-memory"] ?: "—")
                if (memoryUsed != null) ResourceProgress("استخدام الذاكرة", memoryUsed)
                InfoLine("التخزين الحر", board["free-hdd-space"] ?: "—")
                InfoLine("إجمالي التخزين", board["total-hdd-space"] ?: "—")
                if (storageUsed != null) ResourceProgress("استخدام التخزين", storageUsed)
                OutlinedButton(onClick = reload, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Refresh, null); Text(" تحديث الواجهات") }
            }
        }
        item { Text("واجهات الراوتر", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        items(rows, key = { it[".id"] ?: it["name"].orEmpty() }) { row ->
            PanelCard {
                Text(row["name"] ?: "واجهة", fontWeight = FontWeight.Bold)
                InfoLine("النوع", row["type"] ?: "—")
                InfoLine("الحالة", if (row["running"] == "true") "تعمل" else "متوقفة")
                InfoLine("MTU", row["mtu"] ?: "—")
                InfoLine("تنزيل", row["rx-byte"] ?: "—")
                InfoLine("رفع", row["tx-byte"] ?: "—")
            }
        }
        if (message.isNotBlank()) item { Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }
    }
}

@Composable
private fun ReportsScreen(
    counts: DashboardCounts, board: Map<String, String>, logs: List<Map<String, String>>,
    busy: Boolean, message: String, reload: () -> Unit, connected: Boolean,
    navigate: (Screen) -> Unit, navigateActive: () -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageHeading("التقارير", "إحصاءات مباشرة وسجل أحداث الراوتر") }
        item {
            PanelCard {
                Text("ملخص الشبكة", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                InfoLine("إجمالي كروت Hotspot", counts.hotspotUsers.text())
                InfoLine("Hotspot المتصل", counts.hotspot.text())
                InfoLine("PPPoE المتصل", counts.pppoe.text())
                InfoLine("إجمالي كروت User Manager", counts.userManager.text())
                InfoLine("جلسات User Manager النشطة", counts.userManagerActive.text())
                InfoLine("استخدام CPU", board["cpu-load"]?.let { "$it%" } ?: "—")
                InfoLine("مدة التشغيل", board["uptime"] ?: "—")
                Button(onClick = reload, enabled = connected && !busy, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(7.dp)); Text(if (busy) "جار تحديث التقرير…" else "تحديث التقرير والسجل")
                }
            }
        }
        item {
            PanelCard {
                Text("الوصول إلى التقارير التشغيلية", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HomeAction("الجلسات", Icons.Default.AccessTime, Modifier.weight(1f)) { navigate(Screen.SESSIONS) }
                    HomeAction("المتصلون الآن", Icons.Default.Wifi, Modifier.weight(1f)) { navigateActive() }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HomeAction("الكروت المنتهية", Icons.Default.EventBusy, Modifier.weight(1f)) { navigate(Screen.EXPIRED) }
                    HomeAction("إدارة العملاء", Icons.Default.Groups, Modifier.weight(1f)) { navigate(Screen.USERS) }
                }
            }
        }
        item { Text("سجل النظام", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (logs.isEmpty() && !busy) item {
            PanelCard { Text("لا توجد أحداث معروضة. حدّث السجل أو تحقق من صلاحية قراءة System Log.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        items(logs.take(100), key = { it[".id"] ?: "${it["time"]}-${it["topics"]}" }) { row ->
            PanelCard {
                Text(row["topics"] ?: "حدث نظام", fontWeight = FontWeight.Bold)
                Text(row["time"] ?: "—", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Text(row["message"] ?: "—", style = MaterialTheme.typography.bodyMedium)
            }
        }
        if (message.isNotBlank()) item { Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }
    }
}

@Composable
private fun SettingsScreen(
    config: RouterConfig, save: (RouterConfig) -> Unit, connect: () -> Unit,
    message: String, busy: Boolean, darkMode: Boolean, toggleTheme: () -> Unit
) {
    var portText by remember(config.host) { mutableStateOf(config.port.toString()) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageHeading("الإعدادات", "الاتصال والأمان ومظهر التطبيق") }
        item {
            PanelCard {
                Text("إعدادات اتصال MikroTik", fontWeight = FontWeight.Bold)
                EntryField("عنوان الراوتر", config.host, { save(config.copy(host = it)) })
                EntryField("اسم المستخدم", config.username, { save(config.copy(username = it)) })
                EntryField("كلمة المرور", config.password, { save(config.copy(password = it)) }, secret = true)
                EntryField("منفذ API", portText, { portText = it; save(config.copy(port = it.toIntOrNull() ?: 0)) }, number = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = config.tls, onCheckedChange = { save(config.copy(tls = it)) })
                    Spacer(Modifier.width(8.dp)); Text("تفعيل TLS دون ربطه برقم المنفذ")
                }
                Button(onClick = connect, enabled = !busy && config.port in 1..65535, modifier = Modifier.fillMaxWidth()) { Text("حفظ واختبار الاتصال") }
                if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            PanelCard {
                Text("المظهر", fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (darkMode) "الوضع الداكن" else "الوضع الفاتح", Modifier.weight(1f))
                    Switch(checked = darkMode, onCheckedChange = { toggleTheme() })
                }
            }
        }
        item {
            PanelCard {
                Text("الأمان", fontWeight = FontWeight.Bold)
                Text("تُحفظ بيانات الاتصال محليًا بتشفير Android Keystore. استخدم TLS بشهادة موثوقة، وحساب MikroTik محدود الصلاحيات.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
        }
        item { Text("Smart Sanaa · Native Android · RouterOS v6/v7", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
    }
}

@Composable
private fun SideMenu(page: Screen, connected: Boolean, navigate: (Screen) -> Unit, logout: () -> Unit) {
    val context = LocalContext.current
    // Developer identity is intentionally read-only in the user interface.
    val adminName = "عبدالله عوض"
    val adminPhone = "775070442"
    val telegram = remember { context.getSharedPreferences("smart_sanaa_admin", android.content.Context.MODE_PRIVATE).getString("telegram", "").orEmpty() }
    val drawerItems = listOf(
        Triple(Screen.HOME, "الرئيسية", Icons.Default.Home),
        Triple(Screen.CREATE_CARD, "إضافة كروت", Icons.Default.AddCard),
        Triple(Screen.CARDS, "عمليات الكروت", Icons.Default.CreditCard),
        Triple(Screen.REPORTS, "التقارير", Icons.Default.BarChart)
    )
    val accents = listOf(Cyan, Color(0xFF3184D2), Color(0xFF7760D7), Green)
    fun openContact(url: String?) {
        if (url != null) runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }
    LazyColumn(
        Modifier.fillMaxHeight().widthIn(min = 280.dp, max = 336.dp),
        contentPadding = PaddingValues(15.dp), verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface)
                .border(1.dp, Cyan.copy(alpha = .25f), RoundedCornerShape(20.dp)).padding(13.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                Image(painterResource(R.drawable.smart_sanaa_launcher), "شعار سمارت صنعاء", Modifier.size(50.dp).clip(RoundedCornerShape(13.dp)))
                Column(Modifier.weight(1f)) {
                    Text("سمارت صنعاء", fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                    Text(if (connected) "متصل بالراوتر" else "غير متصل", color = if (connected) Green else Red, fontSize = 12.sp)
                }
            }
        }
        items(drawerItems.size) { index ->
            val (destination, label, icon) = drawerItems[index]
            val accent = accents[index]
            val selected = page == destination || (destination == Screen.CARDS && page == Screen.USER_DETAILS)
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp))
                .background(if (selected) accent.copy(alpha = .16f) else MaterialTheme.colorScheme.surface)
                .border(1.dp, accent.copy(alpha = if (selected) .64f else .27f), RoundedCornerShape(15.dp))
                .clickable { navigate(destination) }.padding(horizontal = 13.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                Box(Modifier.size(37.dp).clip(RoundedCornerShape(11.dp)).background(accent.copy(alpha = .12f)), contentAlignment = Alignment.Center) {
                    Icon(icon, label, tint = accent)
                }
                Text(label, fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Icon(Icons.Default.ChevronLeft, null, tint = accent, modifier = Modifier.size(18.dp))
            }
        }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(Color(0xFFF1F7FF), Color(0xFFFFF4F5))))
                .border(1.dp, Color(0xFFD6B2C0), RoundedCornerShape(20.dp)).padding(15.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Icon(Icons.Default.AdminPanelSettings, null, tint = Red)
                    Text("برمجة وتطوير", fontWeight = FontWeight.SemiBold, color = Color(0xFF14345A))
                }
                Text(adminName, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFB61B2C))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Icon(Icons.Default.Phone, null, tint = Blue, modifier = Modifier.size(19.dp))
                    Text(adminPhone, color = Color(0xFF14345A), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { openContact(AdminContactLinks.whatsApp(adminPhone)) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF148C62)),
                        contentPadding = PaddingValues(horizontal = 4.dp)) {
                        Icon(Icons.Default.Chat, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(5.dp)); Text("واتساب", fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = { openContact(AdminContactLinks.telegram(telegram)) },
                        enabled = AdminContactLinks.telegram(telegram) != null,
                        modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) {
                        Icon(Icons.Default.Send, null, tint = Cyan, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(5.dp)); Text("تلجرام", fontSize = 12.sp)
                    }
                }
                TextButton(onClick = { navigate(Screen.SETTINGS) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Settings, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp)); Text("إعدادات الاتصال")
                }
                Button(onClick = logout, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                    Icon(Icons.Default.Logout, null); Spacer(Modifier.width(7.dp)); Text("تسجيل الخروج")
                }
            }
        }
    }
}

@Composable
private fun BottomNav(active: Screen, navigate: (Screen) -> Unit) {
    val selected = when (active) {
        Screen.CREATE_CARD -> Screen.CREATE_CARD
        Screen.CARDS, Screen.USER_DETAILS, Screen.EXPIRED, Screen.MAINTENANCE -> Screen.CARDS
        Screen.REPORTS -> Screen.REPORTS
        else -> active
    }
    val options = listOf(
        Triple(Screen.HOME, "الرئيسية", Icons.Default.Home),
        Triple(Screen.CREATE_CARD, "إضافة كروت", Icons.Default.AddCard),
        Triple(Screen.CARDS, "عمليات الكروت", Icons.Default.CreditCard),
        Triple(Screen.REPORTS, "التقارير", Icons.Default.BarChart)
    )
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 1.dp) {
        options.forEach { (screen, label, icon) ->
            NavigationBarItem(
                selected = selected == screen,
                onClick = { navigate(screen) },
                icon = { Icon(icon, label) },
                label = { Text(label, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Cyan,
                    selectedTextColor = Cyan,
                    unselectedIconColor = Muted,
                    unselectedTextColor = Muted,
                    indicatorColor = Cyan.copy(alpha = .12f)
                )
            )
        }
    }
}
