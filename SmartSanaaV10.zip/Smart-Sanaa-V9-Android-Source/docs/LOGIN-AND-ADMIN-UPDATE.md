# Smart Sanaa V9 — Native login and admin-card update

- Rebuilt login in Jetpack Compose with blue/white/red gradient, actual original app launcher icon, IP, username, password and independently configurable RouterOS API port + TLS; password visibility control and explicit network security notice.
- Added wired Remember Me preference; credentials are saved to existing Android Keystore-backed SecureConfig only when enabled. Disabling also clears previously saved credentials, without interrupting a current session.
- Preserved RouterOS native API authentication and existing screens, card workflows, printing, navigation and build settings.
- Kept exactly the existing four side-navigation cards and their navigation destinations.
- Redesigned fixed developer identity card: عبدالله عوض / 775070442, with WhatsApp and Telegram actions. Removed edit UI and associated stored name/phone overrides. Telegram remains enabled only when a valid handle was previously configured; no fake handle invented.
- No publishing, live router writes or release-signing performed by this change.

## Verification

- Structural/behavior source checks performed locally; Android Gradle Plugin and SDK unavailable here, so no local Android assembleDebug or runtime testing claim.
- Build via existing GitHub Actions pipeline on the work branch, then install APK on test Android device and verify RouterOS v6/v7 connectivity and mobile layout.
