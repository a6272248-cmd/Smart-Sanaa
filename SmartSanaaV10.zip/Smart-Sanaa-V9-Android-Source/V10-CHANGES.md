# Smart Sanaa V10 — voucher screen refinement

- Simplified native one-page voucher workflow: configuration, exact A4 preview, explicit RouterOS confirmation, final print/save/share.
- Removed duplicative stage navigation and unused form fields (duration, price, notes, prefix, manual serial start, customer/group/shared-users) from the visible create-card screen. Router profile remains responsible for the configured usage period; Hotspot creation no longer overrides it with a hardcoded `1d`.
- Input type is a single selector: numeric, or letters and numbers.
- Serial numbering has a checkbox and persisted automatic next-number allocation, with the existing local reservation before remote creation.
- A4 physical dimensions remain configurable but are collapsed by default. The default is 4 x 20 on A4 with 52.2 x 14.47 mm vouchers.
- The confirmed batch uses existing native Android PDF print, document save and share actions.
- Original native RouterOS connection, authentication, offline safety, navigation, home, reports and operations sources retained.

## Verification
- ZIP structural integrity, CRC, safe paths, required Gradle files and source text inspected.
- **Android SDK/Gradle and live RouterOS devices are unavailable in this environment. No APK compilation, Compose type-check, Android lint, physical printing, or real-router write test was performed.** GitHub Actions must run tests/lint/build before treating this as a working release.
- Upload one `SmartSanaaV10.zip` file to `feature/smart-manager-enterprise-v4`. The existing bootstrap-android.yml automatically discovers archives named SmartSanaa*.zip; do not rename the workflow.
- Before production use, check profile time limits, native PDF alignment, serial continuity, installation signature, and authentication on RouterOS 6/7.
