package com.smartsanaa.manager

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SSLSocketFactory

/** RouterOS API binary wire protocol; works with modern v6/v7 API login. */
data class RouterConfig(val host: String = "10.11.0.5", val port: Int = 8728, val username: String = "admin", val password: String = "", val tls: Boolean = false)
data class ApiResponse(val records: List<Map<String, String>>) {
    val data: List<Map<String, String>> get() = records.filter { it["!type"] == "!re" }
}
class RouterOsException(message: String): Exception(message)
class RouterOsApi(private val config: RouterConfig) {
    private fun OutputStream.writeLength(length: Int) {
        when {
            length < 0x80 -> write(length)
            length < 0x4000 -> { write((length shr 8) or 0x80); write(length and 255) }
            length < 0x200000 -> { write((length shr 16) or 0xC0); write((length shr 8) and 255); write(length and 255) }
            length < 0x10000000 -> { write((length shr 24) or 0xE0); write((length shr 16) and 255); write((length shr 8) and 255); write(length and 255) }
            else -> { write(0xF0); for (shift in intArrayOf(24,16,8,0)) write((length shr shift) and 255) }
        }
    }
    private fun InputStream.readByteRequired(): Int = read().also { if (it < 0) throw EOFException("Router disconnected") }
    private fun InputStream.readLength(): Int {
        val a = readByteRequired()
        return when {
            (a and 0x80) == 0 -> a
            (a and 0xC0) == 0x80 -> ((a and 0x3F) shl 8) or readByteRequired()
            (a and 0xE0) == 0xC0 -> ((a and 0x1F) shl 16) or (readByteRequired() shl 8) or readByteRequired()
            (a and 0xF0) == 0xE0 -> ((a and 0x0F) shl 24) or (readByteRequired() shl 16) or (readByteRequired() shl 8) or readByteRequired()
            a == 0xF0 -> (readByteRequired() shl 24) or (readByteRequired() shl 16) or (readByteRequired() shl 8) or readByteRequired()
            else -> throw RouterOsException("Invalid API length")
        }
    }
    private fun OutputStream.send(words: List<String>) {
        words.forEach { word -> val bytes = word.toByteArray(Charsets.UTF_8); writeLength(bytes.size); write(bytes) }
        write(0); flush()
    }
    private fun InputStream.receive(): List<String> {
        val out = mutableListOf<String>()
        while (true) {
            val size = readLength()
            if (size == 0) return out
            if (size > 8_000_000 || size < 0) throw RouterOsException("Unexpected response size")
            val bytes = ByteArray(size); var read = 0
            while (read < size) { val count = read(bytes, read, size - read); if (count < 0) throw EOFException("Incomplete API response"); read += count }
            out += String(bytes, Charsets.UTF_8)
        }
    }
    private fun parse(sentence: List<String>): Map<String,String> {
        val result = mutableMapOf<String,String>(); result["!type"] = sentence.firstOrNull() ?: ""
        sentence.drop(1).forEach { val value = it.removePrefix("="); val i = value.indexOf('='); if(i > 0) result[value.substring(0,i)] = value.substring(i+1) }
        return result
    }
    suspend fun execute(path: String, params: Map<String,String> = emptyMap()): ApiResponse = withContext(Dispatchers.IO) {
        require(path.startsWith("/") && !path.contains(' ')) { "Invalid API path" }
        require(config.port in 1..65535)
        val plain = Socket()
        try {
            plain.connect(InetSocketAddress(config.host, config.port), 6000)
            plain.soTimeout = 10000
            val socket = if(config.tls) {
                val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(plain, config.host, config.port, true)
                ssl.soTimeout = 10000
                ssl.sslParameters = ssl.sslParameters.apply { endpointIdentificationAlgorithm = "HTTPS" }
                ssl.startHandshake() // Default trust verification; self-signed routers require trusted CA.
                ssl
            } else plain
            socket.use {
                val input = it.getInputStream(); val output = it.getOutputStream()
                output.send(listOf("/login", "=name=${config.username}", "=password=${config.password}"))
                val login = input.receive()
                val first = login.firstOrNull() ?: ""
                if(first == "!trap") throw RouterOsException("Login refused: ${parse(login)["message"] ?: "check credentials"}")
                if(first != "!done") throw RouterOsException("RouterOS legacy challenge login unsupported; update RouterOS")
                val words = mutableListOf(path)
                params.forEach { (key,value) -> words += "=$key=$value" }
                output.send(words)
                val rows = mutableListOf<Map<String,String>>()
                while(true) {
                    val sentence = input.receive(); val kind = sentence.firstOrNull() ?: ""
                    val row = parse(sentence)
                    if(kind == "!trap" || kind == "!fatal") throw RouterOsException(row["message"] ?: "RouterOS command failed")
                    if(kind == "!done") break
                    if(kind == "!re") rows += row
                }
                ApiResponse(rows)
            }
        } finally { if(!plain.isClosed) plain.close() }
    }
}

/** These map commands to the different RouterOS 6/7 paths. */
object RouterCommands {
    fun list(screen: Screen, version7: Boolean): String? = when(screen) {
        Screen.USERS -> if(version7) "/user-manager/user/print" else "/tool/user-manager/user/print"
        Screen.CARDS -> if(version7) "/user-manager/user/print" else "/tool/user-manager/user/print"
        Screen.PACKAGES -> if(version7) "/user-manager/profile/print" else "/tool/user-manager/profile/print"
        Screen.HOTSPOT -> "/ip/hotspot/active/print"
        Screen.PPPOE -> "/ppp/active/print"
        Screen.DEVICE -> "/interface/print"
        Screen.NOTIFICATIONS -> "/log/print"
        else -> null
    }
}
