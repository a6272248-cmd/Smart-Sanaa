package com.smartsanaa.manager

import android.content.Context
import android.content.Intent
import android.content.Context.PRINT_SERVICE
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.print.PageRange
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.ceil
import kotlin.math.roundToInt

/** A4 print settings aligned with the original Smart Manager card editor. */
data class PrintTemplate(
    val columns: Int = 4,
    val rows: Int = 20,
    val cardWidthMm: Float = 52.2f,
    val cardHeightMm: Float = 14.47f,
    val marginMm: Float = 0f,
    val gapMm: Float = 0.4f,
    val showSerial: Boolean = false,
    val serialStart: Int = 1,
    val showPrice: Boolean = true,
    val usernameX: Float = 50f,
    val usernameY: Float = 58f,
    val usernameWidth: Float = 90f,
    val usernameSize: Float = 9f,
    val backgroundPath: String? = null
)

@Composable
fun VoucherCreator(
    repo: RouterRepository?,
    connected: Boolean,
    initialService: String,
    onFinish: () -> Unit,
    onCreated: (String, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val templatePrefs = remember(context) { context.getSharedPreferences("voucher_print", Context.MODE_PRIVATE) }
    var service by remember { mutableStateOf(if (initialService == "User Manager" && repo?.um?.path != null) "User Manager" else "Hotspot") }
    var profiles by remember { mutableStateOf<List<String>>(emptyList()) }
    var servers by remember { mutableStateOf<List<String>>(emptyList()) }
    var profile by remember { mutableStateOf("") }
    var server by remember { mutableStateOf("all") }
    var quantity by remember { mutableStateOf("10") }
    var usernameLength by remember { mutableStateOf("8") }
    var prefix by remember { mutableStateOf("") }
    var usernameType by remember { mutableStateOf("numbers") }
    var duration by remember { mutableStateOf("1d") }
    var customer by remember { mutableStateOf("admin") }
    var group by remember { mutableStateOf("default") }
    var sharedUsers by remember { mutableStateOf("1") }
    var price by remember { mutableStateOf("0") }
    var notes by remember { mutableStateOf("") }
    var loadingProfiles by remember { mutableStateOf(false) }
    var loadingServers by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("") }
    var planned by remember { mutableStateOf<List<String>>(emptyList()) }
    var created by remember { mutableStateOf<List<String>>(emptyList()) }
    var profileMenu by remember { mutableStateOf(false) }
    var serverMenu by remember { mutableStateOf(false) }

    var templatePath by remember { mutableStateOf(templatePrefs.getString("background", "").orEmpty()) }
    var templateBitmap by remember(templatePath) { mutableStateOf(templatePath.takeIf { it.isNotBlank() }?.let(::decodeVoucherTemplate)) }
    var columns by remember { mutableStateOf(templatePrefs.getString("columns", "4") ?: "4") }
    var rowsPerPage by remember { mutableStateOf(templatePrefs.getString("rows", "20") ?: "20") }
    var cardWidth by remember { mutableStateOf(templatePrefs.getString("card_width", "52.2") ?: "52.2") }
    var cardHeight by remember { mutableStateOf(templatePrefs.getString("card_height", "14.47") ?: "14.47") }
    var margin by remember { mutableStateOf(templatePrefs.getString("margin", "0") ?: "0") }
    var gap by remember { mutableStateOf(templatePrefs.getString("gap", "0.4") ?: "0.4") }
    var showSerial by remember { mutableStateOf(templatePrefs.getBoolean("serial_enabled", true)) }
    var serialStart by remember {
        val saved = templatePrefs.getString("serial_start", "1")?.toIntOrNull() ?: 1
        mutableStateOf(maxOf(saved, templatePrefs.getInt("next_serial", 1)).toString())
    }
    // Freeze the serial range used by the confirmed batch, even if next-batch settings change.
    var confirmedBatchSerialStart by remember { mutableIntStateOf(0) }
    var showPrice by remember { mutableStateOf(templatePrefs.getBoolean("show_price", true)) }
    var usernameX by remember { mutableFloatStateOf(templatePrefs.getFloat("username_x", 50f)) }
    var usernameY by remember { mutableFloatStateOf(templatePrefs.getFloat("username_y", 58f)) }
    var usernameWidth by remember { mutableFloatStateOf(templatePrefs.getFloat("username_width", 90f)) }
    var usernameSize by remember { mutableFloatStateOf(templatePrefs.getFloat("username_size", 9f)) }
    var currentPreviewPage by remember { mutableIntStateOf(1) }
    var pendingPdfFile by remember { mutableStateOf<File?>(null) }
    LaunchedEffect(columns, rowsPerPage, cardWidth, cardHeight, margin, gap,
        showSerial, serialStart, showPrice, usernameX, usernameY, usernameWidth, usernameSize) {
        templatePrefs.edit()
            .putString("columns", columns).putString("rows", rowsPerPage)
            .putString("card_width", cardWidth).putString("card_height", cardHeight)
            .putString("margin", margin).putString("gap", gap)
            .putBoolean("serial_enabled", showSerial).putString("serial_start", serialStart)
            .putBoolean("show_price", showPrice)
            .putFloat("username_x", usernameX).putFloat("username_y", usernameY)
            .putFloat("username_width", usernameWidth).putFloat("username_size", usernameSize)
            .apply()
    }

    val savePdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val source = pendingPdfFile
        if (uri != null && source != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    source.inputStream().use { it.copyTo(output) }
                } ?: error("تعذّر فتح ملف الحفظ")
            }.onSuccess { status = "تم حفظ PDF في الموقع الذي اخترته" }
                .onFailure { status = "فشل حفظ PDF: ${it.message}" }
        }
        pendingPdfFile = null
    }

    val templatePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val target = File(context.filesDir, "voucher-template-${System.currentTimeMillis()}.img")
                context.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
                    ?: error("تعذر قراءة صورة القالب")
                val decoded = decodeVoucherTemplate(target.absolutePath)
                if (decoded == null) {
                    target.delete()
                    error("ملف الصورة غير صالح؛ اختر PNG أو JPEG أو WebP")
                }
                val previous = templatePath
                templatePath = target.absolutePath
                templateBitmap = decoded
                templatePrefs.edit().putString("background", target.absolutePath).apply()
                if (previous.isNotBlank() && previous != target.absolutePath) {
                    // Only delete the app's own previously copied image.
                    val oldFile = File(previous)
                    if (oldFile.parentFile == context.filesDir && oldFile.name.startsWith("voucher-template-")) oldFile.delete()
                }
                status = "تم حفظ قالب الطباعة على الهاتف"
            }.onFailure { status = "تعذر تحميل القالب: ${it.message}" }
        }
    }

    LaunchedEffect(repo, connected, service, customer) {
        delay(350)
        profiles = emptyList()
        servers = emptyList()
        profile = ""
        val r = repo ?: return@LaunchedEffect
        if (!connected) return@LaunchedEffect
        val root = r.profileRoot(service) ?: return@LaunchedEffect
        loadingProfiles = true
        runCatching {
            val path = "$root/print"
            val params = if (service == "User Manager" && root.startsWith("/tool/")) {
                mapOf(".proplist" to "name", "customer" to customer.ifBlank { "admin" })
            } else mapOf(".proplist" to "name")
            r.api.execute(path, r.requestParams(path, params)).data.mapNotNull { it["name"] }.distinct().sorted()
        }.onSuccess { list -> profiles = list; if (profile !in list) profile = list.firstOrNull().orEmpty() }
            .onFailure { status = "تعذر تحميل الباقات: ${it.message}" }
        loadingProfiles = false
        if (service == "Hotspot") {
            loadingServers = true
            runCatching { r.api.execute("/ip/hotspot/print", mapOf(".proplist" to "name")).data.mapNotNull { it["name"] }.distinct().sorted() }
                .onSuccess { servers = listOf("all") + it; if (server !in servers) server = "all" }
                .onFailure { status = "تعذر تحميل خوادم Hotspot: ${it.message}" }
            loadingServers = false
        }
    }

    val previewCount = if (created.isNotEmpty()) created.size else planned.size
    val totalPages = if (previewCount == 0) 0 else {
        val perPage = (columns.toIntOrNull() ?: 4).coerceAtLeast(1) * (rowsPerPage.toIntOrNull() ?: 20).coerceAtLeast(1)
        ceil(previewCount.toDouble() / perPage).toInt()
    }
    LaunchedEffect(totalPages) {
        if (totalPages > 0) {
            currentPreviewPage = currentPreviewPage.coerceIn(1, totalPages)
        } else currentPreviewPage = 1
    }

    fun validatedPrintLayout(): Pair<PrintTemplate, IntRange> {
        val firstSerial = if (created.isNotEmpty() && confirmedBatchSerialStart > 0) confirmedBatchSerialStart
            else serialStart.toIntOrNull() ?: 0
        if (showSerial) SerialRangePolicy.nextStart(firstSerial, previewCount.coerceAtLeast(1))
        val layout = PrintTemplate(
            columns = columns.toInt(), rows = rowsPerPage.toInt(),
            cardWidthMm = cardWidth.toFloat(), cardHeightMm = cardHeight.toFloat(),
            marginMm = margin.toFloat(), gapMm = gap.toFloat(),
            showSerial = showSerial, serialStart = firstSerial.coerceAtLeast(1),
            showPrice = showPrice, usernameX = usernameX, usernameY = usernameY,
            usernameWidth = usernameWidth, usernameSize = usernameSize,
            backgroundPath = templatePath.takeIf { it.isNotBlank() }
        )
        PrintLayout.page(layout.columns, layout.rows, layout.cardWidthMm, layout.cardHeightMm, layout.marginMm, layout.gapMm)
        require(totalPages > 0) { "لم يتم إنشاء كروت للطباعة" }
        return layout to (1..totalPages)
    }

    fun prepareConfirmedPdf(): File {
        require(created.isNotEmpty()) { "يجب تأكيد إنشاء الكروت على الراوتر أولًا" }
        val (layout, range) = validatedPrintLayout()
        return exportVoucherPdf(context.cacheDir, created, price, notes, layout, range.first, range.last)
    }

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 14.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { PageHeading("إضافة وطباعة الكروت", "إعداد الكروت والقالب ومعاينة A4 والطباعة في شاشة واحدة") }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                VoucherStage("١  الإعداد", planned.isEmpty() && created.isEmpty(), Modifier.weight(1f))
                VoucherStage("٢  المعاينة", planned.isNotEmpty(), Modifier.weight(1f))
                VoucherStage("٣  الطباعة", created.isNotEmpty(), Modifier.weight(1f))
            }
        }

        if (planned.isEmpty() && created.isEmpty()) {
            item {
                PanelCard {
                    VoucherSectionHeading("النظام والسيرفر والباقة", "تُحمّل الباقات والخوادم من الراوتر المتصل")
                    Text("نوع الكروت", fontWeight = FontWeight.Medium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Hotspot", "User Manager").forEach { item ->
                            FilterChip(
                                selected = service == item,
                                onClick = { service = item; status = ""; created = emptyList() },
                                enabled = item != "User Manager" || repo?.um?.path != null,
                                label = { Text(item) }
                            )
                        }
                    }
                    Text("الباقة", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    Box {
                        OutlinedButton(onClick = { profileMenu = true }, modifier = Modifier.fillMaxWidth(), enabled = profiles.isNotEmpty()) {
                            Text(profile.ifBlank { if (loadingProfiles) "جار تحميل الباقات…" else "اختر الباقة" }, modifier = Modifier.weight(1f), textAlign = TextAlign.Start)
                        }
                        DropdownMenu(expanded = profileMenu, onDismissRequest = { profileMenu = false }) {
                            profiles.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { profile = item; profileMenu = false }) }
                        }
                    }
                    if (loadingProfiles) LinearProgressIndicator(Modifier.fillMaxWidth())
                    if (service == "Hotspot") {
                        Text("خادم Hotspot", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        Box {
                            OutlinedButton(onClick = { serverMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (server == "all") "كل الخوادم" else server, modifier = Modifier.weight(1f), textAlign = TextAlign.Start)
                            }
                            DropdownMenu(expanded = serverMenu, onDismissRequest = { serverMenu = false }) {
                                (listOf("all") + servers.filter { it != "all" }).distinct().forEach { item ->
                                    DropdownMenuItem(text = { Text(if (item == "all") "كل الخوادم" else item) }, onClick = { server = item; serverMenu = false })
                                }
                            }
                        }
                        if (loadingServers) LinearProgressIndicator(Modifier.fillMaxWidth())
                        VoucherField("حد الاستخدام مثال 1d أو 2h30m", duration) { duration = it }
                    }
                    if (service == "User Manager" && repo?.um?.path?.startsWith("/tool/") == true) {
                        VoucherField("Customer / المالك", customer) { customer = it }
                        VoucherField("عدد المستخدمين المتزامنين", sharedUsers) { sharedUsers = it }
                    } else if (service == "User Manager") {
                        VoucherField("Group", group) { group = it }
                        VoucherField("عدد المستخدمين المتزامنين", sharedUsers) { sharedUsers = it }
                    }
                }
            }
            item {
                PanelCard {
                    VoucherSectionHeading("توليد الكروت", "العدد والطول ونوع الرقم والتسلسل والقيمة")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VoucherField("الكمية (1–100)", quantity, Modifier.weight(1f)) { quantity = it.filter(Char::isDigit).take(3) }
                        VoucherField("طول الكود", usernameLength, Modifier.weight(1f)) { usernameLength = it.filter(Char::isDigit).take(2) }
                    }
                    VoucherField("بادئة اسم المستخدم (اختياري)", prefix) { prefix = it.trim().take(12) }
                    Text("نوع الأرقام", fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodySmall)
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("numbers" to "أرقام فقط", "lowercase" to "أحرف صغيرة", "uppercase" to "أحرف كبيرة", "mixed" to "مختلط").forEach { (value, label) ->
                            FilterChip(selected = usernameType == value, onClick = { usernameType = value }, label = { Text(label, fontSize = 12.sp) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VoucherField("السعر", price, Modifier.weight(1f)) { price = it.take(12) }
                        VoucherField("ملاحظات", notes, Modifier.weight(1f)) { notes = it.take(60) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("ترقيم تسلسلي للكروت", Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        Switch(checked = showSerial, onCheckedChange = { showSerial = it })
                    }
                    if (showSerial) VoucherField("بداية الرقم التسلسلي", serialStart) {
                        serialStart = it.filter(Char::isDigit).take(8)
                    }
                    Text("لن تُنشأ الكروت إلا بعد المعاينة والتأكيد. كلمة المرور فارغة بحسب إعداد لوحة Smart Manager.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    Button(
                        onClick = {
                            val r = repo
                            val count = quantity.toIntOrNull()
                            val length = usernameLength.toIntOrNull()
                            if (r == null || !connected) { status = "اتصل بالراوتر أولًا"; return@Button }
                            if (count == null || count !in 1..100) { status = "الكمية يجب أن تكون من 1 إلى 100"; return@Button }
                            if (length == null || length !in 3..18) { status = "طول الكود يجب أن يكون من 3 إلى 18"; return@Button }
                            if (profile.isBlank() || profile !in profiles) { status = "اختر باقة موجودة على الراوتر"; return@Button }
                            if (service == "Hotspot" && duration.isNotBlank() && ExpiryPolicy.durationSeconds(duration)?.let { it > 0L } != true) { status = "اكتب حد استخدام صحيحًا مثل 1d أو 2h30m"; return@Button }
                            if (service == "User Manager" && sharedUsers.toIntOrNull()?.let { it > 0 } != true) { status = "عدد المستخدمين المتزامنين يجب أن يكون رقمًا موجبًا"; return@Button }
                            if (service == "User Manager" && r.um.path == null) { status = r.um.status; return@Button }
                            busy = true
                            created = emptyList()
                            status = "جار فحص الأسماء وتكوين المعاينة…"
                            scope.launch {
                                runCatching {
                                    val existing = r.existingUsernames(service, customer.ifBlank { "admin" })
                                    VoucherCodePolicy.generate(count, length, prefix.trim(), usernameType, existing)
                                }.onSuccess {
                                    planned = it
                                    status = "المعاينة جاهزة: ${it.size} كرت. لم يتم إرسال أي أمر إنشاء إلى الراوتر بعد."
                                }.onFailure { status = "تعذر تجهيز المعاينة: ${it.message}" }
                                busy = false
                            }
                        },
                        enabled = connected && !busy && !loadingProfiles && profiles.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AddCard, null); Spacer(Modifier.width(8.dp)); Text(if (busy) "جار التجهيز…" else "معاينة الأرقام قبل الإضافة")
                    }
                }
            }
        } else if (planned.isNotEmpty()) {
            item {
                PanelCard {
                    VoucherSectionHeading("مراجعة الدفعة", "لن تُرسل أي بيانات قبل التأكيد")
                    Text("${planned.size} كرت · $service · الباقة $profile", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("هذه أسماء مقترحة محليًا. لن تُحفظ على الراوتر حتى تضغط تأكيد الإضافة.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    planned.take(12).forEachIndexed { index, code -> InfoLine("${index + 1}", code) }
                    if (planned.size > 12) Text("و ${planned.size - 12} كرتًا آخر…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { planned = emptyList(); status = "يمكنك تعديل الإعدادات ثم إعادة المعاينة." }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("تعديل الإعدادات") }
                        Button(onClick = {
                            val r = repo ?: return@Button
                            val batch = planned.toList()
                            val selectedService = service
                            val selectedProfile = profile
                            val selectedCustomer = customer.ifBlank { "admin" }
                            val selectedGroup = group.ifBlank { "default" }
                            val selectedShared = sharedUsers.ifBlank { "1" }
                            val selectedServer = server
                            val selectedDuration = duration
                            // Reserve the entire proposed serial range BEFORE issuing any router writes.
                            // Reserving also on partial failures prevents local reuse after an uncertain reply.
                            val reservedFirst = serialStart.toIntOrNull() ?: 0
                            if (showSerial) {
                                val next = runCatching { SerialRangePolicy.nextStart(reservedFirst, batch.size) }
                                    .getOrElse { status = "رقم التسلسل غير صالح: ${it.message}"; return@Button }
                                if (!templatePrefs.edit().putInt("next_serial", next).commit()) {
                                    status = "تعذر حفظ التسلسل على الهاتف، لم تُرسل الدفعة."; return@Button
                                }
                                confirmedBatchSerialStart = reservedFirst
                            } else confirmedBatchSerialStart = 0
                            val batchId = UUID.randomUUID().toString().take(10)
                            busy = true
                            progress = 0
                            status = "جار إنشاء الكروت على الراوتر…"
                            scope.launch {
                                val confirmed = mutableListOf<String>()
                                var stopMessage = ""
                                for (code in batch) {
                                    val values = buildMap {
                                        put("username", code)
                                        put("password", "")
                                        put("profile", selectedProfile)
                                        put("comment", "Smart-Sanaa batch $batchId")
                                        if (selectedService == "Hotspot") {
                                            if (selectedDuration.isNotBlank()) put("limit-uptime", selectedDuration)
                                            if (selectedServer.isNotBlank() && selectedServer != "all") put("server", selectedServer)
                                        } else {
                                            put("customer", selectedCustomer)
                                            put("group", selectedGroup)
                                            put("shared-users", selectedShared)
                                        }
                                    }
                                    try {
                                        r.createUser(selectedService, values, allowEmptyPassword = true)
                                        confirmed += code
                                        progress = confirmed.size
                                    } catch (e: PartialUserCreationException) {
                                        stopMessage = "تم إنشاء $code لكن لم يكتمل ربط الباقة؛ لم يُدرج في ملف الطباعة. ${e.message}"
                                        break
                                    } catch (e: Exception) {
                                        stopMessage = "توقفت الدفعة عند $code: ${e.message}. لا تعِد الإرسال قبل تحديث قائمة الكروت؛ قد يكون الراوتر نفذ الطلب الأخير."
                                        break
                                    }
                                }
                                created = confirmed
                                planned = emptyList()
                                val finalMessage = when {
                                    stopMessage.isNotBlank() -> "تم تأكيد ${confirmed.size} من ${batch.size}. $stopMessage"
                                    confirmed.size == batch.size -> "تم إنشاء ${confirmed.size} كرتًا بنجاح على $selectedService."
                                    else -> "تم تأكيد ${confirmed.size} من ${batch.size} كرتًا."
                                }
                                status = finalMessage
                                onCreated(selectedService, finalMessage)
                                busy = false
                            }
                        }, enabled = connected && !busy, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Save, null); Spacer(Modifier.width(6.dp)); Text(if (busy) "جار الإضافة $progress/${planned.size}" else "تأكيد وإضافة للراوتر")
                        }
                    }
                }
            }
        }

        item {
            PanelCard {
                VoucherSectionHeading("قالب الكرت وطباعة A4", "إعداد مطابق لترتيب سمارت منجر · 4 أعمدة × 20 صفًا افتراضيًا")
                VoucherCardPreview(
                    templateBitmap, created.firstOrNull() ?: planned.firstOrNull() ?: "123456789",
                    usernameX, usernameY,
                    onMove = { x, y -> usernameX = x; usernameY = y }
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { templatePicker.launch(arrayOf("image/jpeg", "image/png", "image/webp")) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.AttachFile, null)
                        Spacer(Modifier.width(5.dp))
                        Text(if (templatePath.isBlank()) "اختيار قالب الكرت" else "تغيير صورة القالب")
                    }
                    if (templatePath.isNotBlank()) OutlinedButton(onClick = {
                        val file = File(templatePath)
                        if (file.parentFile == context.filesDir && file.name.startsWith("voucher-template-")) file.delete()
                        templatePath = ""
                        templateBitmap = null
                        templatePrefs.edit().remove("background").apply()
                    }) { Text("إزالة") }
                }
                Text("مقاسات ورقة A4", fontWeight = FontWeight.SemiBold, color = Color(0xFF153A60))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VoucherField("الأعمدة", columns, Modifier.weight(1f)) { columns = it.filter(Char::isDigit).take(1) }
                    VoucherField("الصفوف", rowsPerPage, Modifier.weight(1f)) { rowsPerPage = it.filter(Char::isDigit).take(2) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VoucherField("عرض الكرت مم", cardWidth, Modifier.weight(1f)) { cardWidth = it.filter { ch -> ch.isDigit() || ch == '.' }.take(6) }
                    VoucherField("ارتفاع الكرت مم", cardHeight, Modifier.weight(1f)) { cardHeight = it.filter { ch -> ch.isDigit() || ch == '.' }.take(6) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VoucherField("الهامش مم", margin, Modifier.weight(1f)) { margin = it.filter { ch -> ch.isDigit() || ch == '.' }.take(6) }
                    VoucherField("الفاصل مم", gap, Modifier.weight(1f)) { gap = it.filter { ch -> ch.isDigit() || ch == '.' }.take(6) }
                }
                if (created.isNotEmpty()) {
                    Text("${created.size} كرت مؤكد · $totalPages صفحة A4", fontWeight = FontWeight.Medium)
                    Button(onClick = {
                        runCatching {
                            val file = prepareConfirmedPdf()
                            val manager = context.getSystemService(PRINT_SERVICE) as PrintManager
                            manager.print("Smart Sanaa - Vouchers", VoucherPdfPrintAdapter(file),
                                PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build())
                        }.onFailure { status = "تعذّر فتح الطباعة: ${it.message}" }
                    }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                        Icon(Icons.Default.PictureAsPdf, null)
                        Spacer(Modifier.width(8.dp))
                        Text("طباعة الكروت المؤكدة")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            runCatching { prepareConfirmedPdf() }
                                .onSuccess { pendingPdfFile = it; savePdfPicker.launch(it.name) }
                                .onFailure { status = "تعذّر حفظ PDF: ${it.message}" }
                        }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("حفظ PDF") }
                        OutlinedButton(onClick = {
                            runCatching {
                                val file = prepareConfirmedPdf()
                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/pdf"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "مشاركة كروت Smart Sanaa"))
                            }.onFailure { status = "تعذّر مشاركة PDF: ${it.message}" }
                        }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("مشاركة PDF") }
                    }
                    Button(onClick = onFinish, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF13977E))) {
                        Text("إنهاء والعودة للرئيسية")
                    }
                } else {
                    Text("المعاينة قبل الإضافة متاحة بالأسفل. الطباعة وحفظ PDF بعد تأكيد الإنشاء على الراوتر.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        // Render the same real A4 PDF page that will be printed, even before creation.
        // Planned codes are preview-only: PDF save/print remains disabled until RouterOS confirms them.
        if (planned.isNotEmpty() || created.isNotEmpty()) {
            item {
                PanelCard {
                    val cardsToShow = if (created.isNotEmpty()) created else planned
                    val pageTotal = totalPages.coerceAtLeast(1)
                    val serialFrom = if (created.isNotEmpty() && confirmedBatchSerialStart > 0)
                        confirmedBatchSerialStart else serialStart.toIntOrNull()
                    val serialTo = serialFrom?.toLong()?.plus(cardsToShow.size - 1)
                    VoucherSectionHeading(
                        if (created.isNotEmpty()) "معاينة الكروت المؤكدة" else "معاينة صفحة A4 قبل الإضافة",
                        "${cardsToShow.size} كرت · $columns أعمدة × $rowsPerPage صفوف · $pageTotal صفحة"
                    )
                    if (showSerial && serialFrom != null && serialTo != null) {
                        Text("التسلسل: $serialFrom–$serialTo", color = Color(0xFF168278), fontWeight = FontWeight.SemiBold)
                    }
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        OutlinedButton(onClick = { currentPreviewPage = (currentPreviewPage - 1).coerceAtLeast(1) },
                            enabled = currentPreviewPage > 1) { Text("السابق") }
                        Text("صفحة $currentPreviewPage من $pageTotal", fontWeight = FontWeight.Medium)
                        OutlinedButton(onClick = { currentPreviewPage = (currentPreviewPage + 1).coerceAtMost(pageTotal) },
                            enabled = currentPreviewPage < pageTotal) { Text("التالي") }
                    }
                    val layout = runCatching { validatedPrintLayout().first }.getOrNull()
                    if (layout == null) {
                        Text("تحقق من إعدادات مقاسات A4 ونطاق الصفحات في تخصيص الطباعة.",
                            color = MaterialTheme.colorScheme.error)
                    } else {
                        VoucherA4PagePreview(
                            context = context, codes = cardsToShow, pageNumber = currentPreviewPage,
                            price = price, notes = notes, template = layout
                        )
                    }
                    if (created.isEmpty()) {
                        Text("معاينة فقط — لن يُنشأ أي كرت أو يُتاح تصديره قبل تأكيد الإضافة على الراوتر.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        if (created.isNotEmpty()) {
            item {
                PanelCard {
                    Text("الكروت المؤكدة على الراوتر", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("${created.size} كرت · ملف PDF سيحتوي على الكروت التي تأكد إنشاؤها فقط.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    created.take(8).forEachIndexed { index, code -> InfoLine("${index + 1}", code) }
                    if (created.size > 8) Text("و ${created.size - 8} كرتًا آخر…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedButton(
                        onClick = {
                            created = emptyList()
                            confirmedBatchSerialStart = 0
                            serialStart = maxOf(templatePrefs.getInt("next_serial", 1), serialStart.toIntOrNull() ?: 1).toString()
                            status = "الدفعة السابقة محفوظة على الراوتر. يمكنك إعداد دفعة جديدة."
                        },
                        enabled = !busy, modifier = Modifier.fillMaxWidth()
                    ) { Text("إعداد دفعة جديدة") }
                }
            }
        }
        if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (status.isNotBlank()) item { Text(status, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun VoucherField(label: String, value: String, modifier: Modifier = Modifier.fillMaxWidth(), update: (String) -> Unit) {
    val numeric = listOf("الكمية", "طول الكود", "عدد المستخدمين", "السعر", "الأعمدة", "الصفوف", "عرض الكرت", "ارتفاع الكرت", "الهامش", "الفاصل", "بداية الرقم", "من صفحة", "إلى صفحة").any(label::contains)
    OutlinedTextField(
        value, update, label = { Text(label) }, modifier = modifier.fillMaxWidth(), singleLine = true,
        shape = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text)
    )
}

@Composable
private fun VoucherStage(text: String, active: Boolean, modifier: Modifier) {
    val accent = MaterialTheme.colorScheme.primary
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = if (active) accent.copy(alpha = .10f) else MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, if (active) accent.copy(alpha = .48f) else MaterialTheme.colorScheme.outlineVariant)
    ) {
        Text(
            text, modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
            color = if (active) accent else MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.Center, maxLines = 1
        )
    }
}

@Composable
private fun VoucherSectionHeading(title: String, subtitle: String) {
    Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
    Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
}

@Composable
private fun VoucherCardPreview(
    background: Bitmap?, sample: String,
    usernameX: Float, usernameY: Float,
    onMove: (Float, Float) -> Unit
) {
    var previewSize by remember { mutableStateOf(IntSize.Zero) }
    val currentX by rememberUpdatedState(usernameX)
    val currentY by rememberUpdatedState(usernameY)
    val moveCallback by rememberUpdatedState(onMove)
    BoxWithConstraints(
        modifier = Modifier.fillMaxWidth().height(110.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
            .onSizeChanged { previewSize = it }
            .pointerInput(previewSize) {
                detectDragGestures { change, drag ->
                    change.consume()
                    if (previewSize.width > 0 && previewSize.height > 0) {
                        moveCallback(
                            (currentX + drag.x / previewSize.width * 100f).coerceIn(10f, 90f),
                            (currentY + drag.y / previewSize.height * 100f).coerceIn(15f, 90f)
                        )
                    }
                }
            }
    ) {
        if (background != null) {
            Image(background.asImageBitmap(), "قالب الطباعة", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        } else {
            Text("SMART SANAA", color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.TopStart).padding(10.dp))
        }
        // Coordinates are the same percentages used by exportVoucherPdf.
        Text(sample, color = Color(0xFF112B4A), fontWeight = FontWeight.Black, fontSize = 14.sp,
            maxLines = 1,
            modifier = Modifier.offset(
                x = maxWidth * (usernameX / 100f) - 48.dp,
                y = maxHeight * (usernameY / 100f) - 13.dp
            ).width(96.dp).background(Color.White.copy(alpha = .80f), RoundedCornerShape(7.dp))
                .padding(horizontal = 3.dp, vertical = 5.dp), textAlign = TextAlign.Center)
    }
    Text("اسحب الرقم لتعديل موضعه على القالب. ستظهر النتيجة في معاينة A4.",
        color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
}

/** Renders one actual A4 PDF page into a read-only preview. The temporary PDF is deleted. */
@Composable
private fun VoucherA4PagePreview(
    context: Context,
    codes: List<String>,
    pageNumber: Int,
    price: String,
    notes: String,
    template: PrintTemplate
) {
    val preview = remember(codes, pageNumber, price, notes, template) {
        runCatching {
            val pdf = exportVoucherPdf(context.cacheDir, codes, price, notes, template, pageNumber, pageNumber)
            try {
                ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                    PdfRenderer(fd).use { renderer ->
                        renderer.openPage(0).use { page ->
                            val width = 840
                            val height = (width.toFloat() * PrintLayout.A4_HEIGHT_MM / PrintLayout.A4_WIDTH_MM).roundToInt()
                            Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { bitmap ->
                                bitmap.eraseColor(android.graphics.Color.WHITE)
                                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            }
                        }
                    }
                }
            } finally { pdf.delete() }
        }
    }
    preview.onSuccess { page ->
        Image(
            bitmap = page.asImageBitmap(), contentDescription = "صفحة A4 رقم $pageNumber",
            modifier = Modifier.fillMaxWidth().aspectRatio(PrintLayout.A4_WIDTH_MM / PrintLayout.A4_HEIGHT_MM)
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(3.dp)),
            contentScale = ContentScale.FillBounds
        )
    }.onFailure {
        Text("تعذرت معاينة الورقة: ${it.message}", color = MaterialTheme.colorScheme.error)
    }
}

/** Android's native print system receives only PDFs created from confirmed MikroTik cards. */
private class VoucherPdfPrintAdapter(private val pdf: File) : PrintDocumentAdapter() {
    override fun onLayout(
        oldAttributes: PrintAttributes?, newAttributes: PrintAttributes?, cancellationSignal: CancellationSignal,
        callback: LayoutResultCallback, extras: Bundle?
    ) {
        if (cancellationSignal.isCanceled) { callback.onLayoutCancelled(); return }
        if (!pdf.isFile || pdf.length() == 0L) { callback.onLayoutFailed("ملف الطباعة غير متوفر"); return }
        callback.onLayoutFinished(
            PrintDocumentInfo.Builder(pdf.name).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN).build(),
            true
        )
    }

    override fun onWrite(
        pages: Array<out PageRange>, destination: ParcelFileDescriptor, cancellationSignal: CancellationSignal,
        callback: WriteResultCallback
    ) {
        Thread {
            runCatching {
                FileInputStream(pdf).use { input ->
                    FileOutputStream(destination.fileDescriptor).use { output ->
                        val bytes = ByteArray(8192)
                        while (true) {
                            if (cancellationSignal.isCanceled) throw java.io.InterruptedIOException("تم إلغاء الطباعة")
                            val count = input.read(bytes)
                            if (count < 0) break
                            output.write(bytes, 0, count)
                        }
                        output.flush()
                    }
                }
            }.onSuccess { callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES)) }
                .onFailure { if (cancellationSignal.isCanceled) callback.onWriteCancelled() else callback.onWriteFailed(it.message ?: "تعذّرت كتابة ملف الطباعة") }
        }.start()
    }
}

private fun decodeVoucherTemplate(path: String): Bitmap? {
    val file = File(path)
    if (!file.isFile) return null
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    val maxSide = maxOf(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
    val sample = maxOf(1, maxSide / 1800)
    return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
}

private fun exportVoucherPdf(
    cacheDir: File,
    cards: List<String>,
    price: String,
    notes: String,
    template: PrintTemplate,
    fromPage: Int,
    toPage: Int
): File {
    require(cards.isNotEmpty()) { "لا توجد كروت مؤكدة للطباعة" }
    val rects = PrintLayout.page(template.columns, template.rows, template.cardWidthMm, template.cardHeightMm, template.marginMm, template.gapMm)
    val perPage = rects.size
    val totalPages = ceil(cards.size.toDouble() / perPage).toInt()
    require(fromPage in 1..totalPages && toPage in fromPage..totalPages)

    val document = PdfDocument()
    val image = template.backgroundPath?.let(::decodeVoucherTemplate)
    val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    val shapePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(243, 248, 252); style = Paint.Style.FILL }
    val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(187, 207, 224); style = Paint.Style.STROKE; strokeWidth = 0.65f }
    val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(19, 65, 100); style = Paint.Style.FILL }
    val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; textSize = 5.4f; typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    val codePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(15, 43, 68); textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(75, 98, 118); textSize = 4.4f; typeface = Typeface.create("sans-serif", Typeface.NORMAL) }
    val serialPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(32, 113, 151); textSize = 4.4f; textAlign = Paint.Align.RIGHT; typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    val pageWidth = (PrintLayout.A4_WIDTH_MM * PrintLayout.POINTS_PER_MM).roundToInt()
    val pageHeight = (PrintLayout.A4_HEIGHT_MM * PrintLayout.POINTS_PER_MM).roundToInt()

    for (pageNumber in fromPage..toPage) {
        val page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        val canvas = page.canvas
        val pageCards = cards.drop((pageNumber - 1) * perPage).take(perPage)
        pageCards.forEachIndexed { localIndex, username ->
            val rect = rects[localIndex]
            val left = rect.xMm * PrintLayout.POINTS_PER_MM
            val top = rect.yMm * PrintLayout.POINTS_PER_MM
            val width = rect.widthMm * PrintLayout.POINTS_PER_MM
            val height = rect.heightMm * PrintLayout.POINTS_PER_MM
            val card = RectF(left, top, left + width, top + height)

            if (image != null) {
                canvas.drawBitmap(image, null, card, bitmapPaint)
            } else {
                canvas.drawRoundRect(card, 3f, 3f, shapePaint)
                canvas.drawRoundRect(card, 3f, 3f, borderPaint)
                val band = RectF(left, top, left + width, top + minOf(7f, height * .28f))
                canvas.drawRoundRect(band, 3f, 3f, bandPaint)
                canvas.drawText("SMART SANAA", left + 5f, top + minOf(5.3f, height * .23f), titlePaint)
            }

            val absoluteIndex = (pageNumber - 1) * perPage + localIndex
            val centerX = left + width * (template.usernameX.coerceIn(0f, 100f) / 100f)
            val textY = top + height * (template.usernameY.coerceIn(15f, 95f) / 100f)
            val allowedWidth = width * (template.usernameWidth.coerceIn(30f, 100f) / 100f)
            canvas.save()
            canvas.clipRect(centerX - allowedWidth / 2f, top, centerX + allowedWidth / 2f, top + height)
            codePaint.textSize = template.usernameSize.coerceIn(6f, 18f)
            val fittedSize = minOf(codePaint.textSize, codePaint.textSize * (allowedWidth / codePaint.measureText(username).coerceAtLeast(1f)).coerceAtMost(1f))
            codePaint.textSize = fittedSize
            canvas.drawText(username, centerX, textY, codePaint)
            canvas.restore()

            if (template.showPrice && price.isNotBlank() && price != "0") {
                canvas.drawText("السعر: $price", left + 4f, top + height - 3f, smallPaint)
            }
            if (template.showSerial) {
                canvas.drawText("${template.serialStart + absoluteIndex}", left + width - 4f, top + height - 3f, serialPaint)
            }
            if (notes.isNotBlank() && template.cardHeightMm >= 20f) {
                smallPaint.textSize = 4f
                canvas.drawText(notes.take(32), left + width / 2f, top + height - 3f, smallPaint)
            }
        }
        document.finishPage(page)
    }

    val directory = File(cacheDir, "exports").apply { mkdirs() }
    val output = File(directory, "smart-sanaa-vouchers-${System.currentTimeMillis()}.pdf")
    output.outputStream().use { document.writeTo(it) }
    document.close()
    image?.recycle()
    return output
}
