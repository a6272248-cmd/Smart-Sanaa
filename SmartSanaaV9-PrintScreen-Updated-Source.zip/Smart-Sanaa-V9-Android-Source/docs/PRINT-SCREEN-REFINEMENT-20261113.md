# Smart Sanaa V9 - printing-screen refinement (2026-11-13)

This revision updates the existing native Android `Vouchers.kt`, retaining RouterOS v6/v7 operations and the original PDF generator.

- Consolidated the visible print panel into template picker, draggable card preview, and 4×20 A4 paper sizing fields.
- Removed unrequested X/Y, font-size and width sliders, separate saved-settings button, and duplicate page-range fields from the visible print screen.
- Moved serial-number activation and its start number into voucher-generation settings.
- Print and save/share PDF remain gated on router-confirmed voucher creation only. Preview before creation remains read-only.
- Existing preferences still persist print sizing and position. Serial reservation logic remains untouched.
- Verified PrintLayout Kotlin source compiled locally and A4 80-card RTL layout check passed.

Not verified: Android Gradle build, emulator/hardware install, connection to MikroTik or printer, and render screenshots. Do not treat this as a verified final APK. Upload on the isolated development branch, execute CI, and test before release.
