package com.smartsanaa.manager

import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.launch
import java.io.File
import java.security.SecureRandom

private val VoucherCyan=Color(0xFF00D9FF)
private val VoucherMuted=Color(0xFF94A3B8)
private val random=SecureRandom()
data class PrintTemplate(val cardWidthMm:Float=63.0f,val cardHeightMm:Float=38.0f,val columns:Int=3,val rows:Int=7,val marginMm:Float=10.0f,val gapMm:Float=2.0f,val usernameSize:Float=12.0f,val showPrice:Boolean=true)

private const val alphabet="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
private fun newCode(length:Int=10)=buildString { repeat(length){append(alphabet[random.nextInt(alphabet.length)])} }

@Composable
fun VoucherCreator(config:RouterConfig,session:RouterOsApi?,connected:Boolean,notification:(String)->Unit) {
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    var profile by remember { mutableStateOf("default") }
    var price by remember { mutableStateOf("0") }
    var duration by remember { mutableStateOf("1d") }
    var quantity by remember { mutableStateOf("1") }
    var notes by remember { mutableStateOf("") }
    var columns by remember { mutableStateOf("3") }
    var rowsPerPage by remember { mutableStateOf("7") }
    var cardWidth by remember { mutableStateOf("63") }
    var cardHeight by remember { mutableStateOf("38") }
    var margin by remember { mutableStateOf("10") }
    var templateName by remember { mutableStateOf("قالب A4 عربي") }
    var creating by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var created by remember { mutableStateOf<List<Pair<String,String>>>(emptyList()) }
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item {Text("إنشاء بطاقات Hotspot",fontWeight=FontWeight.Bold,fontSize=22.sp);Text("إنشاء مستخدمين حقيقيين في RouterOS؛ يجب أن يكون ملف الباقة موجودًا مسبقًا.",color=VoucherMuted,fontSize=12.sp)}
        item {GlassVoucher {
            FieldVoucher("اسم ملف Hotspot Profile",profile){profile=it}
            FieldVoucher("السعر (للطباعة فقط)",price){price=it}
            FieldVoucher("مدة الصلاحية مثال 1d أو 2h",duration){duration=it}
            FieldVoucher("عدد الكروت (1 إلى 100)",quantity){quantity=it}
            FieldVoucher("ملاحظات للطباعة",notes){notes=it}
            Text("إعدادات قالب A4",fontWeight=FontWeight.Bold,fontSize=16.sp)
            FieldVoucher("اسم القالب",templateName){templateName=it}
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { FieldVoucher("الأعمدة",columns){columns=it}; FieldVoucher("الصفوف",rowsPerPage){rowsPerPage=it} }
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { FieldVoucher("عرض الكرت mm",cardWidth){cardWidth=it}; FieldVoucher("ارتفاع الكرت mm",cardHeight){cardHeight=it} }
            FieldVoucher("هامش الصفحة mm",margin){margin=it}
            Text("المعاينة: ${columns.toIntOrNull() ?: 3} × ${rowsPerPage.toIntOrNull() ?: 7} كرت في صفحة A4",color=VoucherCyan,fontSize=12.sp)
            Text("يتم إنشاء اسم مستخدم وكلمة مرور عشوائيين لكل بطاقة. مدة الاستخدام limit-uptime وليست تاريخ انتهاء تلقائي.",color=VoucherMuted,fontSize=12.sp)
            Button(onClick={
                val count=quantity.toIntOrNull() ?: 0
                if(!connected || count !in 1..100 || profile.isBlank() || duration.isBlank()) {status="اتصل بالراوتر وتحقق من حقول الباقة والعدد"}
                else {
                    creating=true;status="جار إنشاء البطاقات…"
                    scope.launch {
                        val done=mutableListOf<Pair<String,String>>()
                        val api=session
                        if(api==null){ status="جلسة الراوتر غير متاحة"; creating=false; notification(status); return@launch }
                        val batchId = java.util.UUID.randomUUID().toString()
                        for(i in 0 until count) {
                            val username="SM"+newCode(9);val password=newCode(10)
                            val result=runCatching {api.execute("/ip/hotspot/user/add",mapOf("name" to username,"password" to password,"profile" to profile,"limit-uptime" to duration,"comment" to "Smart Manager batch $batchId item ${i+1}/$count"))}
                            if(result.isFailure){status="تم إنشاء ${done.size} من $count. الخطأ: ${result.exceptionOrNull()?.message}";break}
                            done+=username to password
                        }
                        created=done.toList()
                        if(done.size==count)status="تم إنشاء $count كرت فعلياً على Hotspot"
                        creating=false;notification(status)
                    }
                }
            },enabled=!creating,modifier=Modifier.fillMaxWidth()) {Text(if(creating)"جار الإنشاء…" else "إنشاء الكروت على الراوتر")}
            if(status.isNotBlank())Text(status,color=VoucherCyan,fontSize=12.sp)
        } }
        if(created.isNotEmpty()) item {GlassVoucher {
            Text("بطاقات مُنشأة (${created.size})",fontWeight=FontWeight.Bold)
            created.take(10).forEach {(u,p)->Text("$u    /    $p",fontSize=12.sp)}
            if(created.size>10)Text("بقية البطاقات مضمنة في PDF",color=VoucherMuted)
            Button(onClick={
                runCatching { val template=PrintTemplate(cardWidth.toFloatOrNull() ?: 63f,cardHeight.toFloatOrNull() ?: 38f,columns.toIntOrNull()?.coerceIn(1,6) ?: 3,rowsPerPage.toIntOrNull()?.coerceIn(1,12) ?: 7,margin.toFloatOrNull() ?: 10f);val file=exportVoucherPdf(context.cacheDir,created,price,notes,template);val uri=FileProvider.getUriForFile(context,"${context.packageName}.provider",file)
                    val intent=Intent(Intent.ACTION_SEND).apply {type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}
                    context.startActivity(Intent.createChooser(intent,"مشاركة PDF للكروت")) }
                .onFailure { status=it.message ?: "تعذر تصدير PDF" }
            },modifier=Modifier.fillMaxWidth()){Text("تصدير ومشاركة PDF")}
        } }
    }
}
@Composable private fun GlassVoucher(content:@Composable ColumnScope.()->Unit){
    Column(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalArrangement=Arrangement.spacedBy(11.dp),content=content)
}
@Composable private fun FieldVoucher(label:String,value:String,update:(String)->Unit){OutlinedTextField(value,update,label={Text(label)},modifier=Modifier.fillMaxWidth(),singleLine=true)}

private fun exportVoucherPdf(cacheDir:File,cards:List<Pair<String,String>>,price:String,notes:String,template:PrintTemplate=PrintTemplate()):File {
    val pdf=PdfDocument();val ink=Paint(Paint.ANTI_ALIAS_FLAG).apply {textSize=15f;color=android.graphics.Color.BLACK}
    var pageNo=1
    cards.chunked(template.columns*template.rows).forEach {chunk->
        val page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo++).create())
        val canvas=page.canvas
        ink.textSize=20f;ink.isFakeBoldText=true;canvas.drawText("SMART MANAGER VOUCHERS",35f,45f,ink)
        ink.textSize=12f;ink.isFakeBoldText=false
        chunk.forEachIndexed {index,(user,password)->
            val col=index % template.columns; val row=index / template.columns
            val cardW=520f/template.columns; val cardH=760f/template.rows
            val left=35f+col*cardW; val top=60f+row*cardH
            ink.style=Paint.Style.STROKE;canvas.drawRoundRect(left,top,left+cardW-6f,top+cardH-6f,8f,8f,ink);ink.style=Paint.Style.FILL
            ink.textSize=template.usernameSize; canvas.drawText("USER: $user",left+10f,top+20f,ink)
            canvas.drawText("PASS: $password",left+10f,top+38f,ink)
            if(template.showPrice) canvas.drawText("PRICE: $price",left+10f,top+56f,ink)
            canvas.drawText(notes.take(24),left+10f,top+74f,ink)
        }
        pdf.finishPage(page)
    }
    val file=File(cacheDir,"smart-manager-vouchers-${System.currentTimeMillis()}.pdf")
    file.outputStream().use {pdf.writeTo(it)};pdf.close();return file
}
