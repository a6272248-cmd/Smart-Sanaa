package com.smartsanaa.manager

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** AES-GCM AndroidKeyStore for local secrets; passwords never stored as plaintext. */
class SecureConfig(context: Context) {
    private val prefs = context.getSharedPreferences("router_settings", Context.MODE_PRIVATE)
    private val alias = "sm_router_credentials_v1"
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
        return gen.generateKey()
    }
    private fun encrypt(s:String):String { val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());return Base64.encodeToString(c.iv+c.doFinal(s.toByteArray()),Base64.NO_WRAP) }
    private fun decrypt(s:String):String = runCatching { val all=Base64.decode(s,Base64.NO_WRAP);val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,all.copyOfRange(0,12)));String(c.doFinal(all.copyOfRange(12,all.size))) }.getOrDefault("")
    fun get(): RouterConfig = RouterConfig(
        host=prefs.getString("host","10.11.0.5") ?: "10.11.0.5",
        port=prefs.getInt("port",8728), username=prefs.getString("user","admin") ?: "admin",
        password=decrypt(prefs.getString("secret","") ?: ""),tls=prefs.getBoolean("tls",false)
    )
    fun save(c:RouterConfig) { prefs.edit().putString("host",c.host).putInt("port",c.port).putString("user",c.username).putString("secret",encrypt(c.password)).putBoolean("tls",c.tls).apply() }
}
