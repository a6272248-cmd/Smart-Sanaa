package com.smartsanaa.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.launch
import java.time.LocalDateTime

private val Bg = Color(0xFF020817)
private val Surface = Color(0xFF091B32)
private val Cyan = Color(0xFF00D9FF)
private val Blue = Color(0xFF0EA5FF)
private val Muted = Color(0xFF94A3B8)
private val Green = Color(0xFF22C55E)
private val Red = Color(0xFFEF4444)
private val Amber = Color(0xFFF59E0B)

enum class Screen(val arabic: String) {
    SPLASH("البداية"), LOGIN("تسجيل الدخول"), HOME("الرئيسية"), USERS("المستخدمون"), USER_DETAILS("تفاصيل المستخدم"),
    CARDS("الكروت"), CREATE_CARD("إنشاء كرت"), PACKAGES("الباقات"), HOTSPOT("Hotspot"), PPPOE("PPPoE"),
    REPORTS("التقارير"), AI("Smart AI Center"), DEVICE("معلومات الجهاز"), NOTIFICATIONS("الإشعارات"),
    SETTINGS("الإعدادات"), PROFILE("الملف الشخصي"), MENU("القائمة الجانبية")
}

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); setContent { SmartManagerApp() } }
}

@Composable
fun SmartManagerApp() {
    val context = LocalContext.current
    val store = remember { SecureConfig(context) }
    var config by remember { mutableStateOf(store.get()) }
    var page by remember { mutableStateOf(Screen.SPLASH) }
    var previous by remember { mutableStateOf(Screen.HOME) }
    var connected by remember { mutableStateOf(false) }
    var version by remember { mutableStateOf("—") }
    var board by remember { mutableStateOf<Map<String,String>>(emptyMap()) }
    var rows by remember { mutableStateOf<List<Map<String,String>>>(emptyList()) }
    var selected by remember { mutableStateOf<Map<String,String>>(emptyMap()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var currentPath by remember { mutableStateOf("") }
    val scope=rememberCoroutineScope()
    val isV7=version.substringBefore('.').toIntOrNull()?.let { it >= 7 } ?: true
    fun goto(next: Screen) { previous=page; page=next; rows=emptyList(); search=""; message="" }
    fun fetch(next: Screen) {
        goto(next)
        val path=RouterCommands.list(next,isV7)
        if(path != null && connected) {
            busy=true; currentPath=path
            scope.launch { runCatching { RouterOsApi(config).execute(path).data }.onSuccess { rows=it;message="تم تحديث البيانات" }.onFailure { message=it.message ?: "فشل الاتصال" };busy=false }
        }
    }
    fun connect() {
        busy=true;message="جار الاتصال بالراوتر…"
        scope.launch {
            runCatching {
                val api=RouterOsApi(config)
                val resources=api.execute("/system/resource/print").data.firstOrNull().orEmpty()
                val identity=api.execute("/system/identity/print").data.firstOrNull().orEmpty()
                resources + mapOf("identity" to (identity["name"] ?: "MikroTik"))
            }.onSuccess { board=it;version=it["version"] ?: "—";connected=true;page=Screen.HOME;message="تم الاتصال" }
             .onFailure { connected=false;message=it.message ?: "فشل الاتصال بالراوتر" }
            busy=false
        }
    }
    BackHandler(page != Screen.SPLASH && page != Screen.LOGIN && page != Screen.HOME) { page=if(page==Screen.USER_DETAILS) Screen.USERS else Screen.HOME }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme=darkColorScheme(primary=Cyan,secondary=Blue,background=Bg,surface=Surface,onSurface=Color.White,onBackground=Color.White)) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF061B35),Bg,Bg)))) {
                Column(Modifier.fillMaxSize()) {
                    if(page !in listOf(Screen.SPLASH,Screen.LOGIN)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=12.dp), verticalAlignment=Alignment.CenterVertically) {
                            IconButton(onClick={goto(Screen.MENU)}){Icon(Icons.Default.Menu,"القائمة",tint=Cyan)}
                            Column(Modifier.weight(1f)) { Text("سمارت مانجر",fontWeight=FontWeight.ExtraBold,fontSize=21.sp);Text(page.arabic,fontSize=12.sp,color=Muted) }
                            IconButton(onClick={fetch(Screen.NOTIFICATIONS)}){Icon(Icons.Default.Notifications,"الإشعارات",tint=Cyan)}
                            Box(Modifier.size(9.dp).background(if(connected) Green else Red,CircleShape))
                        }
                    }
                    Box(Modifier.weight(1f)) {
                        when(page) {
                            Screen.SPLASH -> Splash { page=Screen.LOGIN }
                            Screen.LOGIN -> Login(config, {config=it;store.save(it)}, {connect()},busy,message)
                            Screen.HOME -> Home(board,connected,message,{connect()},{fetch(it)})
                            Screen.USERS,Screen.CARDS,Screen.PACKAGES,Screen.HOTSPOT,Screen.PPPOE,Screen.DEVICE,Screen.NOTIFICATIONS -> {
                                Listing(page,rows,busy,message,search,{search=it},{fetch(page)},{ row -> selected=row;goto(Screen.USER_DETAILS) },{goto(Screen.CREATE_CARD)})
                            }
                            Screen.USER_DETAILS -> Detail(selected){fetch(Screen.USERS)}
                            Screen.CREATE_CARD -> VoucherCreator(config,isV7,connected){msg->message=msg}
                            Screen.REPORTS -> Reports(connected,rows){fetch(Screen.HOTSPOT)}
                            Screen.AI -> Insights(board,connected)
                            Screen.SETTINGS -> Settings(config,{config=it;store.save(it);connected=false}, {connect()},message,busy)
                            Screen.PROFILE -> Profile({goto(Screen.SETTINGS)},{connected=false;page=Screen.LOGIN})
                            Screen.MENU -> SideMenu(connected,{fetch(it)},{connected=false;page=Screen.LOGIN})
                        }
                    }
                    if(page !in listOf(Screen.SPLASH,Screen.LOGIN,Screen.MENU)) BottomNav(page){fetch(it)}
                }
            }
        }
    }
}

@Composable private fun Glass(modifier:Modifier=Modifier, content:@Composable ColumnScope.()->Unit) {
    Column(modifier.clip(RoundedCornerShape(22.dp)).background(Surface.copy(alpha=.86f)).border(1.dp,Cyan.copy(alpha=.23f),RoundedCornerShape(22.dp)).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp),content=content)
}
@Composable private fun Heading(title:String,sub:String="") { Column { Text(title,fontSize=20.sp,fontWeight=FontWeight.Bold);if(sub.isNotEmpty()) Text(sub,fontSize=12.sp,color=Muted) } }
@Composable private fun Indicator(name:String,value:String,color:Color=Cyan) { Glass(Modifier.width(145.dp)){ Text(name,fontSize=12.sp,color=Muted);Text(value,fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=color) } }
@Composable private fun Action(title:String,icon:ImageVector,modifier:Modifier=Modifier,onClick:()->Unit) {
    OutlinedButton(onClick,modifier.height(66.dp),shape=RoundedCornerShape(17.dp),colors=ButtonDefaults.outlinedButtonColors(containerColor=Surface),border=BorderStroke(1.dp,Cyan.copy(alpha=.35f))) {
        Icon(icon,null,tint=Cyan,modifier=Modifier.size(20.dp)); Spacer(Modifier.width(7.dp));Text(title,fontSize=12.sp,maxLines=1)
    }
}
@Composable private fun Splash(next:()->Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Icon(Icons.Default.Router,null,tint=Cyan,modifier=Modifier.size(100.dp))
        Spacer(Modifier.height(32.dp));Text("سمارت مانجر",fontSize=36.sp,fontWeight=FontWeight.Black)
        Text("SMART MANAGER ENTERPRISE",fontSize=13.sp,color=Cyan)
        Spacer(Modifier.height(18.dp));Text("منصة احترافية لإدارة شبكات MikroTik",color=Muted)
        Spacer(Modifier.height(50.dp));Button(onClick=next,modifier=Modifier.fillMaxWidth()){Text("ابدأ الآن")}
    }
}
@Composable private fun Login(config:RouterConfig,update:(RouterConfig)->Unit,submit:()->Unit,busy:Boolean,message:String) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.Center) {
        Icon(Icons.Default.Router,null,tint=Cyan,modifier=Modifier.size(70.dp).align(Alignment.CenterHorizontally));Spacer(Modifier.height(16.dp))
        Heading("مرحباً بك","اتصل بجهاز MikroTik لإدارة الشبكة")
        Spacer(Modifier.height(20.dp))
        Glass(Modifier.fillMaxWidth()) {
            Entry("عنوان IP أو اسم المضيف",config.host,{update(config.copy(host=it))})
            Entry("اسم المستخدم",config.username,{update(config.copy(username=it))})
            Entry("كلمة المرور",config.password,{update(config.copy(password=it))},secret=true)
            Entry("منفذ API",config.port.toString(),{update(config.copy(port=it.toIntOrNull() ?: 8728))},number=true)
            Row(verticalAlignment=Alignment.CenterVertically) { Switch(config.tls,{update(config.copy(tls=it,port=if(it)8729 else 8728))});Spacer(Modifier.width(8.dp));Text("اتصال TLS مشفر (8729)",fontSize=13.sp) }
            Text("تنبيه: المنفذ 8728 غير مشفر، استخدمه داخل شبكة موثوقة فقط.",fontSize=11.sp,color=Amber)
            Button(onClick=submit,modifier=Modifier.fillMaxWidth(),enabled=!busy&&config.host.isNotBlank()&&config.username.isNotBlank()){Text(if(busy)"جار الاتصال..." else "تسجيل الدخول إلى الراوتر")}
            if(message.isNotBlank())Text(message,color=if(message.startsWith("تم"))Green else Amber,fontSize=12.sp)
        }
    }
}
@Composable private fun Entry(title:String,value:String,onChange:(String)->Unit,secret:Boolean=false,number:Boolean=false) {
    OutlinedTextField(value,onChange,label={Text(title)},modifier=Modifier.fillMaxWidth(),singleLine=true,visualTransformation=if(secret)PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,keyboardOptions=KeyboardOptions(keyboardType=if(number)KeyboardType.Number else KeyboardType.Text),colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Cyan,unfocusedBorderColor=Muted.copy(alpha=.35f)))
}
@Composable private fun Home(board:Map<String,String>,connected:Boolean,message:String,reload:()->Unit,navigate:(Screen)->Unit) {
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        item { Glass(Modifier.fillMaxWidth()) {
            Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Router,null,tint=Cyan,modifier=Modifier.size(56.dp));Spacer(Modifier.width(14.dp));Column {Text(board["board-name"] ?: "MikroTik Router",fontSize=19.sp,fontWeight=FontWeight.Bold);Text("RouterOS ${board["version"] ?: "—"}",color=Muted);Text(board["identity"] ?: "لا توجد بيانات",color=Muted)} }
            Text(if(connected)"● متصل بالشبكة" else "● غير متصل",color=if(connected)Green else Red)
            if(!connected)Button(onClick=reload){Text("اتصال الآن")}
        } }
        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)){Indicator("CPU",(board["cpu-load"] ?: "—")+if(connected)"%" else "")}
            Box(Modifier.weight(1f)){Indicator("Uptime",board["uptime"] ?: "—")}
        } }
        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            val free=board["free-memory"]?.toDoubleOrNull();val total=board["total-memory"]?.toDoubleOrNull()
            val ram=if(free!=null&&total!=null&&total>0)"${((1-free/total)*100).toInt()}%" else "—"
            val disk=board["free-hdd-space"]?.toDoubleOrNull();val capacity=board["total-hdd-space"]?.toDoubleOrNull()
            val storage=if(disk!=null&&capacity!=null&&capacity>0)"${((1-disk/capacity)*100).toInt()}%" else "—"
            Box(Modifier.weight(1f)){Indicator("RAM",ram)};Box(Modifier.weight(1f)){Indicator("Storage",storage)}
        } }
        item { Glass(Modifier.fillMaxWidth()) { Heading("حركة الشبكة","الرسوم الحية تتطلب دورية قياس للواجهات");Text("افتح معلومات الجهاز لعرض الواجهات وعداداتها الفعلية.",color=Muted,fontSize=13.sp);Action("معلومات الجهاز",Icons.Default.ShowChart,Modifier.fillMaxWidth()){navigate(Screen.DEVICE)} } }
        item { Heading("الوصول السريع") }
        item { Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf(listOf(Triple("المستخدمون",Screen.USERS,Icons.Default.People),Triple("الكروت",Screen.CARDS,Icons.Default.CreditCard),Triple("الباقات",Screen.PACKAGES,Icons.Default.Layers)),listOf(Triple("Hotspot",Screen.HOTSPOT,Icons.Default.Wifi),Triple("PPPoE",Screen.PPPOE,Icons.Default.Router),Triple("التقارير",Screen.REPORTS,Icons.Default.BarChart))).forEach { group -> Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { group.forEach { (label,s,icon) -> Action(label,icon,Modifier.weight(1f)){navigate(s)} } } }
        } }
        item { Glass(Modifier.fillMaxWidth()) { Heading("Smart AI Insights","قراءات وتشخيصات محلية");Text(if(connected) "المعالج: ${board["cpu-load"] ?: "—"}% · مدة التشغيل: ${board["uptime"] ?: "—"}" else "اتصل بالراوتر لعرض المؤشرات.",color=Muted);Action("فتح مركز التحليل",Icons.Default.AutoAwesome,Modifier.fillMaxWidth()){navigate(Screen.AI)} } }
        if(message.isNotEmpty()) item {Text(message,fontSize=12.sp,color=Muted)}
    }
}
@Composable private fun Listing(page:Screen,rows:List<Map<String,String>>,busy:Boolean,message:String,search:String,onSearch:(String)->Unit,reload:()->Unit,details:(Map<String,String>)->Unit,create:()->Unit) {
    val filtered=rows.filter { it.values.any { v->v.contains(search,ignoreCase=true) } }
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Heading(page.arabic,"بيانات حقيقية من جهاز MikroTik المتصل") }
        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
            Indicator("إجمالي السجلات",rows.size.toString());IconButton(onClick=reload){Icon(Icons.Default.Refresh,"تحديث",tint=Cyan)}
            if(page==Screen.CARDS) IconButton(onClick=create){Icon(Icons.Default.Add,"إنشاء كرت",tint=Green)}
        } }
        item { Entry("بحث في النتائج",search,onSearch) }
        if(busy)item { CircularProgressIndicator(color=Cyan) }
        if(message.isNotEmpty())item {Text(message,color=Muted,fontSize=12.sp)}
        if(!busy&&filtered.isEmpty())item {Glass(Modifier.fillMaxWidth()){Text("لا توجد بيانات للعرض. تحقق من الاتصال والصلاحيات والخدمة على الراوتر.",color=Muted)} }
        items(filtered.take(500)){ item ->
            val name=item["name"] ?: item["user"] ?: item[".id"] ?: "سجل"
            Glass(Modifier.fillMaxWidth().clickable{details(item)}) {
                Row(verticalAlignment=Alignment.CenterVertically) {Icon(when(page){Screen.HOTSPOT->Icons.Default.Wifi;Screen.PPPOE->Icons.Default.Router;Screen.PACKAGES->Icons.Default.Layers;Screen.DEVICE->Icons.Default.SettingsEthernet;else->Icons.Default.Person},null,tint=Cyan);Spacer(Modifier.width(10.dp));Text(name,Modifier.weight(1f),fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Icon(Icons.Default.ChevronLeft,null,tint=Muted)}
                val fields=item.filterKeys { it !in listOf("name","user","!type") }.entries.take(4)
                fields.forEach { (k,v)->Text("$k: $v",color=Muted,fontSize=11.sp,maxLines=1,overflow=TextOverflow.Ellipsis) }
            }
        }
    }
}
@Composable private fun Detail(row:Map<String,String>,back:()->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {Heading("تفاصيل السجل","معلومات مستردة من RouterOS")}
        item {Glass(Modifier.fillMaxWidth()){Icon(Icons.Default.AccountCircle,null,tint=Cyan,modifier=Modifier.size(66.dp));Text(row["name"] ?: row["user"] ?: "—",fontSize=20.sp,fontWeight=FontWeight.Bold)} }
        items(row.entries.toList()){(k,v)->Glass(Modifier.fillMaxWidth()){Text(k,color=Muted,fontSize=12.sp);Text(v)} }
        item {Button(back){Text("العودة للمستخدمين")}}
    }
}
@Composable private fun Reports(connected:Boolean,rows:List<Map<String,String>>,go:()->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item {Heading("التقارير والتحليلات","بيانات الشبكة وتقارير النشاط")}
        item {Glass(Modifier.fillMaxWidth()){Text("تقارير الإيرادات والمبيعات تحتاج إلى سجل مالي أو قاعدة بيانات للمدفوعات.",color=Amber);Text("لن نعرض مبالغ افتراضية باعتبارها إيرادات حقيقية.",color=Muted,fontSize=12.sp)} }
        item {Indicator("حالة الراوتر",if(connected)"متصل" else "غير متصل",if(connected)Green else Red)}
        item {Action("فتح الجلسات الفعلية",Icons.Default.BarChart,Modifier.fillMaxWidth(),go)}
    }
}
@Composable private fun Insights(board:Map<String,String>,connected:Boolean) {
    val cpu=board["cpu-load"]?.toIntOrNull()
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {Heading("Smart AI Center","مساعد مراقبة محلي قائم على قواعد واضحة")}
        item {Glass(Modifier.fillMaxWidth()){Icon(Icons.Default.AutoAwesome,null,tint=Cyan,modifier=Modifier.size(50.dp));Text("تحليل صحة الشبكة",fontSize=20.sp,fontWeight=FontWeight.Bold);Text(if(!connected)"اتصل بالراوتر أولاً" else if(cpu!=null&&cpu>=85)"تحذير: استهلاك CPU مرتفع ($cpu%). راجع العمليات النشطة." else "استهلاك CPU في النطاق المعتاد (${cpu ?: "—"}%).",color=if(cpu!=null&&cpu>=85)Amber else Green)} }
        item {Glass(Modifier.fillMaxWidth()){Heading("التوقعات الذكية");Text("التنبؤ بالاستهلاك يتطلب تخزين سلسلة زمنية من القياسات؛ غير مفعل في هذا الإصدار.",color=Muted)} }
        item {Glass(Modifier.fillMaxWidth()){Heading("التنبيهات الأمنية");Text("راجع سجلات النظام وشاشة الإشعارات لمشاهدة أحداث الراوتر الفعلية.",color=Muted)} }
    }
}
@Composable private fun Settings(config:RouterConfig,save:(RouterConfig)->Unit,connect:()->Unit,message:String,busy:Boolean) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item {Heading("الإعدادات","الشبكة والأمان والمظهر")}
        item {Glass(Modifier.fillMaxWidth()) {
            Heading("إعدادات الاتصال")
            Entry("عنوان الراوتر",config.host,{save(config.copy(host=it))})
            Entry("المستخدم",config.username,{save(config.copy(username=it))})
            Entry("كلمة المرور",config.password,{save(config.copy(password=it))},secret=true)
            Entry("المنفذ",config.port.toString(),{save(config.copy(port=it.toIntOrNull() ?: 8728))},number=true)
            Row(verticalAlignment=Alignment.CenterVertically) {Switch(config.tls,{save(config.copy(tls=it,port=if(it)8729 else 8728))});Text("  API-SSL / TLS")}
            Button(onClick=connect,enabled=!busy,modifier=Modifier.fillMaxWidth()){Text("حفظ واختبار الاتصال")}
            if(message.isNotEmpty())Text(message,color=Muted,fontSize=12.sp)
        } }
        item {Glass(Modifier.fillMaxWidth()){Heading("الأمان");Text("بيانات الاعتماد مشفرة بـ Android Keystore. يوصى باتصال TLS وشهادة موثوقة.",color=Muted,fontSize=13.sp)} }
        item {Glass(Modifier.fillMaxWidth()){Heading("عن التطبيق");Text("Smart Manager Enterprise · Android Native · v0.1.0",color=Muted)} }
    }
}
@Composable private fun Profile(settings:()->Unit,logout:()->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(15.dp)) {
        item {Glass(Modifier.fillMaxWidth(),){Icon(Icons.Default.AccountCircle,null,tint=Cyan,modifier=Modifier.size(90.dp).align(Alignment.CenterHorizontally));Text("مدير الشبكة",fontSize=22.sp,fontWeight=FontWeight.Bold);Text("حساب إدارة MikroTik",color=Muted)} }
        item {Action("إعدادات الاتصال والأمان",Icons.Default.Security,Modifier.fillMaxWidth(),settings)}
        item {Button(onClick=logout,colors=ButtonDefaults.buttonColors(containerColor=Red),modifier=Modifier.fillMaxWidth()){Text("تسجيل الخروج")}}
    }
}
@Composable private fun SideMenu(connected:Boolean,navigate:(Screen)->Unit,logout:()->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        item {Glass(Modifier.fillMaxWidth()){Text("SMART MANAGER",fontSize=22.sp,fontWeight=FontWeight.Black,color=Cyan);Text(if(connected)"● متصل" else "● غير متصل",color=if(connected)Green else Red)} }
        items(listOf(Screen.HOME,Screen.USERS,Screen.CARDS,Screen.CREATE_CARD,Screen.PACKAGES,Screen.HOTSPOT,Screen.PPPOE,Screen.REPORTS,Screen.AI,Screen.DEVICE,Screen.NOTIFICATIONS,Screen.SETTINGS,Screen.PROFILE)){s->Action(s.arabic,Icons.Default.ChevronLeft,Modifier.fillMaxWidth()){navigate(s)} }
        item {Button(onClick=logout,colors=ButtonDefaults.buttonColors(containerColor=Red),modifier=Modifier.fillMaxWidth()){Text("تسجيل الخروج")}}
    }
}
@Composable private fun BottomNav(active:Screen,navigate:(Screen)->Unit) {
    val options=listOf(Triple(Screen.HOME,"الرئيسية",Icons.Default.Home),Triple(Screen.USERS,"العملاء",Icons.Default.People),Triple(Screen.CARDS,"الكروت",Icons.Default.CreditCard),Triple(Screen.REPORTS,"التقارير",Icons.Default.BarChart),Triple(Screen.SETTINGS,"الإعدادات",Icons.Default.Settings))
    NavigationBar(containerColor=Color(0xFF07182D),tonalElevation=0.dp) {
        options.forEach { (screen,label,icon)->NavigationBarItem(selected=screen==active,onClick={navigate(screen)},icon={Icon(icon,label)},label={Text(label,fontSize=10.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Cyan,selectedTextColor=Cyan,unselectedIconColor=Muted,unselectedTextColor=Muted,indicatorColor=Cyan.copy(alpha=.12f)))}
    }
}
