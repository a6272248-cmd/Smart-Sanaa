package com.smartsanaa.manager

import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.launch
import java.io.File
import java.security.SecureRandom

private val VoucherCyan=Color(0xFF00D9FF)
private val VoucherMuted=Color(0xFF94A3B8)
private val random=SecureRandom()
private const val alphabet="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
private fun newCode(length:Int=10)=buildString { repeat(length){append(alphabet[random.nextInt(alphabet.length)])} }

@Composable
fun VoucherCreator(config:RouterConfig,isV7:Boolean,connected:Boolean,notification:(String)->Unit) {
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    var profile by remember { mutableStateOf("default") }
    var price by remember { mutableStateOf("0") }
    var duration by remember { mutableStateOf("1d") }
    var quantity by remember { mutableStateOf("1") }
    var notes by remember { mutableStateOf("") }
    var creating by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var created by remember { mutableStateOf<List<Pair<String,String>>>(emptyList()) }
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item {Text("إنشاء بطاقات Hotspot",fontWeight=FontWeight.Bold,fontSize=22.sp);Text("إنشاء مستخدمين حقيقيين في RouterOS؛ يجب أن يكون ملف الباقة موجودًا مسبقًا.",color=VoucherMuted,fontSize=12.sp)}
        item {GlassVoucher {
            FieldVoucher("اسم ملف Hotspot Profile",profile){profile=it}
            FieldVoucher("السعر (للطباعة فقط)",price){price=it}
            FieldVoucher("مدة الصلاحية مثال 1d أو 2h",duration){duration=it}
            FieldVoucher("عدد الكروت (1 إلى 100)",quantity){quantity=it}
            FieldVoucher("ملاحظات للطباعة",notes){notes=it}
            Text("يتم إنشاء اسم مستخدم وكلمة مرور عشوائيين لكل بطاقة. مدة الاستخدام limit-uptime وليست تاريخ انتهاء تلقائي.",color=VoucherMuted,fontSize=12.sp)
            Button(onClick={
                val count=quantity.toIntOrNull() ?: 0
                if(!connected || count !in 1..100 || profile.isBlank() || duration.isBlank()) {status="اتصل بالراوتر وتحقق من حقول الباقة والعدد"}
                else {
                    creating=true;status="جار إنشاء البطاقات…"
                    scope.launch {
                        val done=mutableListOf<Pair<String,String>>()
                        val api=RouterOsApi(config)
                        for(i in 0 until count) {
                            val username="SM"+newCode(9);val password=newCode(10)
                            val result=runCatching {api.execute("/ip/hotspot/user/add",mapOf("name" to username,"password" to password,"profile" to profile,"limit-uptime" to duration,"comment" to "Smart Manager voucher"))}
                            if(result.isFailure){status="تم إنشاء ${done.size} من $count. الخطأ: ${result.exceptionOrNull()?.message}";break}
                            done+=username to password
                        }
                        created=done.toList()
                        if(done.size==count)status="تم إنشاء $count كرت فعلياً على Hotspot"
                        creating=false;notification(status)
                    }
                }
            },enabled=!creating,modifier=Modifier.fillMaxWidth()) {Text(if(creating)"جار الإنشاء…" else "إنشاء الكروت على الراوتر")}
            if(status.isNotBlank())Text(status,color=VoucherCyan,fontSize=12.sp)
        } }
        if(created.isNotEmpty()) item {GlassVoucher {
            Text("بطاقات مُنشأة (${created.size})",fontWeight=FontWeight.Bold)
            created.take(10).forEach {(u,p)->Text("$u    /    $p",fontSize=12.sp)}
            if(created.size>10)Text("بقية البطاقات مضمنة في PDF",color=VoucherMuted)
            Button(onClick={
                runCatching { val file=exportVoucherPdf(context.cacheDir,created,price,notes);val uri=FileProvider.getUriForFile(context,"${context.packageName}.provider",file)
                    val intent=Intent(Intent.ACTION_SEND).apply {type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}
                    context.startActivity(Intent.createChooser(intent,"مشاركة PDF للكروت")) }
                .onFailure { status=it.message ?: "تعذر تصدير PDF" }
            },modifier=Modifier.fillMaxWidth()){Text("تصدير ومشاركة PDF")}
        } }
    }
}
@Composable private fun GlassVoucher(content:@Composable ColumnScope.()->Unit){
    Column(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalArrangement=Arrangement.spacedBy(11.dp),content=content)
}
@Composable private fun FieldVoucher(label:String,value:String,update:(String)->Unit){OutlinedTextField(value,update,label={Text(label)},modifier=Modifier.fillMaxWidth(),singleLine=true)}

private fun exportVoucherPdf(cacheDir:File,cards:List<Pair<String,String>>,price:String,notes:String):File {
    val pdf=PdfDocument();val ink=Paint(Paint.ANTI_ALIAS_FLAG).apply {textSize=15f;color=android.graphics.Color.BLACK}
    val unit=28; var pageNo=1
    cards.chunked(15).forEach {chunk->
        val page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo++).create())
        val canvas=page.canvas
        ink.textSize=20f;ink.isFakeBoldText=true;canvas.drawText("SMART MANAGER VOUCHERS",35f,45f,ink)
        ink.textSize=12f;ink.isFakeBoldText=false
        chunk.forEachIndexed {index,(user,password)->
            val top=78f+index*49f
            ink.style=Paint.Style.STROKE;canvas.drawRoundRect(28f,top,566f,top+42f,8f,8f,ink);ink.style=Paint.Style.FILL
            canvas.drawText("USER: $user",40f,top+17f,ink)
            canvas.drawText("PASS: $password",235f,top+17f,ink)
            canvas.drawText("PRICE: $price",440f,top+17f,ink)
            canvas.drawText(notes.take(65),40f,top+34f,ink)
        }
        pdf.finishPage(page)
    }
    val file=File(cacheDir,"smart-manager-vouchers-${System.currentTimeMillis()}.pdf")
    file.outputStream().use {pdf.writeTo(it)};pdf.close();return file
}
