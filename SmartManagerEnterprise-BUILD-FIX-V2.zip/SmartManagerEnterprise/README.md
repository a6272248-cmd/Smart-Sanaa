# SMART MANAGER ENTERPRISE — Android Native (Arabic RTL)

**Status: functional source-code foundation / unverified build.** This is a real Android/Kotlin/Jetpack Compose project, **not** a converted UI image or a WebView. It contains all 17 navigable screens, a RouterOS API client, encrypted credential storage, real resource and listing calls, a Hotspot voucher generator, PDF export and a GitHub Actions APK build workflow. It has **not** been compiled against the Android SDK or tested on a physical MikroTik from this environment. Some ambitious modules are deliberately labeled not implemented rather than populated with fake data.

## 17 screens
01 Splash · 02 Login · 03 Home · 04 Users · 05 User details · 06 Cards · 07 Create card · 08 Packages · 09 Hotspot · 10 PPPoE · 11 Reports · 12 Smart AI · 13 Device information · 14 Notifications · 15 Settings · 16 Profile · 17 Side menu.

## Current implementation map
- **Live:** RouterOS login over API; system resource / identity; interface listing; Hotspot active sessions; PPPoE active sessions; RouterOS logs; User Manager user/profile listings using v6 vs v7 paths; searchable user rows; actual Hotspot user creation with random usernames/passwords; voucher PDF sharing.
- **Partial:** dashboard traffic (status and navigation rather than continuous plotted throughput), device health; user details show available RouterOS fields.
- **Not implemented:** persistence of invoices, payment/revenue reports, package purchase billing, background monitoring, ML forecasting, genuine AI chatbot, biometrics, remote push notifications, backup/restore. Those require additional database/service components and are **not** claimed as working.
- RouterOS behavior is dependent on installed User Manager and API permissions. RouterOS v6 older *challenge-response login* firmware is not implemented. Source code supports v6/v7 command-path selection for the listed operations.

## Source code and GitHub setup
The archive `SmartManagerEnterprise-GitHub-Source.zip` contains an **already structured** Android Studio / Gradle repository, including `.github/workflows/android.yml`. GitHub **does not automatically unzip a ZIP uploaded via the Add file > Upload files webpage**. For zero local command-line work, extract the ZIP on your phone or computer and upload the *extracted* files/folders using GitHub's web interface (including the hidden `.github` folder). If using a Git client, commit the extracted directory into your repository root. GitHub Actions then automatically runs the build, and its successful run uploads `SmartManagerEnterprise-debug-apk` under **Actions > run > Artifacts**.

**Do not upload ZIP alone and expect GitHub to unpack it.** Without unpacking or an existing extraction action in the target repository, that cannot work automatically.

## Build
Android Studio: open the extracted `SmartManagerEnterprise` directory; sync Gradle; select **Build > Build APK(s)**. Or in an environment with Gradle installed: `gradle :app:assembleDebug`. CI provisions Gradle 8.13, JDK 17 and Android 36 automatically. The GitHub Actions YAML is the official build entry point and does not need a local Gradle wrapper binary.

Package ID: `com.smartsanaa.manager` · minSdk 26 · targetSdk 35 · Kotlin 2.3.0 · AGP 8.13.0 · Gradle 8.13 · Jetpack Compose.

## Configure your RouterOS
1. Enable RouterOS API (ideally `api-ssl` with a trusted certificate); use restricted credentials with only necessary permissions.
2. Ensure the phone has an IP route to the MikroTik management IP via the local network or approved VPN. `10.11.0.5` is only a prefilled example; it may be an OpenWrt host rather than your MikroTik router. Change it to the **actual RouterOS API host**.
3. Default port 8728 sends credentials over an **unencrypted** connection. For normal use select TLS 8729 and a certificate chaining to a trusted root, with its DNS hostname entered as host. The app does **not** disable certificate validation.
4. After login use Home and the navigation. The access rights of your RouterOS account determine whether commands succeed.
5. Voucher creation uses `/ip/hotspot/user/add` and creates Hotspot users, **not User Manager vouchers**. Select an existing Hotspot user profile. `limit-uptime` is consumed connection time, not a calendar expiry. Creation is an irreversible server-side action; review before using.

## Security and operational notes
- Credentials are stored encrypted by Android Keystore AES-256-GCM, not embedded in source or GitHub.
- No passwords, secrets or production network addresses should be committed to git.
- RouterOS API over port 8728 is not secure over untrusted networks.
- GitHub CI generates an **unsigned-for-release, debug-signed APK** for testing. Publishing requires your own managed release keystore and further security testing.
- Each API request currently establishes a new connection. Large deployments may need paging/cache, cancellation, background refresh, and limits. Lists currently render up to 500 records.
- API protocol and integration require testing against your actual MikroTik models and RouterOS versions.

## Project design
- `MainActivity.kt` — Compose RTL navigation and 17 screen implementation.
- `RouterOs.kt` — network binary API and v6/v7 command selection.
- `SecureConfig.kt` — encrypted local saved connection credentials.
- `Vouchers.kt` — Hotspot creation and PdfDocument print/share.
- `.github/workflows/android.yml` — APK build and artifact upload.

**Known limitation:** build not verified in this environment due to unavailable Android SDK/Gradle dependencies. Review the first Actions build log and fix any compiler/dependency issues before claiming a release APK.
